# 小红书笔记质检工具

自动化对飞书文档中的小红书笔记进行质检，识别违规词、敏感词、平台规则问题，输出质检报告并可选写入飞书行内评论。

## 功能特性

- 📝 **自动内容提取**：从飞书文档自动提取文本和图片
- 🔍 **OCR 图片识别**：自动识别图片中的文字内容
- ⚠️ **多层规则匹配**：平台规则 + 行业规则 + 项目规则三层质检
- 🤖 **AI 智能质检**：基于 LLM 的深度内容审核
- 💬 **飞书评论集成**：可将质检结果直接写入飞书文档行内评论
- 🔄 **规则自动更新**：平台规则每月更新，项目规则每日同步

## 系统要求

- Python 3.9+
- OpenClaw 环境（需要配置飞书应用）
- 飞书企业应用权限（读取文档、写入评论）

## 快速开始

### 1. 安装依赖

```bash
pip install requests Pillow
```

### 2. 运行质检

```bash
cd C:\Users\Administrator\.openclaw\workspace\skills\feishu-xiaolongxia-qa\scripts

# 基本用法
python -X utf8 simple_qc.py "<飞书文档URL>" --project 猿辅导 --industry 教育 --name "笔记名称"

# 示例
python -X utf8 simple_qc.py "https://xxx.feishu.cn/docx/xxxxx" --project 猿辅导 --industry 教育 --name "12-15岁数学思维小班安排表"
```

**参数说明：**
- `<飞书文档URL>`：飞书文档的完整 URL 或 doc_token
- `--project`：项目名称（默认"猿辅导"）
- `--industry`：行业名称（默认"教育"）
- `--name`：输出文件夹名称（建议使用笔记标题）

## 完整工作流程

### Step 1：脚本提取内容 + 规则匹配

```bash
python -X utf8 simple_qc.py "<飞书文档URL>" --project 猿辅导 --industry 教育 --name "笔记名称"
```

**输出：**
- `output/{笔记名称}/llm_input.json` — 提取的内容和规则命中
- `output/{笔记名称}/images/` — 下载的图片文件

### Step 2：OCR 图片识别

使用 OpenClaw 的 `image` 工具对 `llm_input.json` 中的所有图片进行 OCR 识别。

**输出：** `output/{笔记名称}/ocr_results.json`

### Step 2.5：合并 OCR 结果 + 规则匹配

```bash
python -X utf8 simple_qc.py "<doc_token>" --ocr-input "../output/{笔记名称}/ocr_results.json" --project 猿辅导 --industry 教育 --name "笔记名称"
```

**输出：** 更新后的 `llm_input.json`（包含 OCR 结果和规则命中）

### Step 3：AI 智能质检

AI 读取合并后的 `llm_input.json`，按照 `configs/qa_prompt.md` 中的流程执行深度质检。

**输出：** `output/{笔记名称}/llm_output.json` — 完整的质检报告

### Step 4：写入飞书评论（可选）

质检报告输出后，询问用户是否写入飞书评论。确认后执行：

```bash
python -X utf8 apply_comments.py --input "../output/{笔记名称}/comment_plan.json"
```

**输出：** `output/{笔记名称}/comment_apply_result.json`

## 规则系统

### 规则层级

| 层级 | 文件 | 说明 |
|------|------|------|
| 平台规则 | `rules/official/general_checkpoints.json` | 小红书聚光平台内容审核规则总则 |
| 行业规则 | `rules/official/education_checkpoints.json` | 教育行业特定规则 |
| 项目规则 | `rules/projects/yuanfudao.json` | 客户卡审词表（含 trigger_terms） |

### 规则更新

**自动更新：**
- 平台规则 + 行业规则：每月 15 号自动更新
- 项目规则：每天自动更新

**手动更新：**

```bash
cd scripts
python sync_rules.py --project 猿辅导 --industry 教育 --extract-official
```

> ⚠️ 默认只更新项目规则。加 `--extract-official` 才会同时更新平台+行业规则。

### 漏检反馈

当发现质检漏检时，可以将漏检词追加到项目规则的 `missed_words` 字段：

```json
{
  "missed_words": [
    {
      "word": "课时",
      "scene": "图片文字",
      "note": "教育行业通用敏感词，图片中出现原文必须标记",
      "added_at": "2026-06-22",
      "feedback_from": "用户反馈"
    }
  ]
}
```

后续质检会强制检查 `missed_words` 中的所有词汇。

## 输出文件说明

### 永久保留文件

- `llm_input.json` — 脚本提取的内容和规则命中
- `llm_output.json` — AI 质检结果
- `comment_plan.json` — 飞书评论计划

### 临时文件（质检完成后删除）

- `images/` — 下载的图片
- `ocr_results.json` — OCR 识别结果
- `comment_apply_result.json` — 评论写入结果

## 目录结构

```
feishu-xiaolongxia-qa/
├── README.md                          # 本文件
├── SKILL.md                           # OpenClaw Skill 定义
├── configs/
│   ├── llm_input_schema.json          # 脚本输出格式定义
│   ├── llm_output_schema.json         # 模型输出格式定义
│   ├── comment_plan_schema.json       # 评论 JSON 格式定义
│   ├── report_format.md               # 质检报告输出格式
│   ├── qa_prompt.md                   # AI 质检 Prompt
│   └── rules_config.md                # 规则配置说明
├── scripts/
│   ├── simple_qc.py                   # 主入口（文档解析 + 内容提取 + 规则匹配）
│   ├── sync_rules.py                  # 规则同步（从飞书/聚光平台拉取）
│   └── apply_comments.py              # 写入飞书评论
├── rules/
│   ├── manifest.json                  # 规则清单
│   ├── projects/
│   │   └── yuanfudao.json             # 猿辅导项目规则
│   └── official/
│       ├── general.json               # 平台总则（原始规则）
│       ├── education.json             # 教育行业规则（原始规则）
│       ├── general_checkpoints.json   # 平台结构化质检点
│       └── education_checkpoints.json # 行业结构化质检点
└── output/                            # 运行时产出
    └── {笔记名称}/
        ├── llm_input.json
        ├── llm_output.json
        └── comment_plan.json
```

## 常见问题

**Q: 如何修改默认项目或行业？**  
A: 修改 `scripts/sync_rules.py` 中的 `DEFAULT_PROJECT_SOURCES` 配置。

**Q: 规则更新后需要重新生成 checkpoints 吗？**  
A: 是的。平台/行业规则更新后，需要 AI 重新生成 `*_checkpoints.json` 文件。

**Q: 飞书凭据从哪里读取？**  
A: 从 OpenClaw gateway config 的 `channels.feishu.appId` 和 `channels.feishu.appSecret` 自动读取。

**Q: 如何添加新的项目规则？**  
A: 在 `rules/projects/` 目录下创建新的 JSON 文件，并在 `sync_rules.py` 中配置源 URL。

**Q: 质检报告格式可以自定义吗？**  
A: 可以。修改 `configs/report_format.md` 和 `configs/qa_prompt.md` 来调整报告格式和质检逻辑。

## 技术细节

### 飞书 API 调用

脚本会自动从 OpenClaw gateway config 读取飞书应用凭据，调用以下 API：
- 获取 tenant_access_token
- 读取飞书文档内容
- 下载文档中的图片
- 写入行内评论

### 规则匹配逻辑

1. **文本规则匹配**：对提取的文本内容进行关键词匹配
2. **图片规则匹配**：对 OCR 识别的文字进行关键词匹配
3. **missed_words 匹配**：强制检查历史漏检词汇
4. **AI 深度质检**：基于 LLM 的语义理解和上下文分析

### 重试机制

所有飞书 API 调用失败会自动重试，确保稳定性。

## 许可证

本工具仅供内部使用。

## 联系方式

如有问题或建议，请联系开发团队。

---

*最后更新：2026-06-24*
