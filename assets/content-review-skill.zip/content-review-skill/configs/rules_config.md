# 规则配置

## 规则来源

规则文件存储在 `rules/` 目录，分三层：

| 层级 | 文件 | 来源 | 说明 |
|------|------|------|------|
| 平台规则 | `rules/official/general.json` | 小红书聚光平台内容审核规则总则 | 原始规则，仅供同步时参考 |
| 行业规则 | `rules/official/education.json` | 小红书聚光平台教育行业规则 | 原始规则，仅供同步时参考 |
| 平台质检点 | `rules/official/general_checkpoints.json` | 从平台规则提取的结构化质检点 | **实际质检时读取此文件** |
| 行业质检点 | `rules/official/education_checkpoints.json` | 从行业规则提取的结构化质检点 | **实际质检时读取此文件** |
| 项目规则 | `rules/projects/yuanfudao.json` | 客户卡审词表（飞书文档） | 包含 trigger_terms、解决方案等 |

## 规则自动更新机制

| 规则类型 | 更新频率 | 触发方式 |
|---------|---------|----------|
| 平台总则 + 行业规则 | 每月 15 号 | 自动执行 |
| 项目规则（客户卡审词表） | 每天 | 用户说"更新"时立即执行；未说也每天自动执行 |

## 手动更新命令

```bash
cd C:\Users\Administrator\.openclaw\workspace\skills\feishu-xiaolongxia-qa\scripts
python sync_rules.py --project 猿辅导 --industry 教育 --extract-official
```

> ⚠️ **注意**：默认只更新项目规则。加 `--extract-official` 才会同时更新平台+行业规则。

## 如何修改默认项目/行业

如需更改默认的项目或行业，修改 `scripts/sync_rules.py` 中的 `DEFAULT_PROJECT_SOURCES`：

```python
# scripts/sync_rules.py
DEFAULT_PROJECT_SOURCES = {
    "你的项目名": {
        "slug": "your-project-slug",
        "industry": "你的行业",
        "source_url": "飞书文档链接",
    }
}
```

同时更新 SKILL.md 中所有命令示例的 `--project` 和 `--industry` 参数。

## 漏检反馈与规则补充

当用户指出质检漏检时：

1. **确认问题** → 分析为什么漏了（规则缺失 or 执行遗漏）
2. **追加到项目规则** → 写入 `rules/projects/{slug}.json` 的 `missed_words` 字段：

```json
{
  "missed_words": [
    {
      "word": "课时",
      "scene": "图片文字",
      "note": "教育行业通用敏感词，图片中出现原文必须标记",
      "added_at": "2026-06-22",
      "feedback_from": "用户反馈"
    }
  ]
}
```

3. **后续质检强制检查** → simple_qc.py 和模型都会读取 `missed_words`，OCR 完成后逐词扫描

如果是新类型的规则缺失（不是单个词，而是整类问题），同步补充到对应的规则层（平台/行业/项目）。

## 生成结构化质检点（仅规则更新时执行）

> ⚠️ **这不是每次质检的流程**，只在规则更新后执行。

脚本提取的原始规则（`education.json` / `general.json`）是长文本 sections，无法直接做关键词匹配。需要生成结构化的 checkpoints 文件。

**触发时机：**
- 每月 15 号平台/行业规则更新后
- 首次使用质检功能时（如果 checkpoints 文件不存在）

**执行方式：AI 生成**

AI 读取 `rules/official/education.json` 和 `rules/official/general.json`，提取结构化质检点，生成：
- `rules/official/education_checkpoints.json` — 教育行业结构化质检点
- `rules/official/general_checkpoints.json` — 平台通用规则结构化质检点

> ⚠️ 原始规则文件（`general.json` / `education.json`）仅供同步时参考，**实际质检时只读取 checkpoints 文件**。
