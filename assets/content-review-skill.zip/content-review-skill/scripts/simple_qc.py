#!/usr/bin/env python3
"""小红书质检脚本 - 飞书文档解析 + 内容提取 + 图片下载 + 规则匹配
合并了原 build_block_mapping.py 和 simple_qc.py
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# ============================================================
# 常量
# ============================================================

SKILL_DIR = Path(__file__).resolve().parent.parent
RULES_DIR = SKILL_DIR / "rules"

TITLE_LABELS = {"标题：", "标题:"}
BODY_LABELS = {"正文", "正文：", "正文:"}
HASHTAG_LABELS = {"话题 #Tag：", "话题 #Tag:", "话题#Tag：", "话题#Tag:"}
IMAGE_LABELS = ("封面", "图一", "图二", "图三", "图四", "图五", "图六")


# ============================================================
# 通用工具函数（原 build_block_mapping.py）
# ============================================================

def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def read_json(path: Path) -> Any:
    encodings = ("utf-8-sig", "utf-8", "utf-16", "utf-16-le", "utf-16-be")
    last_error: Exception | None = None
    for encoding in encodings:
        try:
            return json.loads(path.read_text(encoding=encoding))
        except (UnicodeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            last_error = exc
    if last_error is not None:
        raise last_error
    raise RuntimeError(f"Unable to read JSON from {path}")


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_text(value: Any) -> str:
    if value is None:
        return ""
    return " ".join(str(value).split()).strip()


def openclaw_config_path() -> Path:
    return Path.home() / ".openclaw" / "openclaw.json"


def load_feishu_credentials(config_path: Path) -> tuple[str, str]:
    payload = read_json(config_path)
    channels = payload.get("channels", {}) if isinstance(payload, dict) else {}
    feishu = channels.get("feishu", {}) if isinstance(channels, dict) else {}
    app_id = normalize_text(feishu.get("appId"))
    app_secret = normalize_text(feishu.get("appSecret"))
    if not app_id or not app_secret:
        raise RuntimeError(f"Feishu appId/appSecret not found in {config_path}")
    return app_id, app_secret


def fetch_tenant_access_token(app_id: str, app_secret: str) -> str:
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    body = json.dumps({"app_id": app_id, "app_secret": app_secret}).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=30) as response:
        payload = json.load(response)
    token = normalize_text(payload.get("tenant_access_token"))
    if not token:
        raise RuntimeError(payload.get("msg") or "Empty Feishu tenant access token")
    return token


def fetch_all_blocks(doc_token: str, token: str) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = []
    page_token = ""
    while True:
        params = [("page_size", "500")]
        if page_token:
            params.append(("page_token", page_token))
        query = "&".join(f"{key}={value}" for key, value in params)
        url = f"https://open.feishu.cn/open-apis/docx/v1/documents/{doc_token}/blocks?{query}"
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(req, timeout=60) as response:
            payload = json.load(response)
        data = payload.get("data", {})
        blocks.extend(data.get("items", []))
        if not data.get("has_more"):
            break
        page_token = normalize_text(data.get("page_token"))
        if not page_token:
            break
    return blocks


# ============================================================
# 文档结构解析（原 build_block_mapping.py）
# ============================================================

def block_text(block: dict[str, Any]) -> str:
    block_type = block.get("block_type")
    if block_type == 2:
        elements = block.get("text", {}).get("elements", [])
    elif block_type == 3:
        elements = block.get("heading1", {}).get("elements", [])
    else:
        return ""
    return normalize_text("".join(element.get("text_run", {}).get("content", "") for element in elements))


def note_id_from_heading(text: str, index: int) -> str:
    match = re.search(r"图文\s*(\d+)", text)
    if match:
        return f"n{match.group(1)}"
    return f"note-{index}"


def group_root_sections(root_children: list[str], blocks_by_id: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    heading_indices: list[tuple[int, str]] = []
    for index, block_id in enumerate(root_children):
        if blocks_by_id.get(block_id, {}).get("block_type") == 3:
            heading_indices.append((index, block_id))
    sections: list[dict[str, Any]] = []
    for idx, (start_index, heading_id) in enumerate(heading_indices, start=1):
        end_index = heading_indices[idx][0] if idx < len(heading_indices) else len(root_children)
        sections.append(
            {
                "heading_block_id": heading_id,
                "heading_text": block_text(blocks_by_id[heading_id]),
                "root_children": root_children[start_index:end_index],
                "section_index": idx,
            }
        )
    return sections


def first_grid_block(section_children: list[str], blocks_by_id: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
    for block_id in section_children:
        block = blocks_by_id.get(block_id, {})
        if block.get("block_type") == 24:
            return block
    return None


def all_grid_blocks(root_children: list[str], blocks_by_id: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    grids: list[dict[str, Any]] = []
    for block_id in root_children:
        block = blocks_by_id.get(block_id, {})
        if block.get("block_type") == 24:
            grids.append(block)
    return grids


def parse_left_column(blocks_by_id: dict[str, dict[str, Any]], column_block: dict[str, Any]) -> dict[str, Any]:
    positions: dict[str, str] = {}
    images: dict[str, dict[str, str]] = {}
    children = column_block.get("children", [])
    for index, child_id in enumerate(children):
        child = blocks_by_id.get(child_id, {})
        if child.get("block_type") != 2:
            continue
        label = block_text(child)
        if label not in IMAGE_LABELS:
            continue
        position = "封面图" if label == "封面" else label
        positions[position] = child_id
        image_block_id = ""
        for next_id in children[index + 1:]:
            next_block = blocks_by_id.get(next_id, {})
            if next_block.get("block_type") == 27:
                image_block_id = next_id
                break
            if next_block.get("block_type") == 2 and block_text(next_block) in IMAGE_LABELS:
                break
        images[position] = {"label_block_id": child_id, "image_block_id": image_block_id}
    return {"positions": positions, "images": images}


def parse_right_column(blocks_by_id: dict[str, dict[str, Any]], column_block: dict[str, Any]) -> dict[str, Any]:
    children = column_block.get("children", [])
    title_label_block_id = ""
    title_block_id = ""
    hashtags_label_block_id = ""
    hashtags_block_id = ""
    body_label_block_id = ""
    body_blocks: list[dict[str, str]] = []
    mode = ""

    for child_id in children:
        child = blocks_by_id.get(child_id, {})
        if child.get("block_type") != 2:
            continue
        text = block_text(child)
        if text in TITLE_LABELS:
            title_label_block_id = child_id
            mode = "title"
            continue
        if text in BODY_LABELS:
            body_label_block_id = child_id
            mode = "body"
            continue
        if text in HASHTAG_LABELS:
            hashtags_label_block_id = child_id
            mode = "hashtags"
            continue

        if mode == "title" and text and not title_block_id:
            title_block_id = child_id
            mode = ""
            continue
        if mode == "body":
            if text:
                body_blocks.append({"block_id": child_id, "text": text})
            continue
        if mode == "hashtags" and text and not hashtags_block_id:
            hashtags_block_id = child_id
            mode = ""
            continue

    positions = {
        "标题": title_block_id or title_label_block_id,
        "正文": body_blocks[0]["block_id"] if body_blocks else body_label_block_id,
        "话题": hashtags_block_id or hashtags_label_block_id,
    }

    return {
        "title_label_block_id": title_label_block_id,
        "title_block_id": title_block_id,
        "body_label_block_id": body_label_block_id,
        "body_blocks": body_blocks,
        "hashtags_label_block_id": hashtags_label_block_id,
        "hashtags_block_id": hashtags_block_id,
        "positions": positions,
    }


def build_note_mapping(section: dict[str, Any], blocks_by_id: dict[str, dict[str, Any]]) -> dict[str, Any]:
    grid_block = first_grid_block(section["root_children"], blocks_by_id)
    note_id = note_id_from_heading(section["heading_text"], section["section_index"])
    payload = {
        "note_id": note_id,
        "heading": section["heading_text"],
        "heading_block_id": section["heading_block_id"],
        "grid_block_id": grid_block.get("block_id") if grid_block else "",
        "fields": {},
        "positions": {},
        "images": {},
        "body_paragraphs": [],
    }
    if not grid_block:
        return payload

    column_ids = grid_block.get("children", [])
    if len(column_ids) < 2:
        return payload
    left_column = blocks_by_id.get(column_ids[0], {})
    right_column = blocks_by_id.get(column_ids[1], {})

    left = parse_left_column(blocks_by_id, left_column)
    right = parse_right_column(blocks_by_id, right_column)

    fields = {
        "cover_text": left["positions"].get("封面图", ""),
        "title": right["title_block_id"] or right["title_label_block_id"],
        "body": right["body_blocks"][0]["block_id"] if right["body_blocks"] else right["body_label_block_id"],
        "hashtags": right["hashtags_block_id"] or right["hashtags_label_block_id"],
    }
    positions = dict(left["positions"])
    positions.update(right["positions"])

    payload.update(
        {
            "fields": fields,
            "positions": positions,
            "images": left["images"],
            "body_paragraphs": right["body_blocks"],
            "title_label_block_id": right["title_label_block_id"],
            "title_block_id": right["title_block_id"],
            "body_label_block_id": right["body_label_block_id"],
            "hashtags_label_block_id": right["hashtags_label_block_id"],
            "hashtags_block_id": right["hashtags_block_id"],
        }
    )
    return payload


def build_note_mapping_from_grid(
    grid_block: dict[str, Any],
    blocks_by_id: dict[str, dict[str, Any]],
    doc_token: str,
    note_index: int = 1,
) -> dict[str, Any]:
    """直接从 GRID block 构建 note_mapping（用于没有 Heading1 的文档）"""
    payload = {
        "note_id": f"note-{note_index}",
        "heading": "",
        "heading_block_id": "",
        "grid_block_id": grid_block.get("block_id", ""),
        "fields": {},
        "positions": {},
        "images": {},
        "body_paragraphs": [],
    }

    column_ids = grid_block.get("children", [])
    if len(column_ids) < 2:
        return payload

    left_column = blocks_by_id.get(column_ids[0], {})
    right_column = blocks_by_id.get(column_ids[1], {})

    left = parse_left_column(blocks_by_id, left_column)
    right = parse_right_column(blocks_by_id, right_column)

    fields = {
        "cover_text": left["positions"].get("封面图", ""),
        "title": right["title_block_id"] or right["title_label_block_id"],
        "body": right["body_blocks"][0]["block_id"] if right["body_blocks"] else right["body_label_block_id"],
        "hashtags": right["hashtags_block_id"] or right["hashtags_label_block_id"],
    }
    positions = dict(left["positions"])
    positions.update(right["positions"])

    payload.update(
        {
            "fields": fields,
            "positions": positions,
            "images": left["images"],
            "body_paragraphs": right["body_blocks"],
            "title_label_block_id": right["title_label_block_id"],
            "title_block_id": right["title_block_id"],
            "body_label_block_id": right["body_label_block_id"],
            "hashtags_label_block_id": right["hashtags_label_block_id"],
            "hashtags_block_id": right["hashtags_block_id"],
        }
    )
    return payload


def build_block_mapping(doc_token: str, blocks: list[dict[str, Any]]) -> dict[str, Any]:
    blocks_by_id = {block["block_id"]: block for block in blocks if isinstance(block, dict) and block.get("block_id")}
    root = blocks_by_id.get(doc_token) or blocks[0]
    root_children = root.get("children", [])
    sections = group_root_sections(root_children, blocks_by_id)

    if not sections:
        grid_blocks = all_grid_blocks(root_children, blocks_by_id)
        if grid_blocks:
            notes = [
                build_note_mapping_from_grid(grid_block, blocks_by_id, doc_token, note_index=index + 1)
                for index, grid_block in enumerate(grid_blocks)
            ]
        else:
            notes = []
    else:
        notes = [build_note_mapping(section, blocks_by_id) for section in sections]

    note_map = {note["note_id"]: note for note in notes}
    return {
        "doc_token": doc_token,
        "generated_at": now_iso(),
        "note_count": len(notes),
        "notes": notes,
        "note_map": note_map,
    }


# ============================================================
# 内容提取 + 图片下载（原 simple_qc.py）
# ============================================================

def parse_doc_token(value: str) -> str:
    raw = normalize_text(value)
    if not raw:
        raise RuntimeError("Missing doc token or URL.")
    if raw.startswith("http://") or raw.startswith("https://"):
        parsed = urllib.parse.urlparse(raw)
        parts = [part for part in parsed.path.split("/") if part]
        for marker in ("docx", "docs", "doc"):
            if marker in parts:
                idx = parts.index(marker)
                if idx + 1 < len(parts):
                    return parts[idx + 1]
        return parts[-1]
    return raw


def extract_full_text(block_mapping: dict[str, Any], blocks_by_id: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """从 block_mapping 和 blocks_by_id 提取每篇笔记的完整文本内容"""
    notes = []
    for note in block_mapping.get("notes", []):
        note_id = note.get("note_id", "")
        heading = note.get("heading", "")

        # 封面文案
        cover_text = ""
        cover_field_id = note.get("fields", {}).get("cover_text", "")
        if cover_field_id and cover_field_id in blocks_by_id:
            block = blocks_by_id[cover_field_id]
            if block.get("block_type") == 2:
                elements = block.get("text", {}).get("elements", [])
                cover_text = normalize_text("".join(
                    e.get("text_run", {}).get("content", "") for e in elements
                ))

        # 标题
        title = ""
        title_block_id = note.get("title_block_id", "")
        if title_block_id and title_block_id in blocks_by_id:
            block = blocks_by_id[title_block_id]
            if block.get("block_type") == 2:
                elements = block.get("text", {}).get("elements", [])
                title = normalize_text("".join(
                    e.get("text_run", {}).get("content", "") for e in elements
                ))

        # 正文
        body_paragraphs = note.get("body_paragraphs", [])
        body_parts = []
        for para in body_paragraphs:
            block_id = para.get("block_id", "")
            text = normalize_text(para.get("text", ""))
            if not text and block_id and block_id in blocks_by_id:
                block = blocks_by_id[block_id]
                if block.get("block_type") == 2:
                    elements = block.get("text", {}).get("elements", [])
                    text = normalize_text("".join(
                        e.get("text_run", {}).get("content", "") for e in elements
                    ))
            if text:
                body_parts.append(text)
        body = "\n".join(body_parts)

        # 话题
        hashtags = []
        hashtags_block_id = note.get("hashtags_block_id", "")
        if hashtags_block_id and hashtags_block_id in blocks_by_id:
            block = blocks_by_id[hashtags_block_id]
            if block.get("block_type") == 2:
                elements = block.get("text", {}).get("elements", [])
                ht_text = normalize_text("".join(
                    e.get("text_run", {}).get("content", "") for e in elements
                ))
                hashtags = re.findall(r"#([^\s#]+)", ht_text)

        # 图片信息
        images = note.get("images", {})
        image_list = []
        for position, img_info in images.items():
            image_block_id = img_info.get("image_block_id", "")
            if image_block_id and image_block_id in blocks_by_id:
                block = blocks_by_id[image_block_id]
                if block.get("block_type") == 27:
                    token = block.get("image", {}).get("token", "")
                    if token:
                        image_list.append({
                            "position": position,
                            "image_token": token,
                            "block_id": image_block_id,
                        })

        notes.append({
            "note_id": note_id,
            "heading": heading,
            "title": title,
            "cover_text": cover_text,
            "body": body,
            "hashtags": hashtags,
            "images": image_list,
        })
    return notes


def download_images(notes: list[dict[str, Any]], api_token: str, out_dir: Path) -> list[dict[str, str]]:
    """下载所有图片到本地目录"""
    downloaded = []
    out_dir.mkdir(parents=True, exist_ok=True)

    pos_map = {"封面图": "cover", "图一": "img1", "图二": "img2", "图三": "img3", "图四": "img4", "图五": "img5", "图六": "img6"}

    for note in notes:
        note_id = note.get("note_id", "")
        for img in note.get("images", []):
            position = img.get("position", "")
            token = img.get("image_token", "")
            if not token:
                continue

            pos_en = pos_map.get(position, position)
            filename = f"{note_id}_{pos_en}_{token}.jpg"
            filepath = out_dir / filename

            if filepath.exists():
                downloaded.append({
                    "note_id": note_id,
                    "position": position,
                    "image_token": token,
                    "local_path": str(filepath),
                })
                continue

            try:
                url = f"https://open.feishu.cn/open-apis/drive/v1/medias/{token}/download"
                req = urllib.request.Request(url, headers={"Authorization": f"Bearer {api_token}"})
                with urllib.request.urlopen(req, timeout=60) as response:
                    data = response.read()
                filepath.write_bytes(data)
                downloaded.append({
                    "note_id": note_id,
                    "position": position,
                    "image_token": token,
                    "local_path": str(filepath),
                })
                print(f"  下载: {position} -> {filepath.name} ({len(data)} bytes)")
            except Exception as e:
                print(f"  失败: {position} ({token}) -> {e}")
                downloaded.append({
                    "note_id": note_id,
                    "position": position,
                    "image_token": token,
                    "local_path": "",
                    "error": str(e),
                })

    return downloaded


def ocr_image(image_path: Path, api_token: str) -> str:
    """OCR 由 agent 在 Step 2 使用 image 工具完成，脚本不做 OCR"""
    return ""


def ocr_images(downloaded: list[dict[str, str]], api_token: str) -> list[dict[str, Any]]:
    """脚本不做 OCR，直接返回空结果，由 agent Step 2 处理"""
    ocr_results = []
    for img in downloaded:
        result = dict(img)
        result["ocr_text"] = ""
        ocr_results.append(result)
        print(f"  OCR: {img.get('position')} -> 待 agent Step 2 处理")
    return ocr_results


# ============================================================
# 规则加载 + 匹配
# ============================================================




def slugify(value: str) -> str:
    """将字符串转换为文件名安全的格式"""
    value = re.sub(r'[^0-9A-Za-z\u4e00-\u9fff]+', '-', value.strip().lower())
    return value.strip('-') or 'item'


def project_slug(project: str) -> str:
    """根据项目名生成文件名 slug"""
    # 常见项目名映射
    KNOWN_SLUGS = {
        "猿辅导": "yuanfudao",
        "yuanfudao": "yuanfudao",
    }
    if project in KNOWN_SLUGS:
        return KNOWN_SLUGS[project]
    return slugify(project)


def load_rules(project: str = "猿辅导", industry: str = "教育") -> dict[str, Any]:
    """加载所有规则文件"""
    rules = {
        "project": [],
        "industry": [],
        "general": [],
        "general_checkpoints": [],
        "industry_checkpoints": [],
        "missed_words": [],
    }

    # 项目规则：根据 project 参数动态查找
    slug = project_slug(project)
    project_file = RULES_DIR / "projects" / f"{slug}.json"
    if project_file.exists():
        data = read_json(project_file)
        rules["project"] = data.get("entries", [])
        rules["missed_words"] = data.get("missed_words", [])
    else:
        # fallback: 尝试加载默认项目
        default_file = RULES_DIR / "projects" / "yuanfudao.json"
        if default_file.exists():
            data = read_json(default_file)
            rules["project"] = data.get("entries", [])
            rules["missed_words"] = data.get("missed_words", [])

    # 行业规则：优先使用 AI 生成的 checkpoints，其次用脚本自动生成的
    industry_checkpoints_file = RULES_DIR / "official" / "education_checkpoints.json"
    if industry_checkpoints_file.exists():
        data = read_json(industry_checkpoints_file)
        rules["industry_checkpoints"] = data.get("categories", [])

    # 平台通用规则：加载 AI 生成的 checkpoints
    checkpoints_file = RULES_DIR / "official" / "general_checkpoints.json"
    if checkpoints_file.exists():
        data = read_json(checkpoints_file)
        rules["general_checkpoints"] = data.get("categories", [])

    return rules


def match_text_rules(text: str, field: str, rules: dict[str, Any]) -> list[dict[str, Any]]:
    """对文本做规则匹配（项目 + 行业 + 平台通用 + 平台结构化质检点 + missed_words）"""
    issues = []
    if not text:
        return issues

    # 1. 项目规则匹配（trigger_terms / patterns）
    for entry in rules.get("project", []):
        trigger_terms = entry.get("trigger_terms", [])
        patterns = entry.get("patterns", [])
        all_terms = list(trigger_terms) + list(patterns)

        if not all_terms:
            continue

        category = entry.get("category", "")
        solution = entry.get("solution", "")
        soft_solution = entry.get("soft_solution", "")
        checkpoint_id = entry.get("checkpoint_id", "")
        checkpoint_name = entry.get("checkpoint_name", "")
        reason = entry.get("reason", "")
        rewrite_candidates = entry.get("rewrite_candidates", [])

        for term in all_terms:
            if not term or not isinstance(term, str):
                continue
            term = term.strip()
            if not term:
                continue

            if term in text:
                issues.append({
                    "field": field,
                    "matched_text": term,
                    "source_type": "project",
                    "checkpoint_id": checkpoint_id,
                    "checkpoint_name": checkpoint_name or category,
                    "reason": reason or f"项目规则: {category}",
                    "solution": soft_solution or solution,
                    "rewrite_candidates": rewrite_candidates,
                })
                break

    # 2. missed_words 匹配（用户反馈沉淀的易漏检词）
    for missed in rules.get("missed_words", []):
        word = missed.get("word", "")
        if not word or not isinstance(word, str):
            continue
        word = word.strip()
        if not word:
            continue

        if word in text:
            issues.append({
                "field": field,
                "matched_text": word,
                "source_type": "missed_word",
                "checkpoint_id": "",
                "checkpoint_name": missed.get("scene", "易漏检词"),
                "reason": missed.get("note", "用户反馈沉淀的易漏检词"),
                "solution": "",
                "rewrite_candidates": [],
            })

    # 3. 平台结构化质检点匹配（general_checkpoints）
    for cat in rules.get("general_checkpoints", []):
        cat_id = cat.get("id", "")
        cat_name = cat.get("name", "")
        for cp in cat.get("checkpoints", []):
            cp_id = cp.get("id", "")
            cp_name = cp.get("name", "")
            patterns = cp.get("match_patterns", [])
            prompt_rule = cp.get("prompt_rule", "")

            for pattern in patterns:
                if not pattern:
                    continue
                try:
                    if re.search(pattern, text):
                        issues.append({
                            "field": field,
                            "matched_text": pattern,
                            "source_type": "platform",
                            "checkpoint_id": cp_id,
                            "checkpoint_name": f"{cat_name}-{cp_name}",
                            "reason": prompt_rule,
                            "solution": "",
                            "rewrite_candidates": [],
                        })
                        break
                except re.error:
                    if pattern in text:
                        issues.append({
                            "field": field,
                            "matched_text": pattern,
                            "source_type": "platform",
                            "checkpoint_id": cp_id,
                            "checkpoint_name": f"{cat_name}-{cp_name}",
                            "reason": prompt_rule,
                            "solution": "",
                            "rewrite_candidates": [],
                        })
                        break

    # 4. 行业结构化质检点匹配（industry_checkpoints）
    for cat in rules.get("industry_checkpoints", []):
        cat_id = cat.get("id", "")
        cat_name = cat.get("name", "")
        for cp in cat.get("checkpoints", []):
            cp_id = cp.get("id", "")
            cp_name = cp.get("name", "")
            patterns = cp.get("match_patterns", [])
            prompt_rule = cp.get("prompt_rule", "")

            for pattern in patterns:
                if not pattern:
                    continue
                try:
                    if re.search(pattern, text):
                        issues.append({
                            "field": field,
                            "matched_text": pattern,
                            "source_type": "industry",
                            "checkpoint_id": cp_id,
                            "checkpoint_name": f"{cat_name}-{cp_name}",
                            "reason": prompt_rule,
                            "solution": "",
                            "rewrite_candidates": [],
                        })
                        break
                except re.error:
                    if pattern in text:
                        issues.append({
                            "field": field,
                            "matched_text": pattern,
                            "source_type": "industry",
                            "checkpoint_id": cp_id,
                            "checkpoint_name": f"{cat_name}-{cp_name}",
                            "reason": prompt_rule,
                            "solution": "",
                            "rewrite_candidates": [],
                        })
                        break

    return issues


# ============================================================
# 主流程
# ============================================================

def run_simple_qc(doc_token_or_url: str, project: str = "猿辅导", industry: str = "教育", name: str = "") -> dict[str, Any]:
    """主流程：解析文档 → 提取内容 → 下载图片 → 规则匹配 → 输出 JSON"""
    doc_token = parse_doc_token(doc_token_or_url)
    print(f"[1/5] 解析文档 token: {doc_token}")

    # 获取飞书 access token
    config_path = openclaw_config_path()
    app_id, app_secret = load_feishu_credentials(config_path)
    token = fetch_tenant_access_token(app_id, app_secret)
    print(f"[2/5] 获取 access token 成功")

    # 获取文档 blocks
    blocks = fetch_all_blocks(doc_token, token)
    blocks_by_id = {b["block_id"]: b for b in blocks if isinstance(b, dict) and b.get("block_id")}
    print(f"  获取 {len(blocks)} 个 blocks")

    # 构建 block mapping
    block_mapping = build_block_mapping(doc_token, blocks)
    print(f"[3/5] 构建 block mapping: {block_mapping.get('note_count', 0)} 篇笔记")

    # 提取文本内容
    notes = extract_full_text(block_mapping, blocks_by_id)
    print(f"[4/5] 提取文本内容:")
    for note in notes:
        print(f"  {note['note_id']}: 标题={note['title'][:30]}... 正文={len(note['body'])}字 图片={len(note['images'])}张")

    # 图片下载到 output/{name}/images/ 目录
    if not name:
        name = doc_token
    output_dir = SKILL_DIR / "output" / name
    images_dir = output_dir / "images"
    print(f"[5/5] 下载图片到 {images_dir}")
    downloaded = download_images(notes, token, images_dir)

    # 加载规则
    rules = load_rules(project, industry)
    industry_cp_count = sum(len(c.get('checkpoints', [])) for c in rules.get('industry_checkpoints', []))
    print(f"  规则加载: 项目={len(rules['project'])}条 平台质检点={sum(len(c.get('checkpoints',[])) for c in rules['general_checkpoints'])}条 行业质检点={industry_cp_count}条")

    # 文本规则匹配（封面文案 + 标题 + 正文 + 话题）
    all_issues = []
    for note in notes:
        if note.get("cover_text"):
            issues = match_text_rules(note["cover_text"], "封面图", rules)
            all_issues.extend(issues)
        if note.get("title"):
            issues = match_text_rules(note["title"], "标题", rules)
            all_issues.extend(issues)
        if note.get("body"):
            issues = match_text_rules(note["body"], "正文", rules)
            all_issues.extend(issues)
        if note.get("hashtags"):
            hashtag_text = " ".join(f"#{tag}" for tag in note["hashtags"])
            issues = match_text_rules(hashtag_text, "话题", rules)
            all_issues.extend(issues)

    # 图片规则匹配在 Step 2.5 由 merge_ocr_results 处理，此处不做
    image_issues = []

    # 收集所有图片信息（无 OCR，OCR 由 agent Step 2 完成）
    all_images = []
    for note in notes:
        for img in note.get("images", []):
            all_images.append(img)

    # 保存结果到 output/{name}/llm_input.json
    output_dir = SKILL_DIR / "output" / name
    output_dir.mkdir(parents=True, exist_ok=True)
    result = {
        "doc_token": doc_token,
        "notes": notes,
        "images": all_images,
        "text_issues": all_issues,
        "rules_summary": {
            "project_rules": len(rules["project"]),
            "industry_rules": len(rules["industry"]),
            "general_rules": len(rules["general"]),
            "platform_checkpoints": sum(len(c.get("checkpoints", [])) for c in rules["general_checkpoints"]),
        },
    }

    output_path = output_dir / "llm_input.json"
    write_json(output_path, result)

    # 统计
    text_issue_count = len(all_issues)
    print(f"\n✅ 结果已保存: {output_path}")
    print(f"  文本规则匹配: {text_issue_count} 条")
    print(f"  图片: {len(all_images)} 张（待 agent OCR）")
    print(f"  图片规则匹配: {len(image_issues)} 条")
    print(f"  总命中: {len(all_issues)} 条")
    print(f"\n提示: 脚本已完成关键词/正则匹配，agent 可进一步做语义理解质检。")

    result["_output_dir"] = str(output_dir)
    result["_name"] = name
    return result


def merge_ocr_results(doc_token: str, ocr_input_path: str, project: str, industry: str, name: str = "") -> dict[str, Any]:
    """读取 agent OCR 结果 JSON，合并到 llm_input.json
    
    输入格式 (ocr_results.json):
    {
      "ocr_results": [
        {
          "note_id": "note-1",
          "position": "封面图",
          "local_path": "runs/.../images/cover_xxx.jpg",
          "ocr_text": "图片中的文字..."
        }
      ]
    }
    """
    ocr_path = Path(ocr_input_path)
    if not ocr_path.exists():
        print(f"❌ OCR 输入文件不存在: {ocr_path}")
        return {}

    ocr_data = read_json(ocr_path)
    ocr_results = ocr_data.get("ocr_results", [])
    if not isinstance(ocr_results, list):
        print(f'❌ OCR 输入格式错误，需要 {{"ocr_results": [...]}}: {ocr_path}')
        return {}

    # 加载规则
    rules = load_rules(project, industry)
    industry_cp_count = sum(len(c.get('checkpoints', [])) for c in rules.get('industry_checkpoints', []))
    print(f"  规则加载: 项目={len(rules['project'])}条 平台质检点={sum(len(c.get('checkpoints',[])) for c in rules['general_checkpoints'])}条 行业质检点={industry_cp_count}条")

    # 对每张图片的 OCR 文字做规则匹配
    image_issues = []
    for item in ocr_results:
        position = item.get("position", "")
        ocr_text = item.get("ocr_text", "")
        if not ocr_text or not isinstance(ocr_text, str):
            continue
        ocr_text = ocr_text.strip()
        if not ocr_text:
            continue
        issues = match_text_rules(ocr_text, f"图片-{position}", rules)
        image_issues.extend(issues)
        print(f"  图片-{position}: {len(ocr_text)}字 -> 命中 {len(issues)} 条")

    # 读取已有结果
    if not name:
        name = doc_token
    output_dir = SKILL_DIR / "output" / name
    result_path = output_dir / "llm_input.json"
    if result_path.exists():
        result = read_json(result_path)
    else:
        print(f"⚠️ 未找到已有结果文件: {result_path}，创建新结果")
        result = {"doc_token": doc_token, "notes": [], "images": [], "text_issues": [], "check_dimensions": [], "rules_summary": {}}

    # 合并 OCR 结果到 simple_qc_result.json
    result["ocr_results"] = ocr_results

    # 合并图片规则命中到 text_issues
    existing_issues = result.get("text_issues", [])
    # 移除已有的图片规则命中（避免重复）
    existing_issues = [i for i in existing_issues if not i.get("field", "").startswith("图片-")]
    existing_issues.extend(image_issues)
    result["text_issues"] = existing_issues

    # 更新 stats
    if "stats" not in result:
        result["stats"] = {}
    result["stats"]["ocr_count"] = len(ocr_results)
    result["stats"]["image_issue_count"] = len(image_issues)
    result["stats"]["total_issue_count"] = len(existing_issues)

    write_json(result_path, result)

    print(f"\n✅ OCR 合并完成: {result_path}")
    print(f"  OCR 结果: {len(ocr_results)} 张图片")
    print(f"  图片规则匹配: {len(image_issues)} 条")
    print(f"  总命中: {len(existing_issues)} 条")

    return result


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    parser = argparse.ArgumentParser(description="小红书质检 - 飞书文档解析 + 内容提取 + 规则匹配")
    parser.add_argument("doc_token", help="飞书文档 token 或 URL")
    parser.add_argument("--project", default="猿辅导", help="项目名（默认：猿辅导）")
    parser.add_argument("--industry", default="教育", help="行业名（默认：教育）")
    parser.add_argument("--ocr-input", help="Agent OCR 结果 JSON 文件路径。格式: {\"ocr_results\": [{\"note_id\": \"...\", \"position\": \"...\", \"local_path\": \"...\", \"ocr_text\": \"...\"}]}。传入后合并到 llm_input.json 并对 OCR 文字做规则匹配。")
    parser.add_argument("--name", default="", help="输出文件夹名（默认使用 doc_token）")
    args = parser.parse_args()

    if args.ocr_input:
        result = merge_ocr_results(args.doc_token, args.ocr_input, args.project, args.industry, args.name)
        if result.get("text_issues"):
            print(f"\n=== 图片 OCR 规则匹配 ===")
            for issue in result["text_issues"]:
                if issue["field"].startswith("图片-"):
                    print(f"  {issue['field']}: \"{issue['matched_text']}\" -> {issue['checkpoint_name']}")
        return 0

    result = run_simple_qc(args.doc_token, args.project, args.industry, args.name)

    # 输出摘要
    print("\n=== 摘要 ===")
    for note in result["notes"]:
        print(f"\n笔记: {note['note_id']}")
        print(f"  标题: {note['title']}")
        print(f"  封面文案: {note['cover_text']}")
        print(f"  正文前100字: {note['body'][:100]}...")
        print(f"  话题: {note['hashtags']}")
        print(f"  图片: {len(note['images'])}张")

    if result["text_issues"]:
        print(f"\n=== 文本规则匹配 ({len(result['text_issues'])}条) ===")
        for issue in result["text_issues"]:
            print(f"  {issue['field']}: \"{issue['matched_text']}\" -> {issue['checkpoint_name']}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
