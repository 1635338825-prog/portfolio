#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def read_json(path: Path) -> Any:
    encodings = ("utf-8-sig", "utf-8", "utf-16", "utf-16-le", "utf-16-be")
    last_error: Exception | None = None
    for encoding in encodings:
        try:
            return json.loads(path.read_text(encoding=encoding))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            last_error = exc
    if last_error is not None:
        raise last_error
    raise RuntimeError(f"Unable to read JSON from {path}")


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_text(value: Any) -> str:
    if value is None:
        return ""
    return " ".join(str(value).split()).strip()


def comment_hash(block_id: str, comment: str) -> str:
    digest = hashlib.sha256(f"{block_id}\n{comment}".encode("utf-8")).hexdigest()
    return digest


def load_state(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"written_ids": [], "written_hashes": []}
    payload = read_json(path)
    if not isinstance(payload, dict):
        return {"written_ids": [], "written_hashes": []}
    payload.setdefault("written_ids", [])
    payload.setdefault("written_hashes", [])
    return payload


def save_state(path: Path, state: dict[str, Any]) -> None:
    write_json(path, state)


def openclaw_config_path() -> Path:
    configured = os.environ.get("OPENCLAW_CONFIG")
    if configured:
        return Path(configured)
    return Path.home() / ".openclaw" / "openclaw.json"


def load_feishu_credentials(config_path: Path) -> tuple[str, str]:
    payload = read_json(config_path)
    channels = payload.get("channels", {}) if isinstance(payload, dict) else {}
    feishu = channels.get("feishu", {}) if isinstance(channels, dict) else {}
    app_id = normalize_text(feishu.get("appId"))
    app_secret = normalize_text(feishu.get("appSecret"))
    if not app_id or not app_secret:
        raise RuntimeError(f"Feishu appId/appSecret not found in {config_path}")
    return app_id, app_secret


def fetch_tenant_access_token(app_id: str, app_secret: str) -> str:
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    body = json.dumps({"app_id": app_id, "app_secret": app_secret}).encode("utf-8")
    request = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = json.load(response)
    if payload.get("code") not in (0, None):
        raise RuntimeError(payload.get("msg") or "Failed to get Feishu tenant access token")
    token = normalize_text(payload.get("tenant_access_token"))
    if not token:
        raise RuntimeError("Empty Feishu tenant access token")
    return token


def write_comment(file_token: str, block_id: str, comment: str, access_token: str) -> dict[str, Any]:
    encoded_token = urllib.parse.quote(file_token, safe="")
    url = f"https://open.feishu.cn/open-apis/drive/v1/files/{encoded_token}/new_comments"
    
    # 将换行符替换为 | 分隔符
    comment = comment.replace("\n", "|")
    
    payload = {
        "file_type": "docx",
        "reply_elements": [{"type": "text", "text": comment}],
        "anchor": {"block_id": block_id},
    }
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        return json.load(response)


def item_final_id(item: dict[str, Any], index: int) -> str:
    return normalize_text(item.get("final_comment_id")) or normalize_text(item.get("comment_id")) or f"comment-{index}"


def item_write_policy(item: dict[str, Any]) -> str:
    return normalize_text(item.get("write_policy")) or "write"


def resolve_file_token(plan: dict[str, Any], item: dict[str, Any]) -> str:
    return normalize_text(item.get("file_token")) or normalize_text(plan.get("file_token")) or normalize_text(plan.get("doc_token"))


def build_result_entry(item: dict[str, Any], final_comment_id: str, status: str, **extra: Any) -> dict[str, Any]:
    entry = {
        "final_comment_id": final_comment_id,
        "block_id": normalize_text(item.get("block_id")),
        "status": status,
    }
    entry.update(extra)
    return entry


def apply_comments(plan: dict[str, Any], *, dry_run: bool, sleep_seconds: float, state_path: Path, config_path: Path | None) -> dict[str, Any]:
    state = load_state(state_path)
    written_ids = set(normalize_text(item) for item in state.get("written_ids", []))
    written_hashes = set(normalize_text(item) for item in state.get("written_hashes", []))

    results: list[dict[str, Any]] = []
    token: str | None = None
    if not dry_run:
        if config_path is None:
            config_path = openclaw_config_path()
        app_id, app_secret = load_feishu_credentials(config_path)
        token = fetch_tenant_access_token(app_id, app_secret)

    items = plan.get("items", [])
    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            results.append(build_result_entry({}, f"comment-{index}", "failed", error="invalid_item"))
            continue

        final_comment_id = item_final_id(item, index)
        write_policy = item_write_policy(item)
        block_id = normalize_text(item.get("block_id"))
        comment = normalize_text(item.get("comment"))
        file_token = resolve_file_token(plan, item)

        if write_policy != "write":
            results.append(build_result_entry(item, final_comment_id, "skipped", reason=f"write_policy={write_policy}"))
            continue
        if not block_id:
            results.append(build_result_entry(item, final_comment_id, "skipped", reason="missing_block_id"))
            continue
        if not comment:
            results.append(build_result_entry(item, final_comment_id, "skipped", reason="missing_comment"))
            continue
        if not file_token:
            results.append(build_result_entry(item, final_comment_id, "failed", error="missing_file_token"))
            continue

        dedupe_hash = comment_hash(block_id, comment)
        if final_comment_id in written_ids or dedupe_hash in written_hashes:
            results.append(build_result_entry(item, final_comment_id, "skipped", reason="duplicate"))
            continue

        if dry_run:
            results.append(build_result_entry(item, final_comment_id, "dry_run", file_token=file_token))
            continue

        assert token is not None
        try:
            payload = write_comment(file_token, block_id, comment, token)
            code = payload.get("code", 0)
            if code not in (0, None):
                results.append(build_result_entry(item, final_comment_id, "failed", error=payload.get("msg") or "unknown_error", response=payload))
            else:
                written_ids.add(final_comment_id)
                written_hashes.add(dedupe_hash)
                state["written_ids"] = sorted(written_ids)
                state["written_hashes"] = sorted(written_hashes)
                save_state(state_path, state)
                results.append(build_result_entry(item, final_comment_id, "written", file_token=file_token, response=payload))
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read().decode("utf-8", errors="replace")
            except Exception:
                body = ""
            results.append(build_result_entry(item, final_comment_id, "failed", error=f"http_{exc.code}", response=body))
        except Exception as exc:  # noqa: BLE001
            results.append(build_result_entry(item, final_comment_id, "failed", error=str(exc)))

        if sleep_seconds > 0:
            time.sleep(sleep_seconds)

    summary = {
        "total": len(results),
        "written": sum(1 for item in results if item["status"] == "written"),
        "dry_run": sum(1 for item in results if item["status"] == "dry_run"),
        "skipped": sum(1 for item in results if item["status"] == "skipped"),
        "failed": sum(1 for item in results if item["status"] == "failed"),
    }
    return {
        "doc_token": normalize_text(plan.get("doc_token")),
        "file_token": normalize_text(plan.get("file_token")),
        "started_at": now_iso(),
        "finished_at": now_iso(),
        "summary": summary,
        "results": results,
        "state_file": str(state_path),
        "dry_run": dry_run,
    }


def make_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Apply Feishu comments from comment_plan_final.json.")
    parser.add_argument("--input", required=True, help="Path to comment_plan_final.json.")
    parser.add_argument("--output", help="Path to write comment_apply_result.json. Defaults beside --input.")
    parser.add_argument("--state-file", help="Path to state file for idempotent comment writes.")
    parser.add_argument("--sleep-seconds", type=float, default=1.0, help="Seconds to sleep between comment writes.")
    parser.add_argument("--dry-run", action="store_true", help="Do not call Feishu API; only validate and simulate writes.")
    parser.add_argument("--config", help="Path to OpenClaw config JSON. Defaults to %%USERPROFILE%%/.openclaw/openclaw.json.")
    return parser


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    args = make_arg_parser().parse_args()
    input_path = Path(args.input)
    output_path = Path(args.output) if args.output else input_path.with_name("comment_apply_result.json")
    state_path = Path(args.state_file) if args.state_file else input_path.with_name("comment_apply_state.json")
    config_path = Path(args.config) if args.config else None

    plan = read_json(input_path)
    started_at = now_iso()
    result = apply_comments(
        plan,
        dry_run=args.dry_run,
        sleep_seconds=args.sleep_seconds,
        state_path=state_path,
        config_path=config_path,
    )
    result["started_at"] = started_at
    result["finished_at"] = now_iso()
    write_json(output_path, result)
    print(json.dumps({"ok": True, "output": str(output_path), "summary": result["summary"], "dry_run": args.dry_run}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
