#!/usr/bin/env python3
"""规则同步脚本 - 简化版
- 默认只更新项目规则（从飞书文档/表格拉取）
- 加 --extract-official 才更新平台规则 + 行业规则
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SKILL_DIR = Path(__file__).resolve().parent.parent
RULES_DIR = SKILL_DIR / "rules"
GENERAL_CHECKPOINTS_FILE = RULES_DIR / "official" / "general_checkpoints.json"

DEFAULT_PROJECT_SOURCES = {
    "猿辅导": {
        "slug": "yuanfudao",
        "industry": "教育",
        "source_url": "https://rcn1fwxrrq16.feishu.cn/wiki/YWtwwCoXLiRSTVkI9hgcrxKnnGf",
    }
}

OFFICIAL_DOCS = {
    "general": {
        "name": "内容审核规则总则",
        "shortcut_id": "8dc5bd9c45c9a90cb9912f3400d43f92",
        "source_url": "https://ad.xiaohongshu.com/next_help/docs/8dc5bd9c45c9a90cb9912f3400d43f92",
    },
    "education": {
        "name": "教育行业规则",
        "shortcut_id": "1c36a1c68aa181fa420af9bf705864ce",
        "source_url": "https://ad.xiaohongshu.com/next_help/docs/1c36a1c68aa181fa420af9bf705864ce",
    },
}

OFFICIAL_SOURCE_URLS = {
    "general": "https://ad.xiaohongshu.com/next_help/docs/8dc5bd9c45c9a90cb9912f3400d43f92",
    "education": "https://ad.xiaohongshu.com/next_help/docs/1c36a1c68aa181fa420af9bf705864ce",
}

HEADER_ALIASES = {
    "学段": "industry",
    "分类": "category",
    "卡审/规避词": "trigger_terms",
    "卡审词/规避词": "trigger_terms",
    "卡审词": "trigger_terms",
    "规避词": "trigger_terms",
    "解决方案": "solution",
    "软性方案": "soft_solution",
    "表述参考": "phrasing_examples",
    "备注": "notes",
}


@dataclass
class ProjectContext:
    project: str
    industry: str
    source_url: str


# ── 工具函数 ──

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_json(path: Path, default: Any | None = None) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def default_official_source_url(doc_key: str) -> str:
    return OFFICIAL_SOURCE_URLS.get(doc_key, "")


def slugify(value: str) -> str:
    value = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff]+", "-", value.strip().lower())
    return value.strip("-") or "item"


def normalize_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def parse_datetime_millis(value: int | None) -> str | None:
    if not value:
        return None
    return datetime.fromtimestamp(value / 1000, tz=timezone.utc).isoformat()


def safe_stringify_cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, dict):
        if value.get("type") == "embed-image":
            return ""
        return normalize_text(" ".join(safe_stringify_cell(item) for item in value.values()))
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, dict) and "text" in item:
                parts.append(str(item.get("text", "")))
            else:
                parts.append(safe_stringify_cell(item))
        return normalize_text("".join(parts))
    return normalize_text(value)


def split_terms(raw: str) -> list[str]:
    text = raw or ""
    if not text:
        return []
    chunks = re.split(r"[\n,，、；;]+", text)
    seen: set[str] = set()
    terms: list[str] = []
    for chunk in chunks:
        item = chunk.strip().strip("""\"'[]()（）""")
        item = re.sub(r"\s+", " ", item)
        if not item or item in {"-", "/", "ok"}:
            continue
        if item not in seen:
            seen.add(item)
            terms.append(item)
    return terms


def extract_quoted_candidates(text: str) -> list[str]:
    return [normalize_text(match) for match in re.findall(r"""["\"]([^"\"]+)["\"]""", text or "")]


def extract_rewrite_candidates(*values: str) -> list[str]:
    raw_candidates: list[str] = []
    for value in values:
        text = normalize_text(value)
        if not text:
            continue
        raw_candidates.extend(extract_quoted_candidates(text))
        raw_candidates.extend(split_terms(text))
    filtered: list[str] = []
    seen: set[str] = set()
    banned = ("不能", "删除", "千万", "修改", "待验证", "请品牌确认", "卡审", "规避", "重发", "不写")
    for candidate in raw_candidates:
        item = candidate.strip("（）。,.!?- ")
        if not item or len(item) > 32:
            continue
        if any(flag in item for flag in banned):
            continue
        if item not in seen:
            seen.add(item)
            filtered.append(item)
    return filtered


def fetch_json(url: str) -> dict[str, Any]:
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json,text/plain,*/*"})
    with urllib.request.urlopen(req, timeout=60) as response:
        return json.load(response)


def parse_xiaohongshu_shortcut_id(source_url: str) -> str:
    parsed = urllib.parse.urlparse(source_url)
    match = re.search(r"/docs/([0-9a-fA-F]+)", parsed.path)
    if match:
        return match.group(1)
    query = urllib.parse.parse_qs(parsed.query)
    shortcut_values = query.get("shortcutId") or query.get("shortcut_id") or []
    if shortcut_values:
        return shortcut_values[0]
    raise RuntimeError(f"Unable to parse Xiaohongshu shortcutId from URL: {source_url}")


def extract_block_text(node: dict[str, Any]) -> str:
    node_type = node.get("type")
    if node_type == "image":
        return ""
    children = node.get("children", [])
    if node_type in {"title", "h1", "h2", "h3", "h4", "paragraph", "bulleted-list"}:
        return normalize_text("".join(child.get("text", "") for child in children if isinstance(child, dict)))
    if node_type == "table":
        rows: list[str] = []
        for row in children:
            row_cells: list[str] = []
            for cell in row.get("children", []):
                row_cells.append(extract_block_text(cell))
            rows.append(" | ".join(filter(None, row_cells)))
        return normalize_text("\n".join(filter(None, rows)))
    texts: list[str] = []
    for child in children:
        if isinstance(child, dict):
            nested = extract_block_text(child)
            if nested:
                texts.append(nested)
    return normalize_text("\n".join(texts))


def parse_official_sections(content: dict[str, Any]) -> list[dict[str, str]]:
    sections: list[dict[str, str]] = []
    headings = {"title": "", "h1": "", "h2": "", "h3": "", "h4": ""}
    active: dict[str, str] | None = None
    for node in content.get("children", []):
        node_type = node.get("type")
        text = extract_block_text(node)
        if node_type == "title":
            headings["title"] = text
            continue
        if node_type in {"h1", "h2", "h3", "h4"}:
            headings[node_type] = text
            lower_levels = {"h1": ["h2", "h3", "h4"], "h2": ["h3", "h4"], "h3": ["h4"], "h4": []}
            for level in lower_levels[node_type]:
                headings[level] = ""
            active = {"path": " / ".join(filter(None, [headings["title"], headings["h1"], headings["h2"], headings["h3"], headings["h4"]])), "text": ""}
            sections.append(active)
            continue
        if not text:
            continue
        if active is None:
            active = {"path": headings["title"] or "untitled", "text": ""}
            sections.append(active)
        active["text"] = text if not active["text"] else active["text"] + "\n" + text
    return sections


def infer_lark_resource(source: str) -> tuple[str, str]:
    parsed = urllib.parse.urlparse(source)
    path = parsed.path
    if "/wiki/" in path:
        return "wiki", path.rstrip("/").split("/")[-1]
    if "/sheets/" in path:
        return "sheet", path.rstrip("/").split("/")[-1]
    if "/docx/" in path or "/doc/" in path:
        return "docx", path.rstrip("/").split("/")[-1]
    return "token", source


def resolve_project_context(project: str, industry: str | None = None, source_url: str | None = None) -> ProjectContext:
    defaults = DEFAULT_PROJECT_SOURCES.get(project, {})
    if not defaults:
        normalized = slugify(project)
        for key, value in DEFAULT_PROJECT_SOURCES.items():
            if slugify(key) == normalized:
                defaults = value
                break
    if not defaults and len(DEFAULT_PROJECT_SOURCES) == 1:
        defaults = next(iter(DEFAULT_PROJECT_SOURCES.values()))
    return ProjectContext(
        project=project,
        industry=industry or defaults.get("industry") or "教育",
        source_url=source_url or defaults.get("source_url") or "",
    )


def project_slug(project: str) -> str:
    defaults = DEFAULT_PROJECT_SOURCES.get(project, {})
    if not defaults:
        normalized = slugify(project)
        for key, value in DEFAULT_PROJECT_SOURCES.items():
            if slugify(key) == normalized:
                defaults = value
                break
    if not defaults and len(DEFAULT_PROJECT_SOURCES) == 1:
        defaults = next(iter(DEFAULT_PROJECT_SOURCES.values()))
    return defaults.get("slug") or slugify(project)


def choose_sheet(info_payload: dict[str, Any]) -> dict[str, Any]:
    sheets = info_payload["data"]["sheets"]["sheets"]
    visible = [sheet for sheet in sheets if not sheet.get("hidden")]
    return visible[0] if visible else sheets[0]


# ── lark-cli 调用 ──

def extract_json_blob(output: str) -> dict[str, Any]:
    start = output.find("{")
    end = output.rfind("}")
    if start == -1 or end == -1:
        raise RuntimeError(f"Unable to parse JSON from lark-cli output: {output}")
    return json.loads(output[start : end + 1])


def run_lark_json(args: list[str]) -> dict[str, Any]:
    lark_executable = shutil.which("lark-cli.cmd") or shutil.which("lark-cli") or "lark-cli"
    command = [lark_executable, *args]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
    combined = (result.stdout or "") + "\n" + (result.stderr or "")
    payload = extract_json_blob(combined)
    if not payload.get("ok", False):
        raise RuntimeError(payload.get("error", {}).get("message", "Unknown lark-cli error"))
    return payload


# ── 项目规则解析 ──

def parse_sheet_entries(values: list[list[Any]], context: ProjectContext, sheet_title: str, sheet_id: str) -> list[dict[str, Any]]:
    header_row_idx = None
    mapping: dict[int, str] = {}
    for idx, row in enumerate(values[:10]):
        headers = [safe_stringify_cell(cell) for cell in row]
        if "卡审/规避词" in headers and "解决方案" in headers:
            header_row_idx = idx
            for col_idx, header in enumerate(headers):
                if header in HEADER_ALIASES:
                    mapping[col_idx] = HEADER_ALIASES[header]
            break
    if header_row_idx is None:
        raise RuntimeError("Could not locate the project sheet header row.")
    entries: list[dict[str, Any]] = []
    for row_idx, row in enumerate(values[header_row_idx + 1 :], start=header_row_idx + 2):
        parsed = {field: "" for field in HEADER_ALIASES.values()}
        for col_idx, field in mapping.items():
            if col_idx < len(row):
                parsed[field] = safe_stringify_cell(row[col_idx])
        trigger_text = parsed["trigger_terms"]
        trigger_terms = split_terms(trigger_text)
        if not trigger_terms:
            continue
        entries.append({
            "id": f"{slugify(context.project)}-{sheet_id}-r{row_idx}",
            "source": context.project,
            "category": parsed["category"] or "未分类",
            "trigger_terms": trigger_terms,
            "patterns": [re.escape(term) for term in trigger_terms if term],
            "solution": parsed["solution"],
            "soft_solution": parsed["soft_solution"],
            "phrasing_examples": [c for c in split_terms(parsed["phrasing_examples"]) if len(c) >= 2],
            "rewrite_candidates": extract_rewrite_candidates(parsed["solution"], parsed["soft_solution"], parsed["phrasing_examples"]),
            "reason": parsed["notes"] or f"项目规则命中：{parsed['category']}",
            "evidence": {"source_row": row_idx, "source_sheet": sheet_title},
            "updated_at": now_iso(),
        })
    return entries


def parse_markdown_tables(markdown: str, context: ProjectContext) -> list[dict[str, Any]]:
    lines = markdown.splitlines()
    tables: list[list[str]] = []
    current: list[str] = []
    for line in lines:
        if line.strip().startswith("|") and line.strip().endswith("|"):
            current.append(line)
        elif current:
            tables.append(current)
            current = []
    if current:
        tables.append(current)
    entries: list[dict[str, Any]] = []
    for table in tables:
        rows = [[cell.strip() for cell in row.strip().strip("|").split("|")] for row in table]
        if len(rows) < 3:
            continue
        headers = rows[0]
        mapping = {idx: HEADER_ALIASES[header] for idx, header in enumerate(headers) if header in HEADER_ALIASES}
        if "trigger_terms" not in mapping.values():
            continue
        trigger_idx = next(idx for idx, field in mapping.items() if field == "trigger_terms")
        for row_idx, row in enumerate(rows[2:], start=3):
            trigger_text = row[trigger_idx] if trigger_idx < len(row) else ""
            terms = split_terms(trigger_text)
            if not terms:
                continue
            payload = {field: "" for field in HEADER_ALIASES.values()}
            for idx, field in mapping.items():
                if idx < len(row):
                    payload[field] = normalize_text(row[idx])
            entries.append({
                "id": f"{slugify(context.project)}-docx-r{row_idx}",
                "source": context.project,
                "category": payload["category"] or "未分类",
                "trigger_terms": terms,
                "patterns": [re.escape(term) for term in terms],
                "solution": payload["solution"],
                "soft_solution": payload["soft_solution"],
                "phrasing_examples": split_terms(payload["phrasing_examples"]),
                "rewrite_candidates": extract_rewrite_candidates(payload["solution"], payload["soft_solution"], payload["phrasing_examples"]),
                "reason": payload["notes"] or f"项目规则命中：{payload['category']}",
                "evidence": {"section": f"markdown-table-row-{row_idx}", "source_row": row_idx},
                "updated_at": now_iso(),
            })
    return entries


def fetch_sheet_entries(token: str, context: ProjectContext) -> dict[str, Any]:
    info = run_lark_json(["sheets", "+info", "--spreadsheet-token", token, "--as", "user"])
    sheet = choose_sheet(info)
    read_payload = run_lark_json(["sheets", "+read", "--spreadsheet-token", token, "--sheet-id", sheet["sheet_id"], "--range", f"{sheet['sheet_id']}!A1:H500", "--as", "user"])
    entries = parse_sheet_entries(read_payload["data"]["valueRange"].get("values", []), context, sheet["title"], sheet["sheet_id"])
    return {
        "source": {"name": context.project, "industry": context.industry, "source_url": context.source_url, "updated_at": now_iso(), "spreadsheet_token": token, "sheet_id": sheet["sheet_id"], "sheet_title": sheet["title"]},
        "entries": entries,
    }


def fetch_docx_entries(token_or_url: str, context: ProjectContext) -> dict[str, Any]:
    payload = run_lark_json(["docs", "+fetch", "--api-version", "v2", "--doc", token_or_url, "--doc-format", "markdown"])
    entries = parse_markdown_tables(payload["data"]["document"]["content"], context)
    return {
        "source": {"name": context.project, "industry": context.industry, "source_url": context.source_url, "updated_at": now_iso(), "doc_token": token_or_url},
        "entries": entries,
    }


def fetch_project_rule_payload(project: str, industry: str, source_url: str | None = None) -> dict[str, Any]:
    context = resolve_project_context(project, industry, source_url)
    resource_type, token = infer_lark_resource(context.source_url)
    if resource_type == "wiki":
        node = run_lark_json(["wiki", "+node-get", "--node-token", context.source_url, "--as", "user"])
        obj_type = node["data"]["obj_type"]
        obj_token = node["data"]["obj_token"]
        if obj_type == "sheet":
            payload = fetch_sheet_entries(obj_token, context)
        elif obj_type in {"docx", "doc"}:
            payload = fetch_docx_entries(context.source_url, context)
        else:
            raise RuntimeError(f"Unsupported wiki-backed resource type: {obj_type}")
    elif resource_type == "sheet":
        payload = fetch_sheet_entries(token, context)
    elif resource_type == "docx":
        payload = fetch_docx_entries(context.source_url, context)
    else:
        raise RuntimeError(f"Unsupported project rule source: {context.source_url}")
    payload["entries"] = [assign_checkpoint_metadata(entry, idx + 1) for idx, entry in enumerate(payload.get("entries", []))]
    return payload


# ── 平台/行业规则解析 ──

def fetch_official_rule_payload(doc_key: str, source_url: str | None = None) -> dict[str, Any]:
    resolved_source_url = source_url or str(OFFICIAL_DOCS.get(doc_key, {}).get("source_url", ""))
    shortcut_id = parse_xiaohongshu_shortcut_id(resolved_source_url)
    endpoint = f"https://ad.xiaohongshu.com/api/light/help/doc/content?shortcutId={shortcut_id}"
    payload = fetch_json(endpoint)
    result = payload["data"]["result"]
    content = json.loads(result["content"])
    sections = parse_official_sections(content)
    updated_at = parse_datetime_millis(result.get("updateTime"))
    entries = build_official_entries(doc_key, sections, updated_at)
    return {
        "source": {"name": result["title"], "shortcut_id": shortcut_id, "endpoint": endpoint, "source_url": resolved_source_url, "updated_at": updated_at},
        "sections": sections,
        "entries": entries,
    }


def infer_examples(entry: dict[str, Any]) -> dict[str, list[str]]:
    examples = entry.get("examples")
    if isinstance(examples, dict):
        return {"bad": examples.get("bad", [])[:2], "good": examples.get("good", [])[:1]}
    bad = (entry.get("phrasing_examples") or [])[:2] or (entry.get("trigger_terms") or [])[:2]
    good = (entry.get("rewrite_candidates") or [])[:1]
    return {"bad": bad, "good": good}


def infer_prompt_rule(entry: dict[str, Any]) -> str:
    prompt_rule = normalize_text(entry.get("prompt_rule", ""))
    if prompt_rule:
        return prompt_rule
    terms = " / ".join((entry.get("trigger_terms") or [])[:6])
    reason = normalize_text(entry.get("reason", ""))
    if terms:
        return f"关注{entry.get('checkpoint_name') or entry.get('category')}相关表达，如：{terms}。{reason}"
    return reason or f"关注{entry.get('checkpoint_name') or entry.get('category')}相关风险"


def relevant_general_sections(sections: list[dict[str, str]]) -> list[dict[str, str]]:
    keep: list[dict[str, str]] = []
    for section in sections:
        path = normalize_text(section.get("path", ""))
        text = normalize_text(section.get("text", ""))
        if not text:
            continue
        if "/ 聚光平台素材规则风险解读 / 二、准入&资质要求" in path or "/ 聚光平台素材规则风险解读 / 三、通用素材审核要求" in path:
            keep.append(section)
    return keep


def infer_general_group_name(path: str) -> str:
    normalized = normalize_text(path)
    rules = [
        (("准入&资质要求", "准入"), "准入资质"), (("第三方商标", "肖像授权", "合作授权", "IP"), "授权资质"),
        (("资质", "有效期", "行业资质", "主体资质"), "准入资质"), (("国家利益", "政治安全", "国家统一"), "国家利益"),
        (("社会稳定", "暴乱", "恐怖主义"), "社会稳定"), (("国家、领导人、军警、公职人员", "国家象征"), "国家机关元素"),
        (("国家事件", "国家政策", "社会热点", "315"), "社会热点营销"), (("色情产品", "两性低俗", "性暗示"), "色情低俗"),
        (("封建迷信", "改运", "开光", "量子"), "封建迷信"), (("专利", "专利号"), "专利宣传"),
        (("承诺保证效果", "保证性承诺"), "效果承诺"), (("夸张用语", "绝对化用语"), "夸张绝对化"),
        (("泄露个人隐私", "身份证号"), "隐私泄露"), (("未成年人不当营销", "未成年人"), "未成年人不当营销"),
        (("价值观导向不佳", "主流价值观"), "价值观导向不佳"), (("引流至站外", "第三方平台"), "站外引流"),
        (("诱导用户产生互动", "点赞送"), "互动诱导"), (("活动宣传", "奖品", "秒杀"), "活动信息不明确"),
        (("文字、语义", "错别字", "繁体字"), "用语不规范"), (("高危体育项目", "人身安全", "警示语"), "高危项目警示语"),
        (("画质不佳", "黑屏", "花屏"), "画质不佳"), (("夸张的标题", "标题不相符"), "标题党"),
        (("观感不适", "恐怖", "血腥"), "不适画面"), (("前后需保持一致",), "前后不一致"),
        (("制造大众焦虑", "教育焦虑"), "制造焦虑"), (("前后使用效果对比",), "效果对比"),
        (("权威机构", "认证", "CCTV"), "权威背书"),
    ]
    for keywords, label in rules:
        if any(keyword in normalized for keyword in keywords):
            return label
    parts = [part.strip() for part in normalized.split("/") if part.strip()]
    return parts[-1] if parts else "平台规则"


def infer_general_trigger_terms(text: str) -> list[str]:
    candidates: list[str] = []
    candidates.extend(extract_quoted_candidates(text))
    for match in re.finditer(r"(不得[^；。\n|]{2,28})", text):
        candidates.append(match.group(1))
    for match in re.finditer(r"(禁止[^；。\n|]{2,28})", text):
        candidates.append(match.group(1))
    common_terms = re.findall(r"[A-Za-z0-9\u4e00-\u9fff#%+]{2,16}", text)
    candidates.extend(common_terms[:30])
    filtered: list[str] = []
    seen: set[str] = set()
    stop = {"内容", "规则", "物料", "广告", "推广", "例如", "不得", "禁止", "说明", "要求", "场景", "核心", "平台"}
    for raw in candidates:
        item = normalize_text(raw).strip("（）【】[]\"'；;，,。.!?")
        if not item or item in stop or len(item) < 2 or len(item) > 20:
            continue
        if item not in seen:
            seen.add(item)
            filtered.append(item)
        if len(filtered) >= 8:
            break
    return filtered


def normalize_general_detail_name(path: str, text: str) -> str:
    parts = [part.strip() for part in normalize_text(path).split("/") if part.strip()]
    tail = parts[-1] if parts else "平台规则"
    tail = re.sub(r"^\d+(\.\d+)*", "", tail).strip("（）,.!?- ")
    if tail:
        return tail[:28]
    text = normalize_text(text)
    if text.startswith("不得"):
        return text[:20]
    return "平台规则"


def is_actionable_general_entry(category: str, checkpoint_name: str, trigger_terms: list[str]) -> bool:
    generic_names = {"一、业务总览", "二、准入&资质要求", "三、通用素材审核要求", "聚光平台禁止推广目录", "聚光平台素材规则风险解读", "平台规则", "总览", "禁投品类"}
    if checkpoint_name in generic_names:
        return False
    if category in {"一、业务总览", "三、通用素材审核要求", "禁投品类"} and len(trigger_terms) <= 2:
        return False
    return True


def load_general_checkpoint_entries() -> list[dict[str, Any]]:
    payload = read_json(GENERAL_CHECKPOINTS_FILE, {"categories": []})
    entries: list[dict[str, Any]] = []
    for category in payload.get("categories", []):
        for checkpoint in category.get("checkpoints", []):
            entry = {
                "id": checkpoint["id"], "source": OFFICIAL_DOCS["general"]["name"],
                "source_type": "official_platform" if category["id"] != "E" else "official_blacklist",
                "industry": None, "project": None,
                "category": category.get("name", checkpoint.get("name")),
                "trigger_terms": checkpoint.get("trigger_examples", []) or checkpoint.get("examples", {}).get("bad", []),
                "patterns": checkpoint.get("match_patterns", []),
                "solution": "", "soft_solution": "",
                "phrasing_examples": checkpoint.get("examples", {}).get("bad", []),
                "rewrite_candidates": checkpoint.get("examples", {}).get("good", []),
                "reason": checkpoint.get("description", ""),
                "prompt_rule": checkpoint.get("prompt_rule", ""),
                "examples": checkpoint.get("examples", {}),
                "evidence": {"section": category.get("name", "")},
                "updated_at": payload.get("meta", {}).get("updated_at"),
                "checkpoint_id": checkpoint["id"],
                "checkpoint_name": checkpoint.get("name", checkpoint["id"]),
                "checkpoint_group": category["id"],
                "local_only": category["id"] == "E",
                "llm_enabled": category["id"] != "E",
            }
            entries.append(assign_checkpoint_metadata(entry))
    return entries


def build_general_detail_entries(sections: list[dict[str, str]], update_time: str | None) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for section in relevant_general_sections(sections):
        path = normalize_text(section.get("path", ""))
        text = normalize_text(section.get("text", ""))
        trigger_terms = infer_general_trigger_terms(text)
        if not trigger_terms:
            continue
        category = infer_general_group_name(path)
        checkpoint_name = normalize_general_detail_name(path, text)
        if not is_actionable_general_entry(category, checkpoint_name, trigger_terms):
            continue
        entry = {
            "id": f"general-detail-{len(entries) + 1}",
            "source": OFFICIAL_DOCS["general"]["name"], "source_type": "official_platform",
            "industry": None, "project": None, "category": category,
            "trigger_terms": trigger_terms,
            "patterns": [re.escape(term) for term in trigger_terms],
            "solution": "", "soft_solution": "",
            "phrasing_examples": trigger_terms[:3], "rewrite_candidates": [],
            "reason": text[:160],
            "prompt_rule": f"关注{checkpoint_name}相关表达，如：{' / '.join(trigger_terms[:6])}。",
            "examples": {"bad": trigger_terms[:2], "good": []},
            "evidence": {"shortcut_id": OFFICIAL_DOCS["general"]["shortcut_id"], "section": path, "excerpt": text[:400]},
            "updated_at": update_time, "checkpoint_name": checkpoint_name, "checkpoint_group": category,
            "local_only": False, "llm_enabled": True,
        }
        entries.append(assign_checkpoint_metadata(entry, len(entries) + 1))
    curated = [entry for entry in load_general_checkpoint_entries() if not entry.get("local_only")]
    merged: list[dict[str, Any]] = []
    seen_keys: set[tuple[str, str]] = set()
    for entry in curated + entries:
        key = (str(entry.get("checkpoint_name", "")), str(entry.get("category", "")))
        if key in seen_keys:
            continue
        seen_keys.add(key)
        merged.append(entry)
    return merged


# ── 教育行业规则 ──

def relevant_education_sections(sections: list[dict[str, str]]) -> list[dict[str, str]]:
    keep: list[dict[str, str]] = []
    for section in sections:
        path = normalize_text(section.get("path", ""))
        text = normalize_text(section.get("text", ""))
        if not text:
            continue
        if "/ 一、内容涵盖 /" in path or "/ 二、高频违规&产品类型 /" in path:
            keep.append(section)
    return keep


def infer_education_group_name(path: str) -> str:
    parts = [part.strip() for part in path.split("/") if part.strip()]
    raw = parts[-1] if parts else "教育行业规则"
    normalized = normalize_text(raw)
    rules = [
        (("考试作弊", "作弊服务"), "考试作弊"), (("学术类代写", "代写服务"), "学术代写"),
        (("学科内容培训", "校外培训", "上门家教"), "学科培训"), (("承诺保证", "包教包会"), "结果承诺"),
        (("包就业", "保就业"), "就业承诺"), (("升学、录取、毕业", "保证录取"), "升学录取承诺"),
        (("升学率", "通过率"), "数据结果暗示"), (("专业人士、受益者", "受益者"), "受益者背书"),
        (("专业人士：", "官方指定合作办学", "命题组"), "专业人士背书"), (("虚假宣传",), "虚假宣传"),
        (("不正确的价值观", "考纲变化", "自学考试即将取消"), "教育焦虑与政策谣言"),
        (("纹绣培训", "国学养生", "运动养生"), "特殊产品类型"),
    ]
    for keywords, label in rules:
        if any(keyword in normalized for keyword in keywords):
            return label
    return raw


def is_noisy_education_candidate(value: str) -> bool:
    candidate = normalize_text(value).strip("（）()[]\"'，,。.;；:：")
    if not candidate or len(candidate) < 3 or len(candidate) > 48:
        return True
    exact_noise = {"核心管控标准", "常见违规场景", "规则解读", "案例解读", "受益者", "受益者：", "专业人士", "专业人士：", "案例一", "案例二", "案例三", "案例四", "核心", "1", "2", "3", "4"}
    if candidate in exact_noise:
        return True
    contains_noise = ("核心管控标准", "常见违规场景", "规则解读", "案例解读", "教育广告", "案例一", "案例二", "案例三", "案例四", "不得对于接受了广告主的培训服务后", "广告不得含有虚假或者引人误解的内容", "case举例")
    if any(flag in candidate for flag in contains_noise):
        return True
    if re.fullmatch(r"[\d\W_]+", candidate):
        return True
    return False


def dedupe_clean_candidates(candidates: list[str], limit: int = 8) -> list[str]:
    seen: set[str] = set()
    filtered: list[str] = []
    for raw in candidates:
        candidate = normalize_text(raw).strip("（）()[]\"'，,。.;；:：")
        if is_noisy_education_candidate(candidate):
            continue
        if candidate not in seen:
            seen.add(candidate)
            filtered.append(candidate)
        if len(filtered) >= limit:
            break
    return filtered


def normalize_education_detail_name(group_name: str, candidate: str) -> str:
    text = normalize_text(candidate)
    haystack = f"{group_name} {text}"
    rules = [
        (("考试作弊服务", "提供作弊服务"), "提供考试作弊服务"), (("考试答案", "作弊器材"), "售卖考试答案/作弊器材"),
        (("不学习", "仅花钱", "通过考试"), "暗示不学习也能通过考试"), (("代写", "代做", "替写"), "明示代写代做服务"),
        (("校外培训", "学科成绩", "升学为目的"), "宣传校外学科培训"), (("家长规划课", "变相发布学科教育"), "借家长规划课变相投放学科培训"),
        (("提高多少分", "提分"), "承诺提分"), (("包教包会", "学不会"), "包教包会"),
        (("涨薪40%", "高回报", "高薪", "财富自由"), "承诺高薪高回报"), (("包就业", "保就业", "定向就业"), "承诺就业结果"),
        (("保证录取", "保证升学", "保录"), "承诺录取/升学"), (("升学率", "通过率"), "用升学率/通过率数据作结果暗示"),
        (("受益者", "真实学习成果", "成绩单"), "使用受益者成果背书"), (("官方指定合作办学", "命题组", "阅卷组成员"), "使用专业人士/官方身份背书"),
        (("自学考试即将取消", "考纲变化", "考试难度加大"), "编造政策变化"), (("焦虑", "落后", "资源稀缺"), "制造教育焦虑"),
        (("国学养生", "玄学", "封建迷信"), "宣传封建迷信内容"), (("运动养生", "医疗功效", "保健功效"), "宣传医疗/保健功效"),
    ]
    for keywords, label in rules:
        if any(keyword in haystack for keyword in keywords):
            return label
    for _q in ['\u201c', '\u201d', '"', "'"]:
        text = text.replace(_q, '')
    text = re.sub(r"[，。；;].*$", "", text).strip()
    return text[:24] if text else group_name[:24]


def infer_education_detail_candidates(text: str) -> list[str]:
    candidates: list[str] = []
    text = normalize_text(text)
    for match in re.finditer(r"(不得[^；。】]{2,40})", text):
        candidates.append(match.group(1))
    for match in re.finditer(r"(禁止[^；。】]{2,40})", text):
        candidates.append(match.group(1))
    for match in re.finditer(r"(保证[^；。】]{2,32})", text):
        candidates.append(match.group(1))
    for match in re.finditer(r"(包教包会|包就业|保就业|保证录取|保证升学|高薪赚钱|高回报|虚假宣传|自学考试即将取消|考纲变化|考试难度加大)", text):
        candidates.append(match.group(1))
    for phrase in extract_quoted_candidates(text):
        if 3 <= len(phrase) <= 24:
            candidates.append(phrase)
    return dedupe_clean_candidates(candidates, limit=10)


def infer_education_trigger_terms(text: str) -> list[str]:
    text = normalize_text(text)
    candidates: list[str] = []
    candidates.extend(extract_quoted_candidates(text))
    for match in re.finditer(r"(包教包会|包就业|保就业|保证录取|保证升学|高薪赚钱|高回报|涨薪40%|升学率|通过率|官方指定合作办学|自学考试即将取消|考纲变化|考试难度加大)", text):
        candidates.append(match.group(1))
    for match in re.finditer(r"(不得[^；。】]{2,24})", text):
        candidates.append(match.group(1))
    if not candidates:
        candidates = re.findall(r"[A-Za-z0-9\u4e00-\u9fff\+#%]+", text)
    return dedupe_clean_candidates(candidates, limit=8)


def build_education_detail_entries(sections: list[dict[str, str]], update_time: str | None) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    seen_names_by_group: dict[str, set[str]] = {}
    for section in relevant_education_sections(sections):
        path = normalize_text(section.get("path", ""))
        text = normalize_text(section.get("text", ""))
        group_name = infer_education_group_name(path)
        detail_candidates = infer_education_detail_candidates(text) or [group_name]
        base_terms = infer_education_trigger_terms(text)
        for detail_name in detail_candidates:
            normalized_name = normalize_education_detail_name(group_name, detail_name)
            bucket = seen_names_by_group.setdefault(group_name, set())
            if normalized_name in bucket:
                continue
            bucket.add(normalized_name)
            scoped_terms = [term for term in base_terms if term in detail_name or detail_name in term]
            trigger_terms = dedupe_clean_candidates(scoped_terms[:6] or base_terms[:6], limit=6) or split_terms(detail_name)[:4] or [detail_name[:12]]
            entry = {
                "id": f"education-detail-{len(entries) + 1}",
                "source": OFFICIAL_DOCS["education"]["name"], "source_type": "official_industry",
                "industry": "教育", "project": None, "category": group_name,
                "trigger_terms": trigger_terms,
                "patterns": [re.escape(term) for term in trigger_terms],
                "solution": "", "soft_solution": "", "phrasing_examples": [], "rewrite_candidates": [],
                "reason": normalize_text(text[:160]) or f"教育行业规则：{detail_name}",
                "prompt_rule": f"关注{normalized_name}相关表达，如：{' / '.join(trigger_terms[:6])}。",
                "examples": {"bad": trigger_terms[:2], "good": []},
                "evidence": {"shortcut_id": OFFICIAL_DOCS["education"]["shortcut_id"], "section": path, "excerpt": text[:400]},
                "updated_at": update_time, "checkpoint_name": normalized_name, "checkpoint_group": group_name,
            }
            entries.append(assign_checkpoint_metadata(entry, len(entries) + 1))
    return entries


def build_official_entries(doc_key: str, sections: list[dict[str, str]], update_time: str | None) -> list[dict[str, Any]]:
    if doc_key == "general":
        return build_general_detail_entries(sections, update_time)
    return build_education_detail_entries(sections, update_time)


# ── checkpoint 元数据 ──

def assign_checkpoint_metadata(entry: dict[str, Any], ordinal: int | None = None) -> dict[str, Any]:
    assigned = dict(entry)
    source_type = assigned.get("source_type")
    source = assigned.get("source", "")
    original_id = str(assigned.get("id", ""))
    checkpoint_id = assigned.get("checkpoint_id", "")
    checkpoint_name = assigned.get("checkpoint_name", "")
    checkpoint_group = assigned.get("checkpoint_group", "")
    if source_type == "official_platform":
        checkpoint_id = checkpoint_id or original_id or f"GEN-{ordinal or 0}"
        checkpoint_name = checkpoint_name or assigned.get("name") or assigned.get("category") or checkpoint_id
        checkpoint_group = checkpoint_group or re.sub(r"\d+$", "", checkpoint_id) or "GEN"
    elif source_type == "official_industry":
        checkpoint_id = checkpoint_id or f"IND-{ordinal or 0}"
        checkpoint_name = checkpoint_name or assigned.get("category") or checkpoint_id
        checkpoint_group = checkpoint_group or assigned.get("category") or "IND"
    elif source_type == "project_rule":
        slug = project_slug(assigned.get("project") or source or "project").upper()
        checkpoint_id = checkpoint_id or re.sub(r"[^A-Z0-9-]+", "-", f"{slug}-{original_id.upper()}").strip("-")
        first_term = (assigned.get("trigger_terms") or ["规则"])[:1][0]
        checkpoint_name = checkpoint_name or f"{assigned.get('category', '项目规则')} / {first_term}"
        checkpoint_group = checkpoint_group or slug
    elif source_type == "official_blacklist":
        checkpoint_id = checkpoint_id or original_id
        checkpoint_name = checkpoint_name or assigned.get("name") or assigned.get("category") or checkpoint_id
        checkpoint_group = checkpoint_group or "E"
    assigned["checkpoint_id"] = checkpoint_id
    assigned["checkpoint_name"] = checkpoint_name
    assigned["checkpoint_group"] = checkpoint_group
    assigned["prompt_rule"] = infer_prompt_rule(assigned)
    assigned["examples"] = infer_examples(assigned)
    assigned["local_only"] = bool(assigned.get("local_only", False))
    assigned["llm_enabled"] = bool(assigned.get("llm_enabled", not assigned["local_only"]))
    return assigned


# ── 主流程 ──

def rule_payload_summary(path_label: str, payload: dict | None, *, requested: bool, extracted: bool) -> dict:
    data = payload if isinstance(payload, dict) else {}
    source = data.get("source", {}) if isinstance(data, dict) else {}
    entries = data.get("entries", []) if isinstance(data.get("entries", []), list) else []
    status = "extracted" if extracted else ("cached" if entries else "missing")
    return {"path": path_label, "requested": requested, "extracted": extracted, "status": status, "source_url": source.get("source_url", ""), "updated_at": source.get("updated_at"), "entry_count": len(entries)}


def load_or_fetch_official_rule_payload(doc_key: str, refresh: bool = False, source_url: str | None = None) -> dict:
    file_map = {"general": RULES_DIR / "official" / "general.json", "education": RULES_DIR / "official" / "education.json"}
    path = file_map[doc_key]
    cached = read_json(path, {})
    if not refresh:
        return cached if isinstance(cached, dict) else {}
    payload = fetch_official_rule_payload(doc_key, source_url=source_url)
    write_json(path, payload)
    return payload


def sync_rule_cache(
    project: str,
    industry: str,
    source_url: str | None = None,
    *,
    refresh_official: bool = False,
    platform_source_url: str | None = None,
    industry_source_url: str | None = None,
) -> dict:
    project_slug_value = project_slug(project)
    cached_manifest_path = RULES_DIR / "manifest.json"
    cached_project_path = RULES_DIR / "projects" / f"{project_slug_value}.json"
    resolved_context = resolve_project_context(project, industry, source_url)
    resolved_project_source_url = source_url or resolved_context.source_url
    resolved_platform_source_url = platform_source_url or default_official_source_url("general")
    resolved_industry_source_url = industry_source_url or default_official_source_url("education")

    try:
        official_general = load_or_fetch_official_rule_payload("general", refresh=refresh_official, source_url=resolved_platform_source_url)
        official_education = load_or_fetch_official_rule_payload("education", refresh=refresh_official, source_url=resolved_industry_source_url)
        project_payload = fetch_project_rule_payload(project, industry, resolved_project_source_url)
        write_json(cached_project_path, project_payload)

        manifest = {
            "generated_at": now_iso(),
            "project": project,
            "industry": industry,
            "sync_mode": {"project_rules": "refreshed", "official_rules": "extracted" if refresh_official else "cached_only"},
            "files": {
                "official/general.json": {"updated_at": official_general.get("source", {}).get("updated_at"), "entry_count": len(official_general.get("entries", [])), "status": "extracted" if refresh_official else "cached"},
                "official/education.json": {"updated_at": official_education.get("source", {}).get("updated_at"), "entry_count": len(official_education.get("entries", [])), "status": "extracted" if refresh_official else "cached"},
                f"projects/{project_slug_value}.json": {"updated_at": project_payload.get("source", {}).get("updated_at"), "entry_count": len(project_payload.get("entries", [])), "source_url": resolved_project_source_url, "status": "extracted"},
            },
        }
        write_json(cached_manifest_path, manifest)
        return manifest
    except RuntimeError as exc:
        error_msg = str(exc)
        if "scope" in error_msg.lower() or "permission" in error_msg.lower() or "403" in error_msg:
            if cached_manifest_path.exists() and cached_project_path.exists():
                print(f"[WARN] 规则同步权限不足，使用缓存规则: {error_msg}", file=sys.stderr)
                return read_json(cached_manifest_path)
            raise RuntimeError(f"规则同步失败且无缓存可用。原始错误: {error_msg}") from exc
        raise


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="同步规则。默认只更新项目规则；加 --extract-official 更新平台+行业规则。")
    parser.add_argument("--project", default="猿辅导")
    parser.add_argument("--industry", default="教育")
    parser.add_argument("--project-rules-url", dest="project_rules_url")
    parser.add_argument("--platform-rules-url", default=default_official_source_url("general"))
    parser.add_argument("--industry-rules-url", default=default_official_source_url("education"))
    parser.add_argument("--extract-official", action="store_true", help="同时更新平台规则和行业规则")
    return parser


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = make_parser()
    args = parser.parse_args()

    manifest = sync_rule_cache(
        args.project, args.industry, args.project_rules_url,
        refresh_official=args.extract_official,
        platform_source_url=args.platform_rules_url,
        industry_source_url=args.industry_rules_url,
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
