---
name: feishu-xiaolongxia-qa
label: 小红书质检
description: |
  对飞书文档中的小红书笔记进行质检，识别违规词、敏感词、平台规则问题，输出质检报告并可选写入飞书行内评论。
  触发场景：
  - 用户提到「质检」「检查」「审核」「卡审」「违规词检查」等关键词
  - 用户提供飞书文档链接并要求检查笔记内容
  - 用户要求检查小红书笔记是否合规
  - 用户要求写入质检评论到飞书文档
---

# 小红书质检

## 触发规则

当用户提到以下关键词时，必须使用本 skill：
- 「质检」「检查」「审核」「卡审」「违规词检查」
- 提供飞书文档链接并要求检查笔记内容
- 要求检查小红书笔记是否合规
- 要求写入质检评论到飞书文档

## 快速开始

```bash
cd C:\Users\Administrator\.openclaw\workspace\skills\feishu-xiaolongxia-qa\scripts
python -X utf8 simple_qc.py "<飞书文档URL或token>" --project 猿辅导 --industry 教育 --name "笔记名称"
```

## 流程概览

### Step 1：脚本提取内容 + 规则匹配

```bash
cd C:\Users\Administrator\.openclaw\workspace\skills\feishu-xiaolongxia-qa\scripts
python -X utf8 simple_qc.py "<飞书文档URL或token>" --project 猿辅导 --industry 教育 --name "笔记名称"
```

**脚本：** `simple_qc.py`（包含文档解析、内容提取、图片下载、规则匹配）

**输入：**
- 飞书文档 URL 或 doc_token
- `--project` 项目名（默认"猿辅导"）
- `--industry` 行业名（默认"教育"）
- `--name` 输出文件夹名

**输出：**
- `output/{笔记名称}/llm_input.json` — 格式见 `configs/llm_input_schema.json`
- `output/{笔记名称}/images/` — 下载的图片文件

> ⚠️ 中间文件（images/）在质检完成后应删除。

### Step 2：agent OCR 图片

对 `llm_input.json` 中 `images[]` 的**每张图片**，使用 `image` 工具识别图中所有文字。

**⚠️ 必须处理所有图片**：
- 遍历 `images[]` 数组，逐张 OCR
- 如果某张图片 OCR 超时或失败，必须重试，直到成功
- 所有图片都处理完毕后，才能进入 Step 2.5

**输出：** 每张图片的 OCR 文字结果，写入 `output/{笔记名称}/ocr_results.json`

```json
{
  "ocr_results": [
    {
      "note_id": "note-1",
      "position": "封面图",
      "local_path": "output/{笔记名称}/images/cover_xxx.jpg",
      "ocr_text": "图片中识别到的文字..."
    }
  ]
}
```

**检查点**：确认 `ocr_results` 数组长度 = `images[]` 数组长度，否则继续处理剩余图片。

### Step 2.5：合并 OCR 结果 + 规则匹配

```bash
cd C:\Users\Administrator\.openclaw\workspace\skills\feishu-xiaolongxia-qa\scripts
python -X utf8 simple_qc.py "<doc_token>" --ocr-input "../output/{笔记名称}/ocr_results.json" --project 猿辅导 --industry 教育 --name "笔记名称"
```

**输出：** 更新后的 `output/{笔记名称}/llm_input.json`（包含 `ocr_results` + 文本/图片的规则命中）

> ⚠️ 中间文件（ocr_results.json）在质检完成后应删除。

### Step 3：模型自主质检

agent 读取合并后的 `llm_input.json`，按 `configs/qa_prompt.md` 中的流程执行质检。

**输出格式：** 见 `configs/llm_output_schema.json`

**报告格式：** 见 `configs/report_format.md`

### Step 3.5：询问用户是否写入飞书评论

质检报告输出后，**必须询问用户**：

> 要把这份质检报告写入飞书文档的行内评论吗？

- 用户确认写入 → 执行 Step 4
- 用户拒绝 → 流程结束

### Step 4：写入飞书行内评论

用户确认质检报告后，agent 根据质检结果生成 `comment_plan.json`，格式见 `configs/comment_plan_schema.json`。

写入 `output/{笔记名称}/comment_plan.json`，然后执行：

```bash
python -X utf8 apply_comments.py --input "../output/{笔记名称}/comment_plan.json"
```

**输出：** `output/{笔记名称}/comment_apply_result.json` + `comment_apply_state.json`

> ⚠️ 中间文件（comment_apply_result.json、comment_apply_state.json）在质检完成后应删除。

## 规则配置

详见 `configs/rules_config.md`

## 目录结构

```
feishu-xiaolongxia-qa/
├── SKILL.md
├── configs/
│   ├── llm_input_schema.json      # 脚本输出格式定义
│   ├── llm_output_schema.json     # 模型输出格式定义
│   ├── comment_plan_schema.json   # 评论 JSON 格式定义
│   ├── report_format.md           # 质检报告输出格式
│   ├── qa_prompt.md               # 模型质检 Prompt
│   └── rules_config.md            # 规则配置说明
├── scripts/
│   ├── simple_qc.py               # 主入口（文档解析 + 内容提取 + 图片下载 + 规则匹配）
│   ├── sync_rules.py              # 规则同步（从飞书/聚光平台拉取）
│   └── apply_comments.py          # 写入飞书评论
├── rules/
│   ├── projects/
│   │   └── yuanfudao.json         # 猿辅导项目规则（含 missed_words）
│   └── official/
│       ├── general.json           # 平台总则
│       ├── education.json         # 教育行业规则
│       ├── general_checkpoints.json   # 结构化质检点
│       └── education_checkpoints.json # 行业结构化质检点
└── output/
    └── {笔记名称}/
        ├── llm_input.json             # Step 1 脚本输出（永久保留）
        ├── llm_output.json            # Step 3 模型质检结果（永久保留）
        └── comment_plan.json          # Step 4 评论计划（永久保留）
        # 以下中间文件质检完成后删除：
        # images/、ocr_results.json、comment_apply_result.json、comment_apply_state.json
```
