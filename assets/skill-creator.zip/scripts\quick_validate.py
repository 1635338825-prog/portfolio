#!/usr/bin/env python3
"""Skill 快速校验脚本。"""

import re
import sys
from pathlib import Path

import yaml


ALLOWED_KEYS = {"name", "label", "description", "license", "allowed-tools", "metadata"}


def validate_skill(skill_path):
    """校验 Skill 目录的基础结构。"""
    skill_path = Path(skill_path)
    skill_md = skill_path / "SKILL.md"

    if not skill_md.exists():
        return False, "未找到 SKILL.md"

    content = skill_md.read_text(encoding="utf-8")
    if not content.startswith("---"):
        return False, "SKILL.md 缺少 YAML frontmatter"

    match = re.match(r"^---\n(.*?)\n---", content, re.DOTALL)
    if not match:
        return False, "frontmatter 格式不正确"

    try:
        frontmatter = yaml.safe_load(match.group(1))
    except yaml.YAMLError as error:
        return False, f"frontmatter 不是合法 YAML：{error}"

    if not isinstance(frontmatter, dict):
        return False, "frontmatter 必须是 YAML 对象"

    unexpected_keys = set(frontmatter) - ALLOWED_KEYS
    if unexpected_keys:
        keys = ", ".join(sorted(unexpected_keys))
        return False, f"frontmatter 包含不支持的字段：{keys}"

    for key in ("name", "label", "description"):
        if not str(frontmatter.get(key, "")).strip():
            return False, f"缺少必填字段：{key}"

    name = str(frontmatter["name"]).strip()
    if not re.match(r"^[a-z0-9-]+$", name):
        return False, "name 只能使用小写字母、数字和连字符"
    if name.startswith("-") or name.endswith("-") or "--" in name:
        return False, "name 不能以连字符开头或结尾，也不能包含连续连字符"
    if len(name) > 64:
        return False, "name 不能超过 64 个字符"

    description = str(frontmatter["description"]).strip()
    if "<" in description or ">" in description:
        return False, "description 不能包含尖括号"
    if len(description) > 1024:
        return False, "description 不能超过 1024 个字符"

    return True, "Skill 校验通过"


def main():
    if len(sys.argv) != 2:
        print("用法：python quick_validate.py <skill目录>")
        sys.exit(1)

    valid, message = validate_skill(sys.argv[1])
    print(message)
    sys.exit(0 if valid else 1)


if __name__ == "__main__":
    main()
