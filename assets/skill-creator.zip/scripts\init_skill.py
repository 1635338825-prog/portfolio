#!/usr/bin/env python3
"""创建一个中文 Skill 模板。"""

import argparse
import re
import sys
from pathlib import Path


SKILL_TEMPLATE = """---
name: {skill_name}
label: {skill_label}
description: TODO：说明这个 Skill 做什么，以及什么时候应该使用。请写清楚触发场景、任务类型、文件类型或工具范围。
---

# {skill_label}

## 使用目标

TODO：用 1 到 2 句话说明这个 Skill 帮员工解决什么问题。

## 工作流程

1. TODO：第一步
2. TODO：第二步
3. TODO：第三步

## 资源

- 需要详细资料时读取 `references/xxx.md`
- 需要稳定执行时运行 `scripts/xxx.py`
- 需要模板或素材时使用 `assets/`

## 交付检查

- TODO：检查结果是否完整
- TODO：检查格式是否符合要求
- TODO：检查是否可以直接交付
"""


REFERENCE_TEMPLATE = """# 参考资料

把主文件不适合展开的详细说明放在这里，例如业务规则、API 文档、字段说明或复杂流程。
"""


SCRIPT_TEMPLATE = """#!/usr/bin/env python3
\"\"\"示例脚本。按实际任务改写，或删除本文件。\"\"\"


def main():
    print("请把 scripts/example.py 改成真实脚本，或删除它。")


if __name__ == "__main__":
    main()
"""


ASSET_NOTE = """这里放模板、图片、示例数据、字体、图标或其他交付素材。
不需要 assets 时，可以删除整个目录。
"""


def validate_name(skill_name):
    if not re.match(r"^[a-z0-9-]+$", skill_name):
        return "skill-name 只能使用小写字母、数字和连字符"
    if skill_name.startswith("-") or skill_name.endswith("-") or "--" in skill_name:
        return "skill-name 不能以连字符开头或结尾，也不能包含连续连字符"
    if len(skill_name) > 64:
        return "skill-name 不能超过 64 个字符"
    return None


def init_skill(skill_name, output_root, skill_label):
    error = validate_name(skill_name)
    if error:
        print(f"错误：{error}")
        return None

    skill_dir = Path(output_root).resolve() / skill_name
    if skill_dir.exists():
        print(f"错误：Skill 目录已存在：{skill_dir}")
        return None

    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        SKILL_TEMPLATE.format(skill_name=skill_name, skill_label=skill_label),
        encoding="utf-8",
    )

    scripts_dir = skill_dir / "scripts"
    references_dir = skill_dir / "references"
    assets_dir = skill_dir / "assets"
    scripts_dir.mkdir()
    references_dir.mkdir()
    assets_dir.mkdir()

    (scripts_dir / "example.py").write_text(SCRIPT_TEMPLATE, encoding="utf-8")
    (references_dir / "notes.md").write_text(REFERENCE_TEMPLATE, encoding="utf-8")
    (assets_dir / "README.txt").write_text(ASSET_NOTE, encoding="utf-8")

    print(f"已创建 Skill：{skill_dir}")
    print("下一步：编辑 SKILL.md，删除不需要的示例文件，然后运行 quick_validate.py 校验。")
    return skill_dir


def main():
    parser = argparse.ArgumentParser(description="创建一个中文 Skill 模板")
    parser.add_argument("skill_name", help="Skill 名称，例如 report-builder")
    parser.add_argument("--path", required=True, help="Skill 创建到哪个目录下")
    parser.add_argument("--label", required=True, help="中文显示名")
    args = parser.parse_args()

    result = init_skill(args.skill_name, args.path, args.label)
    sys.exit(0 if result else 1)


if __name__ == "__main__":
    main()
