---
name: skill-creator
label: 员工 Skill 创建助手
description: 帮助员工创建、修改和打包内部 Skill。适用于员工想把重复工作流程、工具用法、业务知识、输出规范或自动化脚本沉淀成可复用 Skill，并需要生成 SKILL.md、整理 references/scripts/assets、校验结构或打包交付时使用。
---

# 员工 Skill 创建助手

这个 Skill 用来帮助员工把经验沉淀成可复用的 Skill。重点不是写长文档，而是让另一个 AI 助手在真实任务中知道：

- 什么时候使用这个 Skill
- 应该按什么步骤执行
- 需要读取哪些参考资料
- 可以运行哪些脚本
- 最终应该交付什么

## 基本原则

1. 只保留执行任务必须知道的信息。
2. 把触发条件写进 `description`，不要只写在正文里。
3. 主文件 `SKILL.md` 保持短，详细资料放进 `references/`。
4. 重复、容易出错、需要稳定结果的操作放进 `scripts/`。
5. 模板、图片、样例文件、字体等交付素材放进 `assets/`。

## 标准目录

```text
skill-name/
├── SKILL.md
├── scripts/
├── references/
└── assets/
```

只有 `SKILL.md` 是必需的。其他目录按需要保留，不需要就删除。

## 创建流程

### 1. 先问清楚用途

创建或修改 Skill 前，先明确：

- 这个 Skill 帮员工完成什么任务？
- 用户通常会怎么提出需求？
- 任务是否有固定步骤、工具、文件格式或输出标准？
- 哪些内容应该写在主文件，哪些内容应该放到参考文档或脚本里？

如果信息不足，只问最关键的 1 到 3 个问题。

### 2. 设计 Skill 结构

按任务类型选择结构：

- 固定流程：按步骤写，例如“收集信息 -> 处理数据 -> 生成报告 -> 校验结果”。
- 多种操作：按任务分类写，例如“读取、创建、修改、导出”。
- 规范要求：先写规则，再写示例和检查清单。
- 工具集成：先写使用条件，再写命令、参数和注意事项。

需要更详细的写法时，读取：

- `references/workflows.md`：流程型 Skill 写法
- `references/output-patterns.md`：输出格式和示例写法

### 3. 初始化 Skill

新建 Skill 时优先运行：

```bash
python scripts/init_skill.py my-skill --path ./skills --label "我的 Skill"
```

要求：

- `name` 使用小写字母、数字和连字符，例如 `report-builder`。
- 文件夹名和 `name` 保持一致。
- `label` 使用员工能看懂的中文名称。
- `description` 写清楚功能和触发场景。

### 4. 编写 SKILL.md

`SKILL.md` 建议包含：

```markdown
---
name: skill-name
label: 中文名称
description: 说明这个 Skill 做什么，以及什么时候应该使用。
---

# 中文名称

## 使用目标

一句话说明这个 Skill 解决什么问题。

## 工作流程

1. 第一步
2. 第二步
3. 第三步

## 资源

- 需要详细资料时读取 `references/xxx.md`
- 需要稳定执行时运行 `scripts/xxx.py`

## 交付检查

- 检查项 1
- 检查项 2
```

写作要求：

- 用命令式表达，例如“读取”“生成”“校验”。
- 不写泛泛而谈的背景介绍。
- 不重复 AI 已经知道的常识。
- 有固定格式时给模板，有质量要求时给示例。
- 引用资源文件时说明“什么时候读取它”。

### 5. 整理资源

`scripts/` 适合放：

- 数据处理脚本
- 文件转换脚本
- API 调用脚本
- 校验或打包脚本

`references/` 适合放：

- 业务规则
- API 文档
- 数据表结构
- 输出格式说明
- 复杂流程说明

`assets/` 适合放：

- 文档模板
- PPT 模板
- 图片和图标
- 示例数据
- 前端或代码模板

### 6. 校验和打包

修改完成后运行：

```bash
python scripts/quick_validate.py .
```

需要交付压缩包时运行：

```bash
python scripts/package_skill.py . ./dist
```

打包前必须确认：

- `SKILL.md` 有合法 frontmatter。
- `name`、`label`、`description` 都已填写。
- 不需要的示例文件已经删除。
- 资源文件都能被正文正确引用。
- 脚本可以在当前环境正常运行。

## 迭代方式

员工实际使用后，如果发现 AI 助手执行不稳定，优先检查：

1. 触发条件是否写进了 `description`。
2. 流程步骤是否太抽象。
3. 输出格式是否缺模板或示例。
4. 关键资料是否应该移到 `references/`。
5. 重复操作是否应该改成脚本。
