#!/usr/bin/env python3
"""把 Skill 目录打包成 .skill 文件。"""

import argparse
import sys
import zipfile
from pathlib import Path

from quick_validate import validate_skill


def package_skill(skill_path, output_dir=None):
    """校验并打包 Skill。"""
    skill_path = Path(skill_path).resolve()

    if not skill_path.exists():
        print(f"错误：Skill 目录不存在：{skill_path}")
        return None
    if not skill_path.is_dir():
        print(f"错误：路径不是目录：{skill_path}")
        return None
    if not (skill_path / "SKILL.md").exists():
        print(f"错误：目录中缺少 SKILL.md：{skill_path}")
        return None

    print("正在校验 Skill...")
    valid, message = validate_skill(skill_path)
    if not valid:
        print(f"校验失败：{message}")
        return None
    print(message)

    output_path = Path(output_dir).resolve() if output_dir else Path.cwd()
    output_path.mkdir(parents=True, exist_ok=True)
    package_path = output_path / f"{skill_path.name}.skill"

    try:
        with zipfile.ZipFile(package_path, "w", zipfile.ZIP_DEFLATED) as archive:
            for file_path in skill_path.rglob("*"):
                if not file_path.is_file():
                    continue
                if "__pycache__" in file_path.parts or file_path.suffix == ".pyc":
                    continue

                archive_name = file_path.relative_to(skill_path.parent)
                archive.write(file_path, archive_name)
                print(f"已加入：{archive_name}")
    except Exception as error:
        print(f"打包失败：{error}")
        return None

    print(f"打包完成：{package_path}")
    return package_path


def main():
    parser = argparse.ArgumentParser(description="把 Skill 目录打包成 .skill 文件")
    parser.add_argument("skill_path", help="Skill 目录路径")
    parser.add_argument("output_dir", nargs="?", help="输出目录，默认当前目录")
    args = parser.parse_args()

    result = package_skill(args.skill_path, args.output_dir)
    sys.exit(0 if result else 1)


if __name__ == "__main__":
    main()
