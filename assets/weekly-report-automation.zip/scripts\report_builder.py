#!/usr/bin/env python3
"""本地周报生成器。"""

import csv
import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "output"


SAMPLE_ROWS = [
    {
        "account_group": "低客单",
        "placement": "搜索",
        "content_type": "达人内容",
        "spend": 1280,
        "impressions": 42000,
        "clicks": 1260,
        "conversions": 84,
    },
    {
        "account_group": "中客单",
        "placement": "信息流",
        "content_type": "品牌内容",
        "spend": 2360,
        "impressions": 68000,
        "clicks": 1710,
        "conversions": 96,
    },
    {
        "account_group": "高客单",
        "placement": "全域",
        "content_type": "达人内容",
        "spend": 980,
        "impressions": 21000,
        "clicks": 460,
        "conversions": 31,
    },
]


def load_config(config_path):
    return json.loads(Path(config_path).read_text(encoding="utf-8"))


def load_rows(config):
    local_csv = ROOT / config.get("input", {}).get("local_csv", "")
    if not local_csv.exists():
        return SAMPLE_ROWS

    with local_csv.open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def to_number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def safe_divide(numerator, denominator):
    return numerator / denominator if denominator else 0.0


def aggregate(rows, group_by):
    buckets = defaultdict(lambda: {
        "spend": 0.0,
        "impressions": 0.0,
        "clicks": 0.0,
        "conversions": 0.0,
    })

    for row in rows:
        key = tuple(row.get(field, "") for field in group_by)
        bucket = buckets[key]
        bucket["spend"] += to_number(row.get("spend"))
        bucket["impressions"] += to_number(row.get("impressions"))
        bucket["clicks"] += to_number(row.get("clicks"))
        bucket["conversions"] += to_number(row.get("conversions"))

    output = []
    for key, values in buckets.items():
        item = {field: key[index] for index, field in enumerate(group_by)}
        item.update({
            "spend": round(values["spend"], 2),
            "impressions": int(values["impressions"]),
            "clicks": int(values["clicks"]),
            "conversions": int(values["conversions"]),
            "cpc": round(safe_divide(values["spend"], values["clicks"]), 2),
            "ctr": round(safe_divide(values["clicks"], values["impressions"]) * 100, 2),
            "conversion_rate": round(safe_divide(values["conversions"], values["clicks"]) * 100, 2),
            "conversion_cost": round(safe_divide(values["spend"], values["conversions"]), 2),
        })
        output.append(item)

    return output


def write_report(config, rows, start_date, end_date):
    OUTPUT_DIR.mkdir(exist_ok=True)
    date_label = f"{start_date.replace('-', '')}_{end_date.replace('-', '')}"
    report_path = OUTPUT_DIR / f"weekly_report_{date_label}.csv"

    fieldnames = [
        "sheet",
        "group",
        "spend",
        "impressions",
        "clicks",
        "conversions",
        "cpc",
        "ctr",
        "conversion_rate",
        "conversion_cost",
    ]

    with report_path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for sheet in config.get("sheets", []):
            group_by = sheet.get("group_by", [])
            for item in aggregate(rows, group_by):
                group_label = " / ".join(str(item.get(field, "")) for field in group_by)
                writer.writerow({
                    "sheet": sheet.get("name", "未命名页面"),
                    "group": group_label,
                    "spend": item["spend"],
                    "impressions": item["impressions"],
                    "clicks": item["clicks"],
                    "conversions": item["conversions"],
                    "cpc": item["cpc"],
                    "ctr": item["ctr"],
                    "conversion_rate": item["conversion_rate"],
                    "conversion_cost": item["conversion_cost"],
                })

    return report_path


def write_validation(rows, start_date, end_date):
    date_label = f"{start_date.replace('-', '')}_{end_date.replace('-', '')}"
    validation_path = OUTPUT_DIR / f"validation_{date_label}.json"
    payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "row_count": len(rows),
        "warnings": [],
    }
    validation_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return validation_path


def build_weekly_report(config_path, start_date, end_date):
    config = load_config(config_path)
    rows = load_rows(config)
    report_path = write_report(config, rows, start_date, end_date)
    validation_path = write_validation(rows, start_date, end_date)

    return {
        "report_path": str(report_path),
        "validation_path": str(validation_path),
        "row_count": len(rows),
    }
