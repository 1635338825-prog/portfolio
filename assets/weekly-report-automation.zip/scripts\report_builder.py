#!/usr/bin/env python3
"""本地周报生成器。"""

import csv
import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "output"


def load_config(config_path):
    return json.loads(Path(config_path).read_text(encoding="utf-8"))


def load_account_ids(accounts_path):
    if not accounts_path.exists():
        raise FileNotFoundError(
            f"未找到账户配置：{accounts_path}。请先复制 configs/accounts.example.json 为 accounts.json。"
        )

    payload = json.loads(accounts_path.read_text(encoding="utf-8"))
    account_ids = [
        str(account.get("account_id", "")).strip()
        for account in payload.get("accounts", [])
        if account.get("enabled", True)
    ]
    account_ids = [account_id for account_id in account_ids if account_id]
    if not account_ids:
        raise ValueError("账户配置中没有启用的 account_id。")
    return account_ids


def empty_rows(account_ids):
    """No data adapter means the package still produces a reviewable report layout."""
    return [
        {
            "account_id": account_id,
            "account_group": "待配置",
            "placement": "待导入",
            "content_type": "待导入",
            "spend": 0,
            "impressions": 0,
            "clicks": 0,
            "conversions": 0,
        }
        for account_id in account_ids
    ]


def load_rows(config, account_ids):
    local_csv = ROOT / config.get("input", {}).get("local_csv", "")
    if not local_csv.exists():
        return empty_rows(account_ids), "blank_template"

    with local_csv.open("r", encoding="utf-8-sig", newline="") as file:
        rows = list(csv.DictReader(file))
    requested = set(account_ids)
    return [row for row in rows if str(row.get("account_id", "")).strip() in requested], "local_csv"


def to_number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def safe_divide(numerator, denominator):
    return numerator / denominator if denominator else 0.0


def aggregate(rows, group_by):
    buckets = defaultdict(lambda: {
        "account_id": "",
        "spend": 0.0,
        "impressions": 0.0,
        "clicks": 0.0,
        "conversions": 0.0,
    })

    for row in rows:
        key = tuple(row.get(field, "") for field in group_by)
        bucket = buckets[key]
        bucket["spend"] += to_number(row.get("spend"))
        bucket["impressions"] += to_number(row.get("impressions"))
        bucket["clicks"] += to_number(row.get("clicks"))
        bucket["conversions"] += to_number(row.get("conversions"))

    output = []
    for key, values in buckets.items():
        item = {field: key[index] for index, field in enumerate(group_by)}
        item.update({
            "spend": round(values["spend"], 2),
            "impressions": int(values["impressions"]),
            "clicks": int(values["clicks"]),
            "conversions": int(values["conversions"]),
            "cpc": round(safe_divide(values["spend"], values["clicks"]), 2),
            "ctr": round(safe_divide(values["clicks"], values["impressions"]) * 100, 2),
            "conversion_rate": round(safe_divide(values["conversions"], values["clicks"]) * 100, 2),
            "conversion_cost": round(safe_divide(values["spend"], values["conversions"]), 2),
        })
        output.append(item)

    return output


def write_report(config, rows, start_date, end_date):
    OUTPUT_DIR.mkdir(exist_ok=True)
    date_label = f"{start_date.replace('-', '')}_{end_date.replace('-', '')}"
    report_path = OUTPUT_DIR / f"weekly_report_{date_label}.csv"

    fieldnames = [
        "sheet",
        "account_id",
        "group",
        "spend",
        "impressions",
        "clicks",
        "conversions",
        "cpc",
        "ctr",
        "conversion_rate",
        "conversion_cost",
    ]

    with report_path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for sheet in config.get("sheets", []):
            group_by = sheet.get("group_by", [])
            for item in aggregate(rows, group_by):
                group_label = " / ".join(str(item.get(field, "")) for field in group_by)
                writer.writerow({
                    "sheet": sheet.get("name", "未命名页面"),
                    "account_id": item.get("account_id", ""),
                    "group": group_label,
                    "spend": item["spend"],
                    "impressions": item["impressions"],
                    "clicks": item["clicks"],
                    "conversions": item["conversions"],
                    "cpc": item["cpc"],
                    "ctr": item["ctr"],
                    "conversion_rate": item["conversion_rate"],
                    "conversion_cost": item["conversion_cost"],
                })

    return report_path


def write_validation(rows, account_ids, source_mode, start_date, end_date):
    date_label = f"{start_date.replace('-', '')}_{end_date.replace('-', '')}"
    validation_path = OUTPUT_DIR / f"validation_{date_label}.json"
    matched_account_ids = sorted({str(row.get("account_id", "")).strip() for row in rows})
    missing_account_ids = sorted(set(account_ids) - set(matched_account_ids))
    warnings = []
    if source_mode == "blank_template":
        warnings.append("未发现本地数据源，已按账户 ID 生成空白周报格式。")
    if missing_account_ids:
        warnings.append(f"{len(missing_account_ids)} 个账户未匹配到数据。")
    payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "row_count": len(rows),
        "source_mode": source_mode,
        "requested_account_count": len(account_ids),
        "matched_account_count": len(matched_account_ids),
        "warnings": warnings,
    }
    validation_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return validation_path


def build_weekly_report(config_path, accounts_path, start_date, end_date):
    config = load_config(config_path)
    account_ids = load_account_ids(accounts_path)
    rows, source_mode = load_rows(config, account_ids)
    report_path = write_report(config, rows, start_date, end_date)
    validation_path = write_validation(rows, account_ids, source_mode, start_date, end_date)

    return {
        "report_path": str(report_path),
        "validation_path": str(validation_path),
        "row_count": len(rows),
        "requested_account_count": len(account_ids),
        "matched_account_count": len({row.get("account_id", "") for row in rows}),
    }
