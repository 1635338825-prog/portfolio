#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
唯品会周报 - 同步笔记映射表
从飞书表格同步映射关系，生成 3 个索引：code_mapping / note_mapping / campaign_mapping

用法:
  python sync_weekly_mapping.py
"""

import sys
import json
import re
from pathlib import Path
from datetime import datetime, timezone, timedelta

import requests

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.stderr.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = Path(__file__).parent
CONFIG_DIR = SCRIPT_DIR.parent / 'configs'


def get_config():
    """读取配置文件"""
    config_path = CONFIG_DIR / 'vip_weekly_config.json'
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def get_tenant_token(app_id, app_secret, max_retries=3):
    """获取 tenant_access_token"""
    url = 'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal'
    data = {'app_id': app_id, 'app_secret': app_secret}

    for attempt in range(max_retries):
        try:
            resp = requests.post(url, json=data, timeout=10)
            resp.raise_for_status()
            result = resp.json()
            if result.get('code') == 0:
                print(f'[OK] tenant token获取成功')
                return result['tenant_access_token']
            print(f'[重试] tenant token获取失败: {result.get("msg")} (尝试 {attempt+1}/{max_retries})')
        except Exception as e:
            print(f'[重试] tenant token获取异常: {e} (尝试 {attempt+1}/{max_retries})')

    raise Exception(f'tenant token获取失败（重试{max_retries}次）')


def get_spreadsheet_token(tenant_token, wiki_node_token, max_retries=3):
    """通过 wiki node token 获取 spreadsheet token"""
    url = f'https://open.feishu.cn/open-apis/wiki/v2/spaces/get_node?token={wiki_node_token}'
    headers = {'Authorization': f'Bearer {tenant_token}'}

    for attempt in range(max_retries):
        try:
            resp = requests.get(url, headers=headers, timeout=10)
            resp.raise_for_status()
            result = resp.json()
            if result.get('code') == 0:
                obj_token = result['data']['node']['obj_token']
                print(f'[OK] spreadsheet token获取成功')
                return obj_token
            print(f'[重试] spreadsheet token获取失败: {result.get("msg")} (尝试 {attempt+1}/{max_retries})')
        except Exception as e:
            print(f'[重试] spreadsheet token获取异常: {e} (尝试 {attempt+1}/{max_retries})')

    raise Exception(f'spreadsheet token获取失败（重试{max_retries}次）')


def read_sheet_data(tenant_token, spreadsheet_token, sheet_id, max_retries=3):
    """读取 sheet 数据"""
    url = f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{spreadsheet_token}/values/{sheet_id}!A2:J9999'
    headers = {'Authorization': f'Bearer {tenant_token}'}

    for attempt in range(max_retries):
        try:
            resp = requests.get(url, headers=headers, timeout=30)
            resp.raise_for_status()
            result = resp.json()
            if result.get('code') == 0:
                values = result['data']['valueRange']['values']
                print(f'[OK] sheet数据读取成功，共 {len(values)} 行')
                return values
            print(f'[重试] sheet数据读取失败: {result.get("msg")} (尝试 {attempt+1}/{max_retries})')
        except Exception as e:
            print(f'[重试] sheet数据读取异常: {e} (尝试 {attempt+1}/{max_retries})')

    raise Exception(f'sheet数据读取失败（重试{max_retries}次）')


def parse_mapping(rows):
    """解析映射表，生成 3 个索引"""
    code_mapping = {}
    note_mapping = {}
    campaign_mapping = {}

    for row in rows:
        if not row or len(row) < 9:
            continue

        # 提取各列数据
        pname_col = str(row[0] or '').strip()
        dmp_name = str(row[1] or '').strip()
        code_raw = str(row[2] or '').strip()
        note_id = str(row[3] or '').strip()
        src = str(row[4] or '').strip()
        campaign_name = str(row[5] or '').strip()
        campaign_id = str(row[6] or '').strip()
        account = str(row[7] or '').strip()
        placement = str(row[8] or '').strip()

        # 提取 8 位监测点位码（支持带日期后缀或点号的格式，如 cfo3jwzr0401、fakwjq4l.）
        # 先去掉点号和后面的内容
        code_clean = code_raw.split('.')[0]
        m = re.match(r'^([a-z0-9]{8})', code_clean.lower())
        code = m.group(1) if m else ''

        if not code:
            continue

        # 构建 point_name
        point_name = pname_col if pname_col else (code + '_' + dmp_name if dmp_name else '')

        # code_mapping: 以 code 为 key 去重
        if code not in code_mapping:
            code_mapping[code] = {
                'note_id': note_id,
                'point_name': point_name,
                'note_source': src,
                'placement': placement,
                'account': account,
                'campaign_name': campaign_name,
            }

        # note_mapping: note_id -> [codes]
        if note_id and code:
            if note_id not in note_mapping:
                note_mapping[note_id] = []
            if code not in note_mapping[note_id]:
                note_mapping[note_id].append(code)

        # campaign_mapping: campaign_id -> code
        if campaign_id and code:
            campaign_mapping[campaign_id] = code

    return code_mapping, note_mapping, campaign_mapping


def main():
    print('=' * 50)
    print('唯品会周报 - 同步笔记映射表')
    print('=' * 50)

    try:
        config = get_config()
        feishu_config = config.get('feishu', {})
        mapping_config = config.get('mapping_table', {})

        app_id = feishu_config.get('app_id')
        app_secret = feishu_config.get('app_secret')
        wiki_node_token = mapping_config.get('wiki_node_token', 'A7zCwk4HZiUg42kQxEIcF4WGn7e')
        sheet_id = feishu_config.get('sheet_id', 'ewETi0')

        if not app_id or not app_secret:
            raise Exception('配置文件中缺少 feishu.app_id 或 feishu.app_secret')

        # 1. 获取 tenant token
        print('\n[1/3] 获取 tenant_access_token...')
        tenant_token = get_tenant_token(app_id, app_secret)

        # 2. 获取 spreadsheet token
        print('\n[2/3] 获取 spreadsheet token...')
        spreadsheet_token = get_spreadsheet_token(tenant_token, wiki_node_token)

        # 3. 读取 sheet 数据
        print('\n[3/3] 读取 sheet 数据...')
        rows = read_sheet_data(tenant_token, spreadsheet_token, sheet_id)

        # 4. 解析映射
        print('\n[解析] 生成映射索引...')
        code_mapping, note_mapping, campaign_mapping = parse_mapping(rows)

        print(f'  - code_mapping: {len(code_mapping)} 条')
        print(f'  - note_mapping: {len(note_mapping)} 条')
        print(f'  - campaign_mapping: {len(campaign_mapping)} 条')

        # 5. 写入 mapping.json
        tz = timezone(timedelta(hours=8))
        now = datetime.now(tz)

        output = {
            'meta': {'last_updated': now.strftime('%Y-%m-%d')},
            'code_mapping': code_mapping,
            'note_mapping': note_mapping,
            'campaign_mapping': campaign_mapping
        }

        output_path = CONFIG_DIR / 'mapping.json'
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output, f, ensure_ascii=False, indent=2)

        print(f'\n✅ 映射表已写入: {output_path}')
        print('=' * 50)

    except Exception as e:
        print(f'\n✗ 同步失败: {e}')
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
