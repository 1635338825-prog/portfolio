# 客户周报自动化模板

这是一个公开展示版的周报自动化 Skill 模板，用来展示如何把跨平台广告数据、指标计算和报表交付沉淀成可复用工具。

## 包含内容

- `SKILL.md`：使用说明和流程约束
- `configs/weekly_report_config.json`：通用报表、字段映射和校验配置模板
- `configs/accounts.example.json`：账户 ID 配置示例
- `scripts/run_weekly_report.py`：主入口
- `scripts/report_builder.py`：本地数据聚合和文件生成
- `PUBLIC_RELEASE.md`：公开版脱敏边界

## 不包含内容

这个作品集版本不会包含，也不会通过配置间接引用：

- 真实客户名
- 账户 ID、计划 ID、点位码和笔记标识
- 登录状态、Cookie、令牌、密钥和连接地址
- 实时映射缓存、浏览器状态和原始数据
- 历史周报、校验结果、导出的 Excel 及调试产物

## 运行示例

```bash
cd scripts
python run_weekly_report.py --start-date 2026-06-01 --end-date 2026-06-07
```

先复制账户配置示例，再填写需要出报的账户 ID：

```bash
cp configs/accounts.example.json configs/accounts.json
```

运行后会在 `output/` 下生成对应账户的周报 CSV 和校验摘要：

```bash
python scripts/run_weekly_report.py --start-date 2026-06-01 --end-date 2026-06-07 --accounts configs/accounts.json
```

未接入数据源时，脚本会按账户 ID 生成空白周报格式，便于确认交付结构；接入本地导出数据后会计算对应指标。真实认证、实时数据和客户映射仅在私有环境维护。

## 适合复用的场景

- 每周固定生成客户投放报告
- 两个或多个业务数据源需要统一清洗和聚合
- 需要基于计划标识与点位码做跨源字段映射
- 报表结构固定，但客户配置和数据口径不同
- 需要把 Agent 分步执行的流程重构为稳定、可重复的脚本

## 扩展方式

1. 在 `configs/weekly_report_config.json` 中添加新的分组、指标、校验规则和映射字段。
2. 在 `report_builder.py` 中补充数据适配、计算或异常回补逻辑。
3. 将认证、真实数据读取、客户映射和历史产出放在私有环境维护，不写入作品集版本。
4. 把 `configs/accounts.json` 加入本地忽略规则，不要提交真实账户 ID。
