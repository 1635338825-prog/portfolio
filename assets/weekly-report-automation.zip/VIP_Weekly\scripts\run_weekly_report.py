#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
唯品会周报 - 主入口脚本
串联所有步骤，一条命令跑完全流程

用法:
  python run_weekly_report.py --start-date 2026-06-09 --end-date 2026-06-15
  python run_weekly_report.py --start-date 2026-04-27 --end-date 2026-05-03 --skip-monthly
"""

import sys
import json
import subprocess
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.stderr.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = Path(__file__).parent


def run_script(script_name, args, max_retries=2):
    """运行子脚本，失败自动重试"""
    script_path = SCRIPT_DIR / script_name
    cmd = [sys.executable, str(script_path)] + args

    for attempt in range(max_retries + 1):
        print(f'\n{"=" * 60}')
        print(f'运行: {script_name} {" ".join(args)}')
        if attempt > 0:
            print(f'（重试 {attempt}/{max_retries}）')
        print(f'{"=" * 60}')

        result = subprocess.run(cmd, cwd=str(SCRIPT_DIR))

        if result.returncode == 0:
            return 0

        if attempt < max_retries:
            print(f'\n✗ {script_name} 失败，{10}秒后重试...')
            time.sleep(10)

    return result.returncode


def calc_date_label(start_date_str, end_date_str):
    """根据起止日期生成 date label，如 '6.9-6.15'"""
    start_dt = datetime.strptime(start_date_str, '%Y-%m-%d')
    end_dt = datetime.strptime(end_date_str, '%Y-%m-%d')
    return f"{start_dt.month}.{start_dt.day}-{end_dt.month}.{end_dt.day}"


def main():
    print('=' * 60)
    print('唯品会周报 - 全流程自动化')
    print('=' * 60)

    import argparse
    parser = argparse.ArgumentParser(description='唯品会周报全流程')
    parser.add_argument('--start-date', default=None, help='周开始日期 YYYY-MM-DD')
    parser.add_argument('--end-date', default=None, help='周结束日期 YYYY-MM-DD')
    parser.add_argument('--skip-monthly', action='store_true', help='跨月时跳过 monthly 采集')
    args = parser.parse_args()

    # 确定日期（默认上周一~上周日）
    tz = timezone(timedelta(hours=8))
    today = datetime.now(tz)

    if args.start_date and args.end_date:
        start_date = args.start_date
        end_date = args.end_date
    else:
        # 默认上周一~上周日
        last_monday = today - timedelta(days=today.weekday() + 7)
        last_sunday = last_monday + timedelta(days=6)
        start_date = last_monday.strftime('%Y-%m-%d')
        end_date = last_sunday.strftime('%Y-%m-%d')

    date_label = calc_date_label(start_date, end_date)

    # 判断是否跨月
    start_dt = datetime.strptime(start_date, '%Y-%m-%d')
    end_dt = datetime.strptime(end_date, '%Y-%m-%d')
    cross_month = (start_dt.month != end_dt.month)
    skip_monthly = args.skip_monthly or cross_month

    print(f'周期: {start_date} ~ {end_date}')
    print(f'标签: {date_label}')
    print(f'跨月: {"是" if cross_month else "否"}')
    print(f'跳过monthly: {"是" if skip_monthly else "否"}')

    try:
        # Step 0: 同步映射表
        print(f'\n{"█" * 60}')
        print('Step 0: 同步笔记映射表')
        print(f'{"█" * 60}')
        exit_code = run_script('sync_weekly_mapping.py', [])
        if exit_code != 0:
            print(f'✗ Step 0 失败，中止（不使用缓存的映射表）')
            sys.exit(exit_code)

        # Step 1: 采集 DMP 数据
        print(f'\n{"█" * 60}')
        print('Step 1: 采集 DMP 数据')
        print(f'{"█" * 60}')
        dmp_args = ['--start-date', start_date, '--end-date', end_date]
        if skip_monthly:
            dmp_args.append('--skip-monthly')
        exit_code = run_script('dmp_collector_weekly.py', dmp_args)
        if exit_code != 0:
            print(f'✗ Step 1 失败，中止')
            sys.exit(exit_code)

        # Step 2: 生成周报
        print(f'\n{"█" * 60}')
        print('Step 2: 生成周报 Excel')
        print(f'{"█" * 60}')
        report_args = ['--date', date_label, '--start-date', start_date, '--end-date', end_date]
        exit_code = run_script('vip_weekly_analysis.py', report_args)
        if exit_code != 0:
            print(f'✗ Step 2 失败，中止')
            sys.exit(exit_code)

        # Step 3: 发送消息
        print(f'\n{"█" * 60}')
        print('Step 3: 发送飞书消息')
        print(f'{"█" * 60}')
        exit_code = run_script('send_weekly_message.py', ['--date', date_label])
        if exit_code != 0:
            print(f'✗ Step 3 失败，中止')
            sys.exit(exit_code)

        # 完成
        print(f'\n{"=" * 60}')
        print('✅ 唯品会周报生成完成！')
        print(f'{"=" * 60}')
        print(f'周期: {start_date} ~ {end_date}')
        print(f'标签: {date_label}')
        print(f'输出目录: {SCRIPT_DIR.parent / "output"}')

    except KeyboardInterrupt:
        print(f'\n\n✗ 用户中断')
        sys.exit(130)
    except Exception as e:
        print(f'\n✗ 执行异常: {e}')
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
