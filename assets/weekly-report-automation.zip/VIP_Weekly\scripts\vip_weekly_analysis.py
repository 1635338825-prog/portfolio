﻿# -*- coding: utf-8 -*-
"""
唯品会小红书聚光 - 周报分析脚本 v1.3
根据 SKILL.md 规范生成5个分析Sheet + 1个前端数据Sheet

用法:
  python vip_weekly_analysis.py --date 4.20-4.26 --input ../output/vip_weekly_420_426.xlsx
  python vip_weekly_analysis.py --start-date 2026-04-20 --end-date 2026-04-26 --date 4.20-4.26
"""

import sys
import os
import json
import argparse
import requests
from pathlib import Path
from datetime import date, datetime, timedelta
from collections import defaultdict

# ─── 路径设置 ─────────────────────────────────────────────────────────────
SCRIPTS_DIR = Path(__file__).parent
BASE_DIR    = SCRIPTS_DIR.parent
CONFIGS_DIR = BASE_DIR / 'configs'
OUTPUT_DIR  = BASE_DIR / 'output'

sys.path.insert(0, str(Path(__file__).parent))  # add scripts dir for data_fetcher / token_manager

import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ─── 命令行参数 ───────────────────────────────────────────────────────────
_parser = argparse.ArgumentParser(add_help=False)
_parser.add_argument('--date',       default=None, help='周期标签如 4.20-4.26')
_parser.add_argument('--input',      default=None, help='前端数据json/xlsx路径（优先于API拉取）')
_parser.add_argument('--output',     default=None, help='输出文件路径')
_parser.add_argument('--start-date', default=None, help='周开始日期 YYYY-MM-DD')
_parser.add_argument('--end-date',   default=None, help='周结束日期 YYYY-MM-DD')
_parser.add_argument('--no-fetch',   action='store_true', help='禁止API拉取（仅读缓存）')
_args, _ = _parser.parse_known_args()

# ─── 自动推算上周日期（如果未指定）───────────────────────────────────────
def _calc_last_week():
    """自动推算上周一~上周日"""
    today = date.today()
    last_monday = today - timedelta(days=today.weekday() + 7)
    last_sunday = last_monday + timedelta(days=6)
    return last_monday, last_sunday

if _args.start_date and _args.end_date:
    _start_dt = datetime.strptime(_args.start_date, '%Y-%m-%d')
    _end_dt   = datetime.strptime(_args.end_date, '%Y-%m-%d')
else:
    _start_dt, _end_dt = _calc_last_week()

if not _args.date:
    _args.date = f"{_start_dt.month}.{_start_dt.day:02d}-{_end_dt.month}.{_end_dt.day:02d}"

DATE_LABEL = _args.date

# ─── 默认路径 ─────────────────────────────────────────────────────────────
# 前端数据优先用JSON缓存，无缓存则API拉取
_FRONTEND_JSON = OUTPUT_DIR / f"frontend_{_start_dt.strftime('%Y%m%d')}_{_end_dt.strftime('%Y%m%d')}.json"
INPUT_FILE = _args.input  # 只有显式指定时才读文件
if _args.output:
    OUT_FILE = _args.output
else:
    OUT_FILE = str(OUTPUT_DIR / f"唯品会周报-{DATE_LABEL}.xlsx")

# ─── 加载配置 ─────────────────────────────────────────────────────────────
def load_config():
    cfg_path = CONFIGS_DIR / 'vip_weekly_config.json'
    if cfg_path.exists():
        with open(cfg_path, encoding='utf-8') as f:
            return json.load(f)
    return {
        "accounts": [],
        "price_order": ["低客单", "中客单", "高客单", "美妆"],
        "ver_order": ["全站智投", "搜索", "信息流", "视频流"],
        "zi_chan_set": ["爆款复刻", "常规自产", "高爆复刻", "新流程复刻"],
        "ke_chan_set": ["客供", "校园", "合作广场"],
    }

CONFIG = load_config()

ACCOUNT_NAME  = {a['id']: a['name'] for a in CONFIG['accounts']}
ACCOUNT_PRICE = CONFIG.get('account_price', {
    '唯品会-破圈-低': '低客单',
    '唯品会-破圈-中': '中客单',
    '唯品会-破圈-中-1': '中客单',
    '唯品会-破圈-高': '高客单',
    '唯品会-破圈-美妆': '美妆',
})
ACCOUNT_IDS   = set(a['id'] for a in CONFIG['accounts'])
PRICE_ORDER   = CONFIG.get('price_order', ["低客单", "中客单", "高客单", "美妆"])
VER_ORDER     = CONFIG.get('ver_order', ["全站智投", "搜索", "信息流", "视频流"])
ZI_CHAN_SET   = set(CONFIG.get('zi_chan_set', ["爆款复刻", "常规自产", "高爆复刻", "新流程复刻"]))
KE_CHAN_SET   = set(CONFIG.get('ke_chan_set', ["客供", "校园", "合作广场", "合作"]))
UNPURCHASE_ACCOUNTS = set(
    a['name'] for a in CONFIG['accounts']
    if '已安装' in a.get('rta', '')
)

# ─── 样式定义 ─────────────────────────────────────────────────────────────
# 无背景色（方便用户粘贴）
# FILL_NONE 已移除：不设置 fill 即为无填充，避免 Excel 报修复警告

FONT_BOLD  = Font(name='微软雅黑', bold=True, size=10)
FONT_NORM  = Font(name='微软雅黑', size=10)

ALIGN_C = Alignment(horizontal='center', vertical='center', wrap_text=True)

THIN   = Side(style='thin', color='BFBFBF')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

def style_cell(cell, fill=None, font=None, align=None, border=True):
    # fill 参数保留接口但不实际应用（无背景色方便粘贴）
    cell.font = font or FONT_NORM
    cell.alignment = align or ALIGN_C
    if border: cell.border = BORDER

def write_row(ws, row_idx, values, fill=None, font=None, bold=False):
    for col_idx, val in enumerate(values, 1):
        cell = ws.cell(row=row_idx, column=col_idx, value=val)
        f = font or (FONT_BOLD if bold else FONT_NORM)
        style_cell(cell, font=f)

def write_header_row(ws, row_idx, values, fill=None):
    write_row(ws, row_idx, values, font=FONT_BOLD)

def set_col_widths(ws, widths):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

# ─── 工具函数 ─────────────────────────────────────────────────────────────
def sf(v, d=0.0):
    if v is None or v == '' or v == '-': return d
    try: return float(str(v).replace('%', '').replace(',', '').strip())
    except: return d

def si(v): return int(sf(v))
def sdiv(a, b): a, b = sf(a), sf(b); return a / b if b else 0.0
def fmt1(v): return si(v)                  # 原始数据字段（消费/展现/点击等），取整，不保留小数
def fmt2(v): return round(sf(v), 1)        # 计算字段（新客成本/CPC/占比等），保留1位小数

# ─── 加载数据 ─────────────────────────────────────────────────────────────
PLACEMENT_MAP = {1:'信息流',2:'搜索',3:'视频流',4:'全站智投',7:'视频流',
                 '1':'信息流','2':'搜索','3':'视频流','4':'全站智投','7':'视频流'}

def _fetch_note_meta(note_ids, start_date_str, end_date_str, df):
    """从 note 离线接口获取 delivery_mode + note_jump_url，按 note_id 索引"""
    result_map = {}
    for acct in CONFIG['accounts']:
        result = df.fetch(
            endpoint='note',
            advertiser_id=acct['id'],
            start_date=start_date_str,
            end_date=end_date_str,
            time_unit='DAY',
            page_size=500
        )
        if result and result.get('data_list'):
            for r in result['data_list']:
                nid = str(r.get('note_id', '') or '').strip()
                if not nid or nid in result_map:
                    continue
                result_map[nid] = {
                    '笔记链接': str(r.get('note_jump_url', '') or '').strip(),
                }
    print(f"  note元数据获取: {len(result_map)} 条")
    return result_map


def fetch_frontend_data(start_date_str, end_date_str):
    """
    从聚光API拉取creative SUMMARY数据，返回标准化rows（内存）
    同时写入 output/frontend_YYYYMMDD_YYYYMMDD.json 作为缓存
    使用日报 cursor 机制：campaign_id精确匹配优先，fallback按note_id游标顺序分配
    """
    from token_manager import TokenManager
    from data_fetcher import DataFetcher

    code_mapping, note_mapping, campaign_mapping = load_mapping()
    tm = TokenManager()
    df = DataFetcher(tm)
    all_raw = []

    for acct in CONFIG['accounts']:
        acct_id = acct['id']
        acct_name = acct['name']
        print(f"  拉取账户: {acct_name}")
        result = df.fetch(
            endpoint='creative',
            advertiser_id=acct_id,
            start_date=start_date_str,
            end_date=end_date_str,
            time_unit='SUMMARY',
            split_columns=['deliveryMode'],
            page_size=500
        )
        if result and result.get('data_list'):
            for r in result['data_list']:
                r['acct_name'] = acct_name
            all_raw.extend(result['data_list'])
            print(f"    {len(result['data_list'])} 条，累计 {len(all_raw)} 条")
        else:
            print(f"    无数据")

    # ── cursor 机制（与日报一致）──────────────────────────────────────
    # 预留集：campaign_mapping 精确匹配的 code，cursor fallback 时跳过
    _note_reserved_codes = {}
    for cid, code in campaign_mapping.items():
        note_id_for_code = code_mapping.get(code, {}).get('note_id', '')
        if note_id_for_code:
            _note_reserved_codes.setdefault(note_id_for_code, set()).add(code)

    note_code_cursor = {}  # note_id → cursor 位置（已分配到第几个）

    rows = []
    for r in all_raw:
        note_id = str(r.get('note_id', '') or '').strip()
        acct_name = r.get('acct_name', '')
        campaign_id = str(r.get('campaign_id', '') or '').strip()
        note_codes = note_mapping.get(note_id, [])

        code = ''
        if note_codes:
            # 优先：campaign_id 精确匹配（限 note_codes 范围内）
            candidate = campaign_mapping.get(campaign_id, '')
            if candidate and candidate in note_codes:
                code = candidate
            else:
                # fallback：cursor 顺序分配，跳过被预留的 code
                reserved = _note_reserved_codes.get(note_id, set())
                cursor = note_code_cursor.get(note_id, 0)
                while cursor < len(note_codes):
                    c = note_codes[cursor]
                    cursor += 1
                    if c not in reserved:
                        code = c
                        note_code_cursor[note_id] = cursor
                        break

        entry = code_mapping.get(code, {}) if code else {}
        note_source = r.get('note_source') or entry.get('note_source', '')
        placement_cn = PLACEMENT_MAP.get(r.get('placement', ''), str(r.get('placement', '')))
        campaign_name = r.get('campaign_name', '')
        yi_pin, er_pin = get_category_parts(campaign_name)
        delivery_mode_raw = r.get('delivery_mode', '')
        try:
            dm_int = int(delivery_mode_raw)
            delivery_mode_cn = {0: '手动投放', 1: '自动投放'}.get(dm_int, '')
        except (ValueError, TypeError):
            delivery_mode_cn = parse_search_mode(campaign_name) or ''
        price_band = ''
        if acct_name:
            if '美妆' in acct_name:
                price_band = '美妆'
            else:
                for seg in reversed(acct_name.split('-')):
                    if seg in ('低', '中', '高'):
                        price_band = {'低': '低客单', '中': '中客单', '高': '高客单'}.get(seg, '')
                        break

        row = {
            '归属账户': acct_name,
            '笔记ID': note_id,
            '计划名称': campaign_name,
            '计划ID': campaign_id,
            '投放版本': placement_cn,
            '投放模式': delivery_mode_cn,
            '价格带': price_band,
            '消费': r.get('fee', 0) or 0,
            '展现量': r.get('impression', 0) or 0,
            '点击量': r.get('click', 0) or 0,
            'app打开': sf(r.get('invoke_app_open_cnt', 0)),
            '监测点位码': code,
            '笔记来源': note_source,
            '人群': r.get('unit_name', ''),
            '定向名称': r.get('unit_name', ''),
            '人群分类': '未购人群' if acct_name in UNPURCHASE_ACCOUNTS else '已购人群',
            '一级品类': yi_pin,
            '二级品类': er_pin,
            '笔记链接': '',
        }
        rows.append(row)

    # 获取 note 元数据（笔记链接）
    all_note_ids = list(set(r['笔记ID'] for r in rows if r['笔记ID']))
    if all_note_ids:
        print(f"  获取note元数据 ({len(all_note_ids)} 个笔记)...")
        note_meta = _fetch_note_meta(all_note_ids, start_date_str, end_date_str, df)
        for r in rows:
            meta = note_meta.get(r['笔记ID'], {})
            r['笔记链接'] = meta.get('笔记链接', '')

    # 写缓存
    start_key = start_date_str.replace('-', '')
    end_key = end_date_str.replace('-', '')
    cache_path = OUTPUT_DIR / f'frontend_{start_key}_{end_key}.json'
    with open(cache_path, 'w', encoding='utf-8') as f:
        json.dump(rows, f, ensure_ascii=False)
    print(f"  前端数据已缓存: {cache_path} ({len(rows)}行)")
    return rows

def load_frontend_data_from_json(path):
    """
    从缓存 JSON 读取前端数据，并用 cursor 机制重新分配监测点位码
    与 fetch_frontend_data 保持相同的分配逻辑
    """
    with open(path, encoding='utf-8') as f:
        raw_rows = json.load(f)
    print(f"  读取前端数据(JSON缓存): {len(raw_rows)} 行")

    code_mapping, note_mapping, campaign_mapping = load_mapping()

    # cursor 机制（与 fetch_frontend_data 完全一致）
    _note_reserved_codes = {}
    for cid, code in campaign_mapping.items():
        note_id_for_code = code_mapping.get(code, {}).get('note_id', '')
        if note_id_for_code:
            _note_reserved_codes.setdefault(note_id_for_code, set()).add(code)

    note_code_cursor = {}

    rows = []
    for r in raw_rows:
        note_id = str(r.get('笔记ID', '') or '').strip()
        acct_name = str(r.get('归属账户', '') or '')
        campaign_id = str(r.get('计划ID', '') or '').strip()
        note_codes = note_mapping.get(note_id, [])

        code = ''
        if note_codes:
            candidate = campaign_mapping.get(campaign_id, '')
            if candidate and candidate in note_codes:
                code = candidate
            else:
                reserved = _note_reserved_codes.get(note_id, set())
                cursor = note_code_cursor.get(note_id, 0)
                while cursor < len(note_codes):
                    c = note_codes[cursor]
                    cursor += 1
                    if c not in reserved:
                        code = c
                        note_code_cursor[note_id] = cursor
                        break

        entry = code_mapping.get(code, {}) if code else {}
        note_source = r.get('笔记来源') or entry.get('note_source', '')

        d = dict(r)
        d['app打开'] = sf(d.get('app打开', 0))  # 兼容旧缓存
        d['监测点位码'] = code
        d['笔记来源'] = note_source
        d['人群分类'] = '未购人群' if acct_name in UNPURCHASE_ACCOUNTS else '已购人群'
        rows.append(d)

    return rows

def load_frontend_data(path):
    """从xlsx读取前端数据（兼容手动导入的文件）"""
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = None
    for sheet_name in ['前端数据', 'Sheet1']:
        if sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            break
    if ws is None:
        ws = wb.active

    headers = [c.value for c in ws[1]]
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        d = dict(zip(headers, row))
        acct = str(d.get('归属账户') or d.get('账户名称') or '').strip()
        d['人群分类'] = '未购人群' if acct in UNPURCHASE_ACCOUNTS else '已购人群'

        rows.append(d)
    wb.close()
    print(f"  读取前端数据(xlsx): {len(rows)} 行")
    return rows

def load_dmp_data():
    """返回完整 dmp_all 结构：{"weekly": {week_key: {code: {...}}}, "monthly": {...}}"""
    dmp_path = CONFIGS_DIR / 'dmp_data.json'
    if dmp_path.exists():
        with open(dmp_path, encoding='utf-8') as f:
            dmp_all = json.load(f)
        weekly_cnt = sum(len(v) for v in dmp_all.get('weekly', {}).values() if isinstance(v, dict))
        monthly_cnt = sum(len(v) for v in dmp_all.get('monthly', {}).values() if isinstance(v, dict))
        print(f"[DMP] 加载 dmp_data.json: weekly={weekly_cnt}条, monthly={monthly_cnt}条")
        return dmp_all
    print("[DMP] 未找到DMP数据，DMP列全为0")
    return {"weekly": {}, "monthly": {}}


def sync_mapping():
    """Step 0: 从飞书表格同步笔记映射，写入 mapping.json（参考日报逻辑）"""
    import re as _re
    cfg_feishu = CONFIG.get('feishu', {})
    cfg_mapping = CONFIG.get('mapping_table', {})
    app_id     = cfg_feishu.get('app_id', '')
    app_secret = cfg_feishu.get('app_secret', '')
    wiki_token = cfg_mapping.get('wiki_node_token', '')
    spreadsheet_token = cfg_mapping.get('spreadsheet_token', '')

    try:
        # Step 0.1: 获取 tenant_access_token
        resp = requests.post(
            'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
            json={'app_id': app_id, 'app_secret': app_secret}, timeout=10
        )
        token = resp.json().get('tenant_access_token', '')
        if not token:
            print('[mapping] 获取飞书token失败，使用本地缓存')
            return

        # Step 0.2: 获取 spreadsheet_token（如果 config 里已有直接用）
        if not spreadsheet_token and wiki_token:
            r2 = requests.get(
                f'https://open.feishu.cn/open-apis/wiki/v2/spaces/get_node?token={wiki_token}',
                headers={'Authorization': f'Bearer {token}'}, timeout=10
            )
            spreadsheet_token = r2.json().get('data', {}).get('node', {}).get('obj_token', '')

        if not spreadsheet_token:
            print('[mapping] 获取spreadsheet_token失败，使用本地缓存')
            return

        # Step 0.3: 读取 ewETi0!A2:J9999（含 I列=投放模式、J列=计划名称）
        r3 = requests.get(
            f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{spreadsheet_token}/values/ewETi0!A2:J9999',
            headers={'Authorization': f'Bearer {token}'}, timeout=30
        )
        rows = r3.json().get('data', {}).get('valueRange', {}).get('values', [])
        if not rows:
            print('[mapping] 飞书表格返回空数据，使用本地缓存')
            return

        # Step 0.4: 构建三个索引（与日报逻辑一致）
        code_mapping_new     = {}
        note_mapping_new     = {}
        campaign_mapping_new = {}
        for row in rows:
            pname_col     = str(row[0]).strip() if len(row) > 0 and row[0] else ''
            dmp_name      = str(row[1]).strip() if len(row) > 1 and row[1] else ''
            code_raw      = str(row[2]).strip() if len(row) > 2 and row[2] else ''
            note_id       = str(row[3]).strip() if len(row) > 3 and row[3] else ''
            src           = str(row[4]).strip() if len(row) > 4 and row[4] else ''
            campaign_name = str(row[5]).strip() if len(row) > 5 and row[5] else ''  # F列：计划名称
            campaign_id   = str(row[6]).strip() if len(row) > 6 and row[6] else ''  # G列：计划ID
            account       = str(row[7]).strip() if len(row) > 7 and row[7] else ''  # H列：账户名称
            placement     = str(row[8]).strip() if len(row) > 8 and row[8] else ''  # I列：投放版位
            delivery_mode = ''  # 已从表格移除
            m = _re.match(r'^[a-z0-9]{8}', code_raw.lower())
            code = m.group(0) if m else ''
            point_name = pname_col if pname_col else (code + '_' + dmp_name if code and dmp_name else '')
            if code and code not in code_mapping_new:
                code_mapping_new[code] = {
                    'note_id': note_id, 'point_name': point_name,
                    'note_source': src, 'placement': placement, 'account': account,
                    'delivery_mode': delivery_mode, 'campaign_name': campaign_name,
                }
            if note_id and code:
                if note_id not in note_mapping_new:
                    note_mapping_new[note_id] = []
                if code not in note_mapping_new[note_id]:
                    note_mapping_new[note_id].append(code)
            if campaign_id and code:
                campaign_mapping_new[campaign_id] = code

        import json as _json
        from datetime import date as _date
        out = {
            'meta': {'last_updated': str(_date.today())},
            'code_mapping': code_mapping_new,
            'note_mapping': note_mapping_new,
            'campaign_mapping': campaign_mapping_new,
        }
        mapping_path = CONFIGS_DIR / 'mapping.json'
        with open(mapping_path, 'w', encoding='utf-8') as f:
            _json.dump(out, f, ensure_ascii=False, indent=2)
        print(f'[mapping] 同步完成: code={len(code_mapping_new)}, note={len(note_mapping_new)}, campaign={len(campaign_mapping_new)}')

    except Exception as e:
        print(f'[mapping] 同步失败: {e}，使用本地缓存')

def load_mapping():
    mapping_path = CONFIGS_DIR / 'mapping.json'
    if not mapping_path.exists():
        return {}, {}, {}
    with open(mapping_path, encoding='utf-8') as f:
        data = json.load(f)
    return data.get('code_mapping', {}), data.get('note_mapping', {}), data.get('campaign_mapping', {})

# ─── 数据处理 ─────────────────────────────────────────────────────────────
def merge_dmp_data(rows, dmp_data, code_mapping):
    """将 DMP 数据按监测点位码注入每行（cursor 已保证同 code 不重复分配）"""
    for r in rows:
        code = str(r.get('监测点位码') or r.get('点位码') or '').strip()
        entry = code_mapping.get(code, {}) if code else {}
        r['_code'] = code
        r['_note_source'] = entry.get('note_source', r.get('笔记来源', ''))
        dmp = dmp_data.get(code, {}) if code else {}
        r['_dmp_uv']    = sf(dmp.get('UV', 0))
        r['_dmp_unpuv'] = sf(dmp.get('未购买UV', 0))
        r['_dmp_op']    = sf(dmp.get('可运营UV', 0))
        r['_dmp_xk']    = sf(dmp.get('新客数', 0))
        r['_dmp_rev']   = sf(dmp.get('实收金额', 0))
        r['_dmp_xrev']  = sf(dmp.get('新客实收', 0))
        r['_dmp_ke']    = sf(dmp.get('客户数', 0))
        r['_dmp_lk']    = r['_dmp_ke'] - r['_dmp_xk']

def parse_placement(val):
    s = str(val or '').strip()
    # 先处理数字编码
    if s in PLACEMENT_MAP:
        return PLACEMENT_MAP[s]
    if '全站' in s: return '全站智投'
    if '搜索' in s: return '搜索'
    if '信息流' in s: return '信息流'
    if '视频' in s: return '视频流'
    return '其他'

def parse_search_mode(campaign_name):
    """从计划名 index[8] 解析投放模式：含『自』=自动投放，含『手』=手动投放"""
    name = str(campaign_name or '')
    parts = name.split('-')
    seg = parts[8].strip() if len(parts) > 8 else ''
    if '自' in seg: return '自动投放'
    if '手' in seg: return '手动投放'
    return None

def parse_source_type(val):
    s = str(val or '').strip()
    if s in KE_CHAN_SET: return '客供'
    return '自产'  # 非客供/校园均为自产（含空值）

def get_price(row):
    return row.get('价格带', '') or ACCOUNT_PRICE.get(str(row.get('归属账户') or row.get('账户名称') or '').strip(), '其他')

def get_category_parts(campaign_name):
    """从计划名解析一级/二级品类，格式: code-日期-版位-素材名-一级品类-二级品类-出价-人群-投放模式
    健壮性：若计划名不足6段或品类字段含数字/特殊字符，返回空字符串"""
    parts = [p.strip() for p in str(campaign_name or '').split('-')]
    yi_pin = parts[4] if len(parts) > 4 else ''
    er_pin = parts[5] if len(parts) > 5 else ''
    # 品类应为纯中文/字母，若含大量数字或为空则视为无效
    if yi_pin and __import__('re').search(r'\d{4,}', yi_pin):
        yi_pin = ''
    if er_pin and __import__('re').search(r'\d{4,}', er_pin):
        er_pin = ''
    return yi_pin, er_pin

def get_crowd(row):
    """从计划名 parts[7] 解析人群标签，如 韩女/品类/节促人群 等"""
    name = str(row.get('计划名称') or '').strip()
    parts = name.split('-')
    return parts[7].strip() if len(parts) > 7 else ''

def _parse_crowd_from_name(name):
    """直接从名称字符串 parts[7] 解析人群标签（用于 unit_name 等场景）"""
    parts = str(name).split('-')
    return parts[7].strip() if len(parts) > 7 else name

def normalize_category(name):
    """
    标准化品类名称，解决格式不一致问题：
    - 去除多余空格（包括中间的空格）
    - 统一常见变体（如 'T 恤' → 'T恤'）
    """
    if not name:
        return name
    # 去除所有空格（包括中间的空格）
    normalized = str(name).replace(' ', '').replace('　', '')  # 半角和全角空格
    return normalized

# ─── 聚合计算 ─────────────────────────────────────────────────────────────
def agg_metrics(rows):
    return {
        '消费':   round(sum(sf(r.get('消费')) for r in rows), 1),
        'UV':     round(sum(sf(r.get('UV', r.get('_dmp_uv', 0))) for r in rows), 1),
        '可运营UV': round(sum(sf(r.get('可运营UV', r.get('_dmp_op', 0))) for r in rows), 1),
        '新客数': round(sum(sf(r.get('新客数', r.get('_dmp_xk', 0))) for r in rows), 1),
        '未购买UV': round(sum(sf(r.get('未购买UV', r.get('_dmp_unpuv', 0))) for r in rows), 1),
        '展现量': round(sum(sf(r.get('展现量')) for r in rows), 1),
        '点击量': round(sum(sf(r.get('点击量')) for r in rows), 1),
        '实收金额': round(sum(sf(r.get('实收金额', r.get('_dmp_rev', 0))) for r in rows), 1),
        '新客实收': round(sum(sf(r.get('新客实收', r.get('_dmp_xrev', 0))) for r in rows), 1),
        '老客数': round(sum(sf(r.get('老客数', r.get('_dmp_lk', 0))) for r in rows), 1),
    }

def calc_derived(m):
    cost = m.get('消费', 0)
    uv = m.get('UV', 0)
    op = m.get('可运营UV', 0)
    xk = m.get('新客数', 0)
    unpuv = m.get('未购买UV', 0)
    imp = m.get('展现量', 0)
    clk = m.get('点击量', 0)
    xrev = m.get('新客实收', 0)
    ke = m.get('老客数', 0) + xk  # 客户数 = 老客数 + 新客数
    return {
        '未购UV占比':       round(sdiv(unpuv, uv) * 100, 1),
        '新客成本(DMP口径)': fmt2(sdiv(cost, xk)),
        '可运营UV成本':     fmt2(sdiv(cost, op)),
        '未购UV成本':       fmt2(sdiv(cost, unpuv)),
        '老客占比':         round(sdiv(m.get('老客数', 0), ke) * 100, 1),
        '新客占比':         round(sdiv(xk, ke) * 100, 1),
        '新客转化率':       round(sdiv(xk, unpuv) * 100, 1),
        'UV到站率':         round(sdiv(uv, clk) * 100, 1),
        '新客uv到站率':     round(sdiv(unpuv, clk) * 100, 1),
        'UV成本':           fmt2(sdiv(cost, uv)),
        'CPC':              fmt2(sdiv(cost, clk)),
        'CTR':              round(sdiv(clk, imp) * 100, 1),
        '新客客单':         fmt2(sdiv(xrev, xk)),
    }

# ══════════════════════════════════════════════════════════════════════════
# Sheet1: 整体投放数据
# ══════════════════════════════════════════════════════════════════════════
def build_sheet1(wb, rows, last_rows):
    ws = wb.create_sheet('整体投放数据')
    HEADERS = ['周期', '消耗占比', '品类分层', '账户', '价格带', '消费', 'UV', '可运营UV', '新客数',
               '未购UV占比', '新客成本(DMP口径)', '可运营UV成本', '未购买UV', '未购UV成本',
               '老客占比', '新客占比', '新客转化率', 'UV到站率', '新客uv到站率', 'UV成本', 'CPC', 'CTR', '新客客单']
    write_header_row(ws, 1, HEADERS)
    row_idx = 2

    last_label = (_start_dt - timedelta(days=7)).strftime('%m.%d') + '-' + (_end_dt - timedelta(days=7)).strftime('%m.%d')
    for week_label, week_rows in [(last_label, last_rows), (DATE_LABEL+'（本周）', rows)]:
        total_m = agg_metrics(week_rows)
        total_d = calc_derived(total_m)
        total_cost = total_m['消费']

        # 按价格带+账户分组
        by_price_account = defaultdict(lambda: defaultdict(list))
        for r in week_rows:
            p = get_price(r)
            account = str(r.get('归属账户', '') or '').strip()
            if p in PRICE_ORDER:
                by_price_account[p][account].append(r)

        price_start = row_idx
        for price in PRICE_ORDER:
            accounts_dict = by_price_account.get(price, {})
            # 按账户名排序
            for account in sorted(accounts_dict.keys()):
                ar = accounts_dict[account]
                m = agg_metrics(ar) if ar else {k: 0 for k in total_m}
                d = calc_derived(m)
                cost = m['消费']
                pct = round(sdiv(cost, total_cost) * 100, 1)
                write_row(ws, row_idx, [
                    week_label if price == PRICE_ORDER[0] and account == sorted(accounts_dict.keys())[0] else '', 
                    f'{pct}%', '常规', account, price, round(cost, 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
                    f"{d['未购UV占比']}%", d['新客成本(DMP口径)'], d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
                    f"{d['老客占比']}%", f"{d['新客占比']}%", f"{d['新客转化率']}%", f"{d['UV到站率']}%", f"{d['新客uv到站率']}%",
                    d['UV成本'], d['CPC'], f"{d['CTR']}%", d['新客客单']
                ])
                row_idx += 1
        price_end = row_idx - 1

        # 合计行
        write_row(ws, row_idx, [
            week_label, '100.0%', '合计', '', '', round(total_m['消费'], 1), round(total_m['UV'], 1), round(total_m['可运营UV'], 1), round(total_m['新客数'], 1),
            f"{total_d['未购UV占比']}%", total_d['新客成本(DMP口径)'], total_d['可运营UV成本'], round(total_m['未购买UV'], 1), total_d['未购UV成本'],
            f"{total_d['老客占比']}%", f"{total_d['新客占比']}%", f"{total_d['新客转化率']}%", f"{total_d['UV到站率']}%", f"{total_d['新客uv到站率']}%",
            total_d['UV成本'], total_d['CPC'], f"{total_d['CTR']}%", total_d['新客客单']
        ], bold=True)
        ws.merge_cells(start_row=row_idx, start_column=3, end_row=row_idx, end_column=5)
        c = ws.cell(row=row_idx, column=3)
        c.value = '合计'
        c.alignment = ALIGN_C
        c.font = FONT_BOLD
        row_idx += 1

        # 合并周期列（含总计行）
        total_end = row_idx - 1
        if total_end >= price_start:
            ws.merge_cells(start_row=price_start, start_column=1, end_row=total_end, end_column=1)
            ws.cell(row=price_start, column=1).value = week_label
            ws.cell(row=price_start, column=1).alignment = ALIGN_C
            if price_end >= price_start:
                ws.merge_cells(start_row=price_start, start_column=3, end_row=price_end, end_column=3)
                ws.cell(row=price_start, column=3).value = '常规'
                ws.cell(row=price_start, column=3).alignment = ALIGN_C

    row_idx += 1

    # 投放版位表
    VER_HEADERS = ['投放版位', '消耗占比', '消费', 'UV', '可运营UV', '新客数',
                   '未购UV占比', '新客成本(DMP口径)', '可运营UV成本', '未购买UV', '未购UV成本',
                   '老客占比', '新客占比', '新客转化率', 'UV到站率', '新客uv到站率', 'UV成本', 'CPC', 'CTR', '新客客单']
    write_header_row(ws, row_idx, VER_HEADERS)
    row_idx += 1

    by_ver = defaultdict(list)
    for r in rows:
        ver = parse_placement(r.get('投放版本'))
        by_ver[ver].append(r)

    for ver in VER_ORDER:
        vr = by_ver.get(ver, [])
        m = agg_metrics(vr) if vr else {k: 0 for k in total_m}
        d = calc_derived(m)
        cost = m['消费']
        pct = round(sdiv(cost, total_cost) * 100, 1)
        write_row(ws, row_idx, [
            ver, f'{pct}%', round(cost, 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
            f"{d['未购UV占比']}%", d['新客成本(DMP口径)'], d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
            f"{d['老客占比']}%", f"{d['新客占比']}%", f"{d['新客转化率']}%", f"{d['UV到站率']}%", f"{d['新客uv到站率']}%",
            d['UV成本'], d['CPC'], f"{d['CTR']}%", d['新客客单']
        ])
        row_idx += 1

    write_row(ws, row_idx, [
        '合计', '100.0%', round(total_m['消费'], 1), round(total_m['UV'], 1), round(total_m['可运营UV'], 1), round(total_m['新客数'], 1),
        f"{total_d['未购UV占比']}%", total_d['新客成本(DMP口径)'], total_d['可运营UV成本'], round(total_m['未购买UV'], 1), total_d['未购UV成本'],
        f"{total_d['老客占比']}%", f"{total_d['新客占比']}%", f"{total_d['新客转化率']}%", f"{total_d['UV到站率']}%", f"{total_d['新客uv到站率']}%",
        total_d['UV成本'], total_d['CPC'], f"{total_d['CTR']}%", total_d['新客客单']
    ], bold=True)
    row_idx += 2

    # ══════════════════════════════════════════════════════════════════════
    # 新客笔记明细（新客数>3，按笔记聚合，账户合并单元格）
    # ══════════════════════════════════════════════════════════════════════
    NOTE_HEADERS = [
        '账户', '一级品类', '二级品类', '消费', 'UV', '可运营UV', '新客数',
        '未购UV占比', '新客成本(DMP口径)', '可运营UV成本', '未购买UV', '未购UV成本',
        '老客占比', '新客占比', '新客转化率', 'UV到站率', 'UV成本', 'CPC', 'CTR', '新客客单'
    ]
    ws.cell(row=row_idx, column=1, value='新客笔记明细').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(NOTE_HEADERS))
    row_idx += 1
    write_header_row(ws, row_idx, NOTE_HEADERS)
    row_idx += 1

    # 按 note_id 聚合，收集完整指标
    _by_note_xk = defaultdict(lambda: {
        'note_id': '', '归属账户': '', '一级品类': '', '二级品类': '',
        '消费': 0.0, '展现量': 0.0, '点击量': 0.0, 'UV': 0.0, '可运营UV': 0.0,
        '新客数': 0.0, '未购买UV': 0.0
    })
    for r in rows:
        nid = str(r.get('笔记ID', '') or '').strip()
        if not nid:
            continue
        agg = _by_note_xk[nid]
        if not agg['note_id']:
            agg['note_id'] = nid
            agg['归属账户'] = str(r.get('归属账户', '') or '').strip()
            agg['一级品类'] = str(r.get('一级品类', '') or '').strip()
            agg['二级品类'] = str(r.get('二级品类', '') or '').strip()
        agg['消费'] += sf(r.get('消费', 0))
        agg['展现量'] += sf(r.get('展现量', 0))
        agg['点击量'] += sf(r.get('点击量', 0))
        # DMP数据字段：优先取原始字段，否则取_dmp_前缀字段
        agg['UV'] += sf(r.get('UV', r.get('_dmp_uv', 0)))
        agg['可运营UV'] += sf(r.get('可运营UV', r.get('_dmp_op', 0)))
        agg['新客数'] += sf(r.get('新客数', r.get('_dmp_xk', 0)))
        agg['未购买UV'] += sf(r.get('未购买UV', r.get('_dmp_unpuv', 0)))

    # 筛选新客数 > 3
    note_xk_rows = [v for v in _by_note_xk.values() if v['新客数'] > 3]
    
    # 按账户分组，组内按新客数降序
    from collections import defaultdict as _dd_note
    _by_account = _dd_note(list)
    for nr in note_xk_rows:
        _by_account[nr['归属账户']].append(nr)
    
    # 对每个账户组内按新客数降序排序
    for acc in _by_account:
        _by_account[acc].sort(key=lambda x: -x['新客数'])
    
    # 按账户名排序（可选）
    sorted_accounts = sorted(_by_account.keys())

    # 写入数据，账户列合并单元格
    for acc in sorted_accounts:
        acc_rows = _by_account[acc]
        start_row = row_idx
        
        for nr in acc_rows:
            xk = nr['新客数']
            uv = nr['UV']
            ke_uv = nr['可运营UV']
            cost = nr['消费']
            weigou_uv = nr['未购买UV']
            
            # 计算衍生指标
            xk_cost = round(cost / xk, 1) if xk > 0 else 0
            ke_uv_cost = round(cost / ke_uv, 1) if ke_uv > 0 else 0
            weigou_pct = f"{round(weigou_uv / uv * 100, 1)}%" if uv > 0 else "0.0%"
            old_pct = f"{round((uv - xk) / uv * 100, 1)}%" if uv > 0 else "0.0%"
            new_pct = f"{round(xk / uv * 100, 1)}%" if uv > 0 else "0.0%"
            xk_cvr = f"{round(xk / uv * 100, 1)}%" if uv > 0 else "0.0%"
            uv_rate = f"{round(uv / nr['点击量'] * 100, 1)}%" if nr['点击量'] > 0 else "0.0%"
            uv_cost = round(cost / uv, 1) if uv > 0 else 0
            cpc = round(cost / nr['点击量'], 1) if nr['点击量'] > 0 else 0
            ctr = f"{round(nr['点击量'] / nr['展现量'] * 100, 1)}%" if nr['展现量'] > 0 else "0.0%"
            xk_kedan = round(cost / xk, 1) if xk > 0 else 0
            
            write_row(ws, row_idx, [
                nr['归属账户'], nr['一级品类'], nr['二级品类'],
                round(cost, 1), round(uv, 1), round(ke_uv, 1), round(xk, 1),
                weigou_pct, xk_cost, ke_uv_cost, round(weigou_uv, 1),
                round(weigou_uv / xk, 1) if xk > 0 else 0,
                old_pct, new_pct, xk_cvr, uv_rate,
                uv_cost, cpc, ctr, xk_kedan
            ])
            row_idx += 1
        
        # 合并账户列（如果有多行）
        if len(acc_rows) > 1:
            ws.merge_cells(start_row=start_row, start_column=1, 
                          end_row=start_row + len(acc_rows) - 1, end_column=1)

    row_idx += 1

    # ══════════════════════════════════════════════════════════════════════
    # 本周转化笔记（新客数>0，按一级品类+二级品类汇总，新客数降序）
    # 字段与搜索整体数据一致
    # ══════════════════════════════════════════════════════════════════════
    CONVERT_HEADERS = [
        '一级品类', '二级品类', '消耗占比', '价格带', '消费', 'UV', '可运营UV', '新客数',
        '未购UV占比', '新客成本(DMP口径)', '可运营UV成本', '未购买UV', '未购UV成本',
        '老客占比', '新客占比', '新客转化率', 'UV到站率', '新客uv到站率', 'UV成本', 'CPC', 'CTR', '新客客单'
    ]

    ws.cell(row=row_idx, column=1, value='本周转化笔记').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(CONVERT_HEADERS))
    row_idx += 1
    write_header_row(ws, row_idx, CONVERT_HEADERS)
    row_idx += 1

    # 筛选新客数>0的行
    convert_rows = [r for r in rows if sf(r.get('新客数', r.get('_dmp_xk', 0))) > 0]
    convert_total_cost = agg_metrics(convert_rows)['消费']

    # 按一级品类+二级品类分组
    from collections import defaultdict as _dd_cv
    _by_cat = _dd_cv(list)
    for r in convert_rows:
        yi = normalize_category(r.get('一级品类', '') or '') or '未知'
        er = normalize_category(r.get('二级品类', '') or '') or '未知'
        _by_cat[(yi, er)].append(r)

    # 按新客数降序排序
    sorted_cats = sorted(_by_cat.items(), key=lambda x: -agg_metrics(x[1])['新客数'])

    for (yi_pin, er_pin), cat_rows in sorted_cats:
        m = agg_metrics(cat_rows)
        d = calc_derived(m)
        cost = m['消费']
        pct = round(sdiv(cost, convert_total_cost) * 100, 1) if convert_total_cost else 0
        # 价格带：取该组中出现最多的价格带
        from collections import Counter as _Counter
        price_counter = _Counter(get_price(r) for r in cat_rows if get_price(r) in PRICE_ORDER)
        top_price = price_counter.most_common(1)[0][0] if price_counter else ''
        write_row(ws, row_idx, [
            yi_pin, er_pin, f'{pct}%', top_price,
            round(cost, 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
            f"{d['未购UV占比']}%", d['新客成本(DMP口径)'],
            d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
            f"{d['老客占比']}%", f"{d['新客占比']}%",
            f"{d['新客转化率']}%", f"{d['UV到站率']}%", f"{d['新客uv到站率']}%",
            d['UV成本'], d['CPC'], f"{d['CTR']}%", d['新客客单']
        ])
        row_idx += 1

    # 总计行
    m_cv = agg_metrics(convert_rows)
    d_cv = calc_derived(m_cv)
    write_row(ws, row_idx, [
        '总计', '', '100.0%', '',
        round(m_cv['消费'], 1), round(m_cv['UV'], 1), round(m_cv['可运营UV'], 1), round(m_cv['新客数'], 1),
        f"{d_cv['未购UV占比']}%", d_cv['新客成本(DMP口径)'],
        d_cv['可运营UV成本'], round(m_cv['未购买UV'], 1), d_cv['未购UV成本'],
        f"{d_cv['老客占比']}%", f"{d_cv['新客占比']}%",
        f"{d_cv['新客转化率']}%", f"{d_cv['UV到站率']}%", f"{d_cv['新客uv到站率']}%",
        d_cv['UV成本'], d_cv['CPC'], f"{d_cv['CTR']}%", d_cv['新客客单']
    ], bold=True)
    row_idx += 1

    set_col_widths(ws, [12, 10, 10, 20, 10, 12, 10, 10, 10, 10, 16, 12, 10, 12, 10, 10, 10, 10, 12, 10, 10, 10, 12])
    print(f"  Sheet1 整体投放数据: 价格带{len(PRICE_ORDER)}行 + 版位{len(VER_ORDER)}行")

# ══════════════════════════════════════════════════════════════════════════
# Sheet2: 投放情况（按板块）- 搜索板块特殊格式
# ══════════════════════════════════════════════════════════════════════════
def build_sheet2(wb, rows, last_rows):
    ws = wb.create_sheet('投放情况（按板块）')
    row_idx = 1
    last_label = (_start_dt - timedelta(days=7)).strftime('%m.%d') + '-' + (_end_dt - timedelta(days=7)).strftime('%m.%d')

    search_rows = [r for r in rows if parse_placement(r.get('投放版本')) == '搜索']
    last_search_rows = [r for r in last_rows if parse_placement(r.get('投放版本')) == '搜索']
    inflow_rows = [r for r in rows if parse_placement(r.get('投放版本')) == '信息流']
    last_inflow_rows = [r for r in last_rows if parse_placement(r.get('投放版本')) == '信息流']
    quanzhan_rows = [r for r in rows if parse_placement(r.get('投放版本')) == '全站智投']
    last_quanzhan_rows = [r for r in last_rows if parse_placement(r.get('投放版本')) == '全站智投']

    search_cost = agg_metrics(search_rows)['消费']
    inflow_cost = agg_metrics(inflow_rows)['消费']
    qz_cost = agg_metrics(quanzhan_rows)['消费']

    # ══════════════════════════════════════════════════════════════════════
    # 搜索板块
    # ══════════════════════════════════════════════════════════════════════

    # 分离自动/手动投放
    auto_rows = [r for r in search_rows if r.get('投放模式', parse_search_mode(r.get('计划名称'))) == '自动投放']
    manual_rows = [r for r in search_rows if r.get('投放模式', parse_search_mode(r.get('计划名称'))) == '手动投放']

    auto_cost = agg_metrics(auto_rows)['消费']
    manual_cost = agg_metrics(manual_rows)['消费']

    # ══════════════════════════════════════════════════════════════════════
    # 1. 搜索整体数据
    # ══════════════════════════════════════════════════════════════════════
    SEARCH_SUMMARY_HEADERS = [
        '周期', '消耗占比', '价格带', '消费', 'UV', '可运营UV', '新客数',
        '未购UV占比', '新客成本(DMP口径)', '可运营UV成本', '未购买UV', '未购UV成本',
        '老客占比', '新客占比', '新客转化率', 'UV到站率', 'UV成本', 'CPC', 'CTR', '新客客单'
    ]

    ws.cell(row=row_idx, column=1, value='搜索整体数据').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(SEARCH_SUMMARY_HEADERS))
    row_idx += 1
    write_header_row(ws, row_idx, SEARCH_SUMMARY_HEADERS)
    row_idx += 1

    # 搜索整体数据：上周+本周堆叠
    for week_label, s_rows in [(last_label, last_search_rows), (DATE_LABEL+'（本周）', search_rows)]:
        search_summary_start = row_idx
        by_price_search = defaultdict(list)
        for r in s_rows:
            p = get_price(r)
            if p in PRICE_ORDER:
                by_price_search[p].append(r)

        # 总消费=各价格带加总（非单独agg）
        total_search_cost = sum(agg_metrics(by_price_search.get(p, []))['消费'] for p in PRICE_ORDER)
        for price in PRICE_ORDER:
            pr = by_price_search.get(price, [])
            m = agg_metrics(pr) if pr else {k: 0 for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']}
            d = calc_derived(m)
            cost = m['消费']
            pct = round(sdiv(cost, total_search_cost) * 100, 1) if total_search_cost else 0
            write_row(ws, row_idx, [
                week_label if price == PRICE_ORDER[0] else '', f'{pct}%', price,
                round(cost, 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
                f"{d['未购UV占比']}%", d['新客成本(DMP口径)'],
                d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
                f"{d['老客占比']}%", f"{d['新客占比']}%",
                f"{d['新客转化率']}%", f"{d['UV到站率']}%",
                d['UV成本'], d['CPC'], f"{d['CTR']}%", d['新客客单']
            ])
            row_idx += 1

        # 总计=各价格带加总，非单独 agg
        m_all = {}
        for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']:
            m_all[k] = sum(agg_metrics(by_price_search.get(p, []))[k] for p in PRICE_ORDER)
        d_all = calc_derived(m_all)
        write_row(ws, row_idx, [
            week_label, '100.0%', '总计',
            round(m_all['消费'], 1), round(m_all['UV'], 1), round(m_all['可运营UV'], 1), round(m_all['新客数'], 1),
            f"{d_all['未购UV占比']}%", d_all['新客成本(DMP口径)'],
            d_all['可运营UV成本'], round(m_all['未购买UV'], 1), d_all['未购UV成本'],
            f"{d_all['老客占比']}%", f"{d_all['新客占比']}%",
            f"{d_all['新客转化率']}%", f"{d_all['UV到站率']}%",
            d_all['UV成本'], d_all['CPC'], f"{d_all['CTR']}%", d_all['新客客单']
        ], bold=True)
        search_summary_end = row_idx
        row_idx += 1

        if search_summary_end >= search_summary_start:
            ws.merge_cells(start_row=search_summary_start, start_column=1, end_row=search_summary_end, end_column=1)
            c = ws.cell(row=search_summary_start, column=1)
            c.value = week_label
            c.alignment = ALIGN_C

    row_idx += 1  # 空行

    # ══════════════════════════════════════════════════════════════════════
    # 2. 搜索板块-投放模式
    # ══════════════════════════════════════════════════════════════════════
    SEARCH_MODE_HEADERS = [
        '周期', '搜索板块-投放模式', '消耗占比', '搜索-价格带',
        '消费', 'UV', '可运营UV', '新客数',
        '未购UV占比', '新客成本(DMP口径)', '可运营UV成本', '未购买UV', '未购UV成本',
        '老客占比', '新客占比', '新客转化率', 'UV到站率', 'UV成本', 'CPC', 'CTR', '新客客单'
    ]

    ws.cell(row=row_idx, column=1, value='搜索板块-投放模式').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(SEARCH_MODE_HEADERS))
    row_idx += 1
    write_header_row(ws, row_idx, SEARCH_MODE_HEADERS)
    row_idx += 1

    auto_ratio = round(sdiv(auto_cost, search_cost) * 100, 1) if search_cost else 0
    manual_ratio = round(sdiv(manual_cost, search_cost) * 100, 1) if search_cost else 0

    # 记录搜索板块开始行（用于合并周期列）
    search_mode_start = row_idx

    def write_search_mode_block(grp_rows, mode_label, mode_ratio):
        """输出搜索的一个投放模式区块"""
        nonlocal row_idx

        by_price = defaultdict(list)
        for r in grp_rows:
            p = get_price(r)
            if p in PRICE_ORDER:
                by_price[p].append(r)

        block_start = row_idx
        for price in PRICE_ORDER:
            pr = by_price.get(price, [])
            m = agg_metrics(pr) if pr else {k: 0 for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']}
            d = calc_derived(m)
            write_row(ws, row_idx, [
                '', '', '', price,
                round(m['消费'], 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
                f"{d['未购UV占比']}%", d['新客成本(DMP口径)'],
                d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
                f"{d['老客占比']}%", f"{d['新客占比']}%",
                f"{d['新客转化率']}%", f"{d['UV到站率']}%",
                d['UV成本'], d['CPC'], f"{d['CTR']}%", d['新客客单']
            ])
            row_idx += 1

        # 总计=各价格带加总
        m_all = {}
        for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']:
            m_all[k] = sum(agg_metrics(by_price.get(p, []))[k] for p in PRICE_ORDER)
        d_all = calc_derived(m_all)
        write_row(ws, row_idx, [
            '', '', '', '总计',
            round(m_all['消费'], 1), round(m_all['UV'], 1), round(m_all['可运营UV'], 1), round(m_all['新客数'], 1),
            f"{d_all['未购UV占比']}%", d_all['新客成本(DMP口径)'],
            d_all['可运营UV成本'], round(m_all['未购买UV'], 1), d_all['未购UV成本'],
            f"{d_all['老客占比']}%", f"{d_all['新客占比']}%",
            f"{d_all['新客转化率']}%", f"{d_all['UV到站率']}%",
            d_all['UV成本'], d_all['CPC'], f"{d_all['CTR']}%", d_all['新客客单']
        ], bold=True)
        block_end = row_idx
        row_idx += 1

        # 合并投放模式列
        ws.merge_cells(start_row=block_start, start_column=2, end_row=block_end, end_column=2)
        c = ws.cell(row=block_start, column=2)
        c.value = mode_label
        c.alignment = ALIGN_C
        c.font = FONT_BOLD

        # 合并消耗占比列
        ws.merge_cells(start_row=block_start, start_column=3, end_row=block_end, end_column=3)
        c = ws.cell(row=block_start, column=3)
        c.value = f'{mode_ratio}%'
        c.alignment = ALIGN_C

        return block_start, block_end

    # 写入自动投放
    auto_start, auto_end = write_search_mode_block(auto_rows, '自动投放', auto_ratio)

    # 写入手动投放
    manual_start, manual_end = write_search_mode_block(manual_rows, '手动投放', manual_ratio)

    # 合并周期列（跨整个搜索板块-投放模式：自动+手动）
    search_mode_end = row_idx - 1
    if search_mode_end >= search_mode_start:
        ws.merge_cells(start_row=search_mode_start, start_column=1, end_row=search_mode_end, end_column=1)
        c = ws.cell(row=search_mode_start, column=1)
        c.value = f'{DATE_LABEL}（本周）'
        c.alignment = ALIGN_C

    row_idx += 1  # 空行

    # ══════════════════════════════════════════════════════════════════════
    # 信息流板块
    # ══════════════════════════════════════════════════════════════════════
    HEADERS = ['周期', '消耗占比', '价格带', '消费', 'UV', '可运营UV', '新客数',
               '未购UV占比', '新客成本(DMP口径)', '可运营UV成本', '未购买UV', '未购UV成本',
               '老客占比', '新客占比', '新客转化率', 'UV到站率', 'UV成本', 'CPC', 'CTR', '新客客单']

    # 信息流整体
    ws.cell(row=row_idx, column=1, value='信息流整体').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(HEADERS))
    row_idx += 1
    write_header_row(ws, row_idx, HEADERS)
    row_idx += 1

    # 信息流整体：上周+本周堆叠
    for week_label, i_rows in [(last_label, last_inflow_rows), (DATE_LABEL+'（本周）', inflow_rows)]:
        il_cost = sum(sf(r.get('消费')) for r in i_rows)
        by_price_il = defaultdict(list)
        for r in i_rows:
            p = get_price(r)
            if p in PRICE_ORDER:
                by_price_il[p].append(r)

        il_start = row_idx
        for price in PRICE_ORDER:
            pr = by_price_il.get(price, [])
            m = agg_metrics(pr) if pr else {k: 0 for k in ['消费','UV','可运营UV','新客数','未购买UV']}
            d = calc_derived(m)
            cost = m['消费']
            pct = round(sdiv(cost, il_cost) * 100, 1) if il_cost else 0
            write_row(ws, row_idx, [
                week_label if price == PRICE_ORDER[0] else '', f'{pct}%', price, round(cost, 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
                f"{d['未购UV占比']}%", d['新客成本(DMP口径)'], d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
                f"{d['老客占比']}%", f"{d['新客占比']}%", f"{d['新客转化率']}%", f"{d['UV到站率']}%",
                d['UV成本'], d['CPC'], f"{d['CTR']}%", d['新客客单']
            ])
            row_idx += 1

        # 总计=各价格带加总
        m_il = {}
        for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']:
            m_il[k] = sum(agg_metrics(by_price_il.get(p, []))[k] for p in PRICE_ORDER)
        d_il = calc_derived(m_il)
        write_row(ws, row_idx, [
            week_label, '100.0%', '合计', round(m_il['消费'], 1), round(m_il['UV'], 1), round(m_il['可运营UV'], 1), round(m_il['新客数'], 1),
            f"{d_il['未购UV占比']}%", d_il['新客成本(DMP口径)'], d_il['可运营UV成本'], round(m_il['未购买UV'], 1), d_il['未购UV成本'],
            f"{d_il['老客占比']}%", f"{d_il['新客占比']}%", f"{d_il['新客转化率']}%", f"{d_il['UV到站率']}%",
            d_il['UV成本'], d_il['CPC'], f"{d_il['CTR']}%", d_il['新客客单']
        ], bold=True)
        il_end = row_idx
        row_idx += 1

        if il_end > il_start:
            ws.merge_cells(start_row=il_start, start_column=1, end_row=il_end, end_column=1)
            ws.cell(row=il_start, column=1).value = week_label
            ws.cell(row=il_start, column=1).alignment = ALIGN_C

    row_idx += 1

    # 信息流-分定向
    ws.cell(row=row_idx, column=1, value='信息流-分定向数据整体数据').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(HEADERS))
    row_idx += 1

    CROWD_HEADERS = ['周期', '人群', '消费', '新客数', '新客成本', 'CTR', 'CPC']
    write_header_row(ws, row_idx, CROWD_HEADERS)
    row_idx += 1

    by_crowd = defaultdict(list)
    for r in inflow_rows:
        crowd = get_crowd(r) or '未知'
        by_crowd[crowd].append(r)

    for crowd, crowd_rows in sorted(by_crowd.items(), key=lambda x: -agg_metrics(x[1])['消费']):
        m = agg_metrics(crowd_rows)
        d = calc_derived(m)
        if m['消费'] <= 0:
            continue
        write_row(ws, row_idx, [DATE_LABEL, crowd, round(m['消费'], 1), round(m['新客数'], 1), d['新客成本(DMP口径)'], f"{d['CTR']}%", d['CPC']])
        row_idx += 1

    # 总计行
    m_crowd_total = agg_metrics(inflow_rows)
    d_crowd_total = calc_derived(m_crowd_total)
    write_row(ws, row_idx, [DATE_LABEL, '总计', round(m_crowd_total['消费'], 1), round(m_crowd_total['新客数'], 1), d_crowd_total['新客成本(DMP口径)'], f"{d_crowd_total['CTR']}%", d_crowd_total['CPC']], bold=True)
    row_idx += 1

    row_idx += 1

    # ══════════════════════════════════════════════════════════════════════
    # 全站板块
    # ══════════════════════════════════════════════════════════════════════
    ws.cell(row=row_idx, column=1, value='全站整体').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(HEADERS))
    row_idx += 1
    write_header_row(ws, row_idx, HEADERS)
    row_idx += 1

    # 全站整体：上周+本周堆叠
    for week_label, q_rows in [(last_label, last_quanzhan_rows), (DATE_LABEL+'（本周）', quanzhan_rows)]:
        qz_cost_w = sum(sf(r.get('消费')) for r in q_rows)
        by_price_qz = defaultdict(list)
        for r in q_rows:
            p = get_price(r)
            if p in PRICE_ORDER:
                by_price_qz[p].append(r)

        qz_start = row_idx
        for price in PRICE_ORDER:
            pr = by_price_qz.get(price, [])
            m = agg_metrics(pr) if pr else {k: 0 for k in ['消费','UV','可运营UV','新客数','未购买UV']}
            d = calc_derived(m)
            cost = m['消费']
            pct = round(sdiv(cost, qz_cost_w) * 100, 1) if qz_cost_w else 0
            write_row(ws, row_idx, [
                week_label if price == PRICE_ORDER[0] else '', f'{pct}%', price, round(cost, 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
                f"{d['未购UV占比']}%", d['新客成本(DMP口径)'], d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
                f"{d['老客占比']}%", f"{d['新客占比']}%", f"{d['新客转化率']}%", f"{d['UV到站率']}%",
                d['UV成本'], d['CPC'], f"{d['CTR']}%", d['新客客单']
            ])
            row_idx += 1

        # 总计=各价格带加总
        m_qz = {}
        for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']:
            m_qz[k] = sum(agg_metrics(by_price_qz.get(p, []))[k] for p in PRICE_ORDER)
        d_qz = calc_derived(m_qz)
        write_row(ws, row_idx, [
            week_label, '100.0%', '合计', round(m_qz['消费'], 1), round(m_qz['UV'], 1), round(m_qz['可运营UV'], 1), round(m_qz['新客数'], 1),
            f"{d_qz['未购UV占比']}%", d_qz['新客成本(DMP口径)'], d_qz['可运营UV成本'], round(m_qz['未购买UV'], 1), d_qz['未购UV成本'],
            f"{d_qz['老客占比']}%", f"{d_qz['新客占比']}%", f"{d_qz['新客转化率']}%", f"{d_qz['UV到站率']}%",
            d_qz['UV成本'], d_qz['CPC'], f"{d_qz['CTR']}%", d_qz['新客客单']
        ], bold=True)
        qz_end = row_idx
        row_idx += 1

        if qz_end > qz_start:
            ws.merge_cells(start_row=qz_start, start_column=1, end_row=qz_end, end_column=1)
            ws.cell(row=qz_start, column=1).value = week_label
            ws.cell(row=qz_start, column=1).alignment = ALIGN_C


    # ══════════════════════════════════════════════════════════════════════
    # 全站板块-投放模式（自动/手动）
    # ══════════════════════════════════════════════════════════════════════
    QZ_MODE_HEADERS = [
        '周期', '全站板块-投放模式', '消耗占比', '全站-价格带',
        '消费', 'UV', '可运营UV', '新客数',
        '未购UV占比', '新客成本(DMP口径)', '可运营UV成本', '未购买UV', '未购UV成本',
        '老客占比', '新客占比', '新客转化率', 'UV到站率', 'UV成本', 'CPC', 'CTR', '新客客单'
    ]

    ws.cell(row=row_idx, column=1, value='全站板块-投放模式').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(QZ_MODE_HEADERS))
    row_idx += 1
    write_header_row(ws, row_idx, QZ_MODE_HEADERS)
    row_idx += 1

    # 分离全站自动/手动
    qz_auto_rows   = [r for r in quanzhan_rows if r.get('投放模式', parse_search_mode(r.get('计划名称'))) == '自动投放']
    qz_manual_rows = [r for r in quanzhan_rows if r.get('投放模式', parse_search_mode(r.get('计划名称'))) == '手动投放']
    qz_auto_cost   = agg_metrics(qz_auto_rows)['消费']
    qz_manual_cost = agg_metrics(qz_manual_rows)['消费']
    qz_auto_ratio   = round(sdiv(qz_auto_cost,   qz_cost) * 100, 1) if qz_cost else 0
    qz_manual_ratio = round(sdiv(qz_manual_cost, qz_cost) * 100, 1) if qz_cost else 0

    qz_mode_start = row_idx

    def write_qz_mode_block(grp_rows, mode_label, mode_ratio):
        """输出全站的一个投放模式区块（结构与搜索保持一致）"""
        nonlocal row_idx

        by_price = defaultdict(list)
        for r in grp_rows:
            p = get_price(r)
            if p in PRICE_ORDER:
                by_price[p].append(r)

        block_start = row_idx
        for price in PRICE_ORDER:
            pr = by_price.get(price, [])
            m = agg_metrics(pr) if pr else {k: 0 for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']}
            d = calc_derived(m)
            write_row(ws, row_idx, [
                '', '', '', price,
                round(m['消费'], 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
                f"{d['未购UV占比']}%", d['新客成本(DMP口径)'],
                d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
                f"{d['老客占比']}%", f"{d['新客占比']}%",
                f"{d['新客转化率']}%", f"{d['UV到站率']}%",
                d['UV成本'], d['CPC'], f"{d['CTR']}%", d['新客客单']
            ])
            row_idx += 1

        # 总计=各价格带加总
        m_all = {}
        for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']:
            m_all[k] = sum(agg_metrics(by_price.get(p, []))[k] for p in PRICE_ORDER)
        d_all = calc_derived(m_all)
        write_row(ws, row_idx, [
            '', '', '', '总计',
            round(m_all['消费'], 1), round(m_all['UV'], 1), round(m_all['可运营UV'], 1), round(m_all['新客数'], 1),
            f"{d_all['未购UV占比']}%", d_all['新客成本(DMP口径)'],
            d_all['可运营UV成本'], round(m_all['未购买UV'], 1), d_all['未购UV成本'],
            f"{d_all['老客占比']}%", f"{d_all['新客占比']}%",
            f"{d_all['新客转化率']}%", f"{d_all['UV到站率']}%",
            d_all['UV成本'], d_all['CPC'], f"{d_all['CTR']}%", d_all['新客客单']
        ], bold=True)
        block_end = row_idx
        row_idx += 1

        # 合并投放模式列
        ws.merge_cells(start_row=block_start, start_column=2, end_row=block_end, end_column=2)
        c = ws.cell(row=block_start, column=2)
        c.value = mode_label
        c.alignment = ALIGN_C
        c.font = FONT_BOLD

        # 合并消耗占比列
        ws.merge_cells(start_row=block_start, start_column=3, end_row=block_end, end_column=3)
        c = ws.cell(row=block_start, column=3)
        c.value = f'{mode_ratio}%'
        c.alignment = ALIGN_C

        return block_start, block_end

    # 写入自动投放
    write_qz_mode_block(qz_auto_rows, '自动投放', qz_auto_ratio)
    # 写入手动投放
    write_qz_mode_block(qz_manual_rows, '手动投放', qz_manual_ratio)

    # 合并周期列（跨整个全站板块-投放模式：自动+手动）
    qz_mode_end = row_idx - 1
    if qz_mode_end >= qz_mode_start:
        ws.merge_cells(start_row=qz_mode_start, start_column=1, end_row=qz_mode_end, end_column=1)
        c = ws.cell(row=qz_mode_start, column=1)
        c.value = f'{DATE_LABEL}（本周）'
        c.alignment = ALIGN_C

    row_idx += 1  # 空行


    set_col_widths(ws, [14, 16, 10, 10, 12, 10, 10, 10, 10, 12, 10, 12, 10, 10, 10, 10, 10, 10, 10, 12])
    print(f"  Sheet2 投放情况（按板块）: 共写入 {row_idx-1} 行")

# ══════════════════════════════════════════════════════════════════════════
# 笔记投放明细（插入 Sheet2 与 Sheet3 之间）
# ══════════════════════════════════════════════════════════════════════════
def build_sheet_note_detail(wb, rows):
    """笔记投放明细：整体+搜索+全站智投+信息流，每块按 note_id 聚合所有行"""
    from collections import defaultdict as _dd3

    ws = wb.create_sheet('笔记投放明细')
    HEADERS = ['笔记链接', '价格带', '消耗', '展现', '点击', '点击率', 'APP打开', 'APP打开成本', '新客数', '新客成本']
    BLOCKS = [('整体', None), ('搜索', '搜索'), ('全站智投', '全站智投'), ('信息流', '信息流')]

    row_idx = 1
    block_counts = []

    for block_label, placement_filter in BLOCKS:
        p_rows = rows if placement_filter is None else [
            r for r in rows if parse_placement(r.get('投放版本')) == placement_filter
        ]

        by_note = _dd3(lambda: {
            'note_id': '', '笔记链接': '', '价格带': '',
            '消耗': 0.0, '展现': 0.0, '点击': 0.0, 'app打开': 0.0, '新客数': 0.0,
        })
        for r in p_rows:
            nid = str(r.get('笔记ID', '') or '').strip()
            if not nid:
                continue
            agg = by_note[nid]
            if not agg['note_id']:
                agg['note_id']  = nid
                agg['笔记链接'] = str(r.get('笔记链接', '') or '')
                agg['价格带']   = get_price(r)
            agg['消耗']    += sf(r.get('消费', 0))
            agg['展现']    += sf(r.get('展现量', 0))
            agg['点击']    += sf(r.get('点击量', 0))
            agg['app打开'] += sf(r.get('app打开', 0))
            agg['新客数']  += sf(r.get('新客数', r.get('_dmp_xk', 0)))

        note_list = sorted(by_note.values(), key=lambda x: -x['新客数'])
        block_counts.append(f'{block_label}{len(note_list)}条')

        # 块标题（纯文本，无样式）
        ws.cell(row=row_idx, column=1, value=f'{block_label} — 笔记投放明细')
        row_idx += 1

        write_header_row(ws, row_idx, HEADERS)
        row_idx += 1

        for item in note_list:
            fee        = round(item['消耗'], 1)
            impression = round(item['展现'], 1)
            click      = round(item['点击'], 1)
            app_open   = round(item['app打开'], 1)
            xk         = round(item['新客数'], 1)
            ctr        = round(sdiv(click, impression) * 100, 1)
            app_cost   = round(sdiv(fee, app_open), 1) if app_open > 0 else 0
            xk_cost    = round(sdiv(fee, xk), 1) if xk > 0 else 0
            write_row(ws, row_idx, [
                item['笔记链接'],
                item['价格带'],
                fee,
                impression,
                click,
                f'{ctr}%',
                app_open,
                app_cost,
                xk,
                xk_cost,
            ])
            row_idx += 1

        row_idx += 1  # 块间空行

    set_col_widths(ws, [50, 10, 12, 12, 10, 10, 12, 14, 10, 12])
    print(f"  笔记投放明细: {'+'.join(block_counts)}")


# ══════════════════════════════════════════════════════════════════════════
# Sheet3: RTA账户-测试情况
# ══════════════════════════════════════════════════════════════════════════
def build_sheet3(wb, rows, last_rows):
    ws = wb.create_sheet('已安装未购RTA账户-测试情况')
    row_idx = 1
    last_label = (_start_dt - timedelta(days=7)).strftime('%m.%d') + '-' + (_end_dt - timedelta(days=7)).strftime('%m.%d')

    rta_rows = [r for r in rows if r.get('人群分类') == '未购人群']
    last_rta_rows = [r for r in last_rows if r.get('人群分类') == '未购人群']
    rta_cost = agg_metrics(rta_rows)['消费']

    # ══════════════════════════════════════════════════════════════════════
    # （一）整体投放情况
    # ══════════════════════════════════════════════════════════════════════
    HEADERS1 = ['周期', '消耗占比', '价格带', '消费', 'UV', '可运营UV', '新客数',
                '未购UV占比', '新客成本(DMP口径)', '可运营UV成本', '未购买UV', '未购UV成本',
                '老客占比', '新客占比', '新客转化率', 'UV到站率', 'UV成本', 'CPC', 'CTR', '新客客单']

    ws.cell(row=row_idx, column=1, value='（一）整体投放情况').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(HEADERS1))
    row_idx += 1
    write_header_row(ws, row_idx, HEADERS1)
    row_idx += 1

    # （一）整体投放情况：上周+本周堆叠
    for week_label, r_rows in [(last_label, last_rta_rows), (DATE_LABEL+'（本周）', rta_rows)]:
        w_cost = sum(sf(r.get('消费')) for r in r_rows)
        by_price_rta = defaultdict(list)
        for r in r_rows:
            p = get_price(r)
            if p in PRICE_ORDER:
                by_price_rta[p].append(r)

        rta_start = row_idx
        for price in PRICE_ORDER:
            pr = by_price_rta.get(price, [])
            m = agg_metrics(pr) if pr else {k: 0 for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']}
            d = calc_derived(m)
            cost = m['消费']
            pct = round(sdiv(cost, w_cost) * 100, 1) if w_cost else 0
            write_row(ws, row_idx, [
                week_label if price == PRICE_ORDER[0] else '', f'{pct}%', price, round(cost, 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
                f"{d['未购UV占比']}%", d['新客成本(DMP口径)'],
                d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
                f"{d['老客占比']}%", f"{d['新客占比']}%",
                f"{d['新客转化率']}%", f"{d['UV到站率']}%",
                d['UV成本'], d['CPC'], f"{d['CTR']}%", d['新客客单']
            ])
            row_idx += 1

        # 总计=各价格带加总
        m_all = {}
        for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']:
            m_all[k] = sum(agg_metrics(by_price_rta.get(p, []))[k] for p in PRICE_ORDER)
        d_all = calc_derived(m_all)
        write_row(ws, row_idx, [
            week_label, f'{round(sdiv(m_all["消费"], w_cost) * 100, 1) if w_cost else 0}%', '总计', round(m_all['消费'], 1), round(m_all['UV'], 1), round(m_all['可运营UV'], 1), round(m_all['新客数'], 1),
            f"{d_all['未购UV占比']}%", d_all['新客成本(DMP口径)'],
            d_all['可运营UV成本'], round(m_all['未购买UV'], 1), d_all['未购UV成本'],
            f"{d_all['老客占比']}%", f"{d_all['新客占比']}%",
            f"{d_all['新客转化率']}%", f"{d_all['UV到站率']}%",
            d_all['UV成本'], d_all['CPC'], f"{d_all['CTR']}%", d_all['新客客单']
        ], bold=True)
        rta_end = row_idx
        row_idx += 1

        if rta_end >= rta_start:
            ws.merge_cells(start_row=rta_start, start_column=1, end_row=rta_end, end_column=1)
            c = ws.cell(row=rta_start, column=1)
            c.value = week_label
            c.alignment = ALIGN_C

    row_idx += 1

    # ══════════════════════════════════════════════════════════════════════
    # （二）分优化目标投放情况
    # ══════════════════════════════════════════════════════════════════════
    HEADERS2 = ['周期', '投放模式', '优化目标', '搜索-价格带', '消费', 'UV', '可运营UV', '新客数',
                '未购UV占比', '新客成本(DMP口径)', '可运营UV成本', '未购买UV', '未购UV成本',
                '老客占比', '新客占比', '新客转化率', 'UV到站率', 'UV成本', 'CPC', 'CTR']

    ws.cell(row=row_idx, column=1, value='（二）分优化目标投放情况').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(HEADERS2))
    row_idx += 1
    write_header_row(ws, row_idx, HEADERS2)
    row_idx += 1

    # 定义投放模式分组
    MODE_GROUPS = [
        ('搜索+自动投放', 'APP支付', lambda r: parse_placement(r.get('投放版本')) == '搜索' and r.get('投放模式', parse_search_mode(r.get('计划名称'))) == '自动投放'),
        ('搜索+手动投放', 'APP支付', lambda r: parse_placement(r.get('投放版本')) == '搜索' and r.get('投放模式', parse_search_mode(r.get('计划名称'))) == '手动投放'),
        ('信息流+APP支付', 'APP支付', lambda r: parse_placement(r.get('投放版本')) == '信息流'),
        ('全站+APP支付', 'APP支付', lambda r: parse_placement(r.get('投放版本')) == '全站智投'),
    ]

    # 记录整个分优化目标区块的开始行（用于合并周期列）
    opt_block_start = row_idx

    for mode_name, opt_goal, mode_filter in MODE_GROUPS:
        mode_rows = [r for r in rta_rows if mode_filter(r)]
        mode_cost = agg_metrics(mode_rows)['消费']

        # 写入该模式的价格带行
        mode_block_start = row_idx
        by_price_mode = defaultdict(list)
        for r in mode_rows:
            p = get_price(r)
            if p in PRICE_ORDER:
                by_price_mode[p].append(r)

        for price in PRICE_ORDER:
            pr = by_price_mode.get(price, [])
            m = agg_metrics(pr) if pr else {k: 0 for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']}
            d = calc_derived(m)
            write_row(ws, row_idx, [
                '', '', '', price,
                round(m['消费'], 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
                f"{d['未购UV占比']}%", d['新客成本(DMP口径)'],
                d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
                f"{d['老客占比']}%", f"{d['新客占比']}%",
                f"{d['新客转化率']}%", f"{d['UV到站率']}%",
                d['UV成本'], d['CPC'], f"{d['CTR']}%"
            ])
            row_idx += 1

        # 总计行
        m_mode = agg_metrics(mode_rows)
        d_mode = calc_derived(m_mode)
        write_row(ws, row_idx, [
            '', '', '', '总计',
            round(m_mode['消费'], 1), round(m_mode['UV'], 1), round(m_mode['可运营UV'], 1), round(m_mode['新客数'], 1),
            f"{d_mode['未购UV占比']}%", d_mode['新客成本(DMP口径)'],
            d_mode['可运营UV成本'], round(m_mode['未购买UV'], 1), d_mode['未购UV成本'],
            f"{d_mode['老客占比']}%", f"{d_mode['新客占比']}%",
            f"{d_mode['新客转化率']}%", f"{d_mode['UV到站率']}%",
            d_mode['UV成本'], d_mode['CPC'], f"{d_mode['CTR']}%"
        ], bold=True)
        mode_block_end = row_idx
        row_idx += 1

        # 合并投放模式列
        ws.merge_cells(start_row=mode_block_start, start_column=2, end_row=mode_block_end, end_column=2)
        c = ws.cell(row=mode_block_start, column=2)
        c.value = mode_name
        c.alignment = ALIGN_C
        c.font = FONT_BOLD

        # 合并优化目标列
        ws.merge_cells(start_row=mode_block_start, start_column=3, end_row=mode_block_end, end_column=3)
        c = ws.cell(row=mode_block_start, column=3)
        c.value = opt_goal
        c.alignment = ALIGN_C

    # 合并周期列（跨整个分优化目标区块）
    opt_block_end = row_idx - 1
    if opt_block_end >= opt_block_start:
        ws.merge_cells(start_row=opt_block_start, start_column=1, end_row=opt_block_end, end_column=1)
        c = ws.cell(row=opt_block_start, column=1)
        c.value = f'{DATE_LABEL}（本周）'
        c.alignment = ALIGN_C

    row_idx += 1

    # ══════════════════════════════════════════════════════════════════════
    # （三）分品类
    # ══════════════════════════════════════════════════════════════════════
    CAT_HEADERS = ['周期', '一级品类', '二级品类', '消费', '新客数', '新客成本', 'CTR', 'CPC']

    ws.cell(row=row_idx, column=1, value='（三）分品类').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(CAT_HEADERS))
    row_idx += 1
    write_header_row(ws, row_idx, CAT_HEADERS)
    row_idx += 1

    by_cat = defaultdict(list)
    for r in rta_rows:
        yi_pin = r.get('一级品类', '') or ''
        er_pin = r.get('二级品类', '') or ''
        by_cat[(yi_pin, er_pin)].append(r)

    for (yi_pin, er_pin), cat_rows in sorted(by_cat.items(), key=lambda x: -agg_metrics(x[1])['消费']):
        m = agg_metrics(cat_rows)
        d = calc_derived(m)
        write_row(ws, row_idx, [DATE_LABEL, yi_pin, er_pin, round(m['消费'], 1), round(m['新客数'], 1), d['新客成本(DMP口径)'], f"{d['CTR']}%", d['CPC']])
        row_idx += 1

    # 分品类总计行
    m_cat_total = agg_metrics(rta_rows)
    d_cat_total = calc_derived(m_cat_total)
    write_row(ws, row_idx, [
        DATE_LABEL, '总计', '', round(m_cat_total['消费'], 1), round(m_cat_total['新客数'], 1),
        d_cat_total['新客成本(DMP口径)'], f"{d_cat_total['CTR']}%", d_cat_total['CPC']
    ], bold=True)
    row_idx += 1

    set_col_widths(ws, [14, 14, 10, 10, 12, 10, 10, 10, 10, 12, 10, 12, 10, 10, 10, 10, 10, 10, 10, 12])
    print(f"  Sheet3 RTA: 消费={rta_cost}, 写入行={row_idx-1}")

# ══════════════════════════════════════════════════════════════════════════
# Sheet4: 客产自产-投放情况
# ══════════════════════════════════════════════════════════════════════════
def build_sheet4(wb, rows, last_rows):
    ws = wb.create_sheet('客产自产-投放情况')
    row_idx = 1
    last_label = (_start_dt - timedelta(days=7)).strftime('%m.%d') + '-' + (_end_dt - timedelta(days=7)).strftime('%m.%d')

    ke_rows = [r for r in rows if parse_source_type(r.get('笔记来源', r.get('_note_source'))) == '客供']
    last_ke_rows = [r for r in last_rows if parse_source_type(r.get('笔记来源', r.get('_note_source'))) == '客供']
    zi_rows = [r for r in rows if parse_source_type(r.get('笔记来源', r.get('_note_source'))) != '客供']  # 自产素材不含客供
    ke_cost = agg_metrics(ke_rows)['消费']
    zi_cost = agg_metrics(zi_rows)['消费']

    # ══════════════════════════════════════════════════════════════════════
    # 1. 客产笔记-整体数据
    # ══════════════════════════════════════════════════════════════════════
    HEADERS_KE = ['周期', '价格带', '消费', 'UV', '可运营UV', '新客数', '未购UV占比', '新客成本(DMP口径)',
                  '可运营UV成本', '未购买UV', '未购UV成本', '老客占比', '新客占比', '新客转化率',
                  'UV到站率', 'UV成本', 'CPC', 'CTR', '新客客单']

    ws.cell(row=row_idx, column=1, value='客产笔记-整体数据').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(HEADERS_KE))
    row_idx += 1
    write_header_row(ws, row_idx, HEADERS_KE)
    row_idx += 1

    # 客产笔记：上周+本周堆叠
    for week_label, k_rows in [(last_label, last_ke_rows), (DATE_LABEL+'（本周）', ke_rows)]:
        by_price_ke = defaultdict(list)
        for r in k_rows:
            p = get_price(r)
            if p in PRICE_ORDER:
                by_price_ke[p].append(r)

        ke_start = row_idx
        for price in PRICE_ORDER:
            pr = by_price_ke.get(price, [])
            m = agg_metrics(pr) if pr else {k: 0 for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']}
            d = calc_derived(m)
            write_row(ws, row_idx, [
                week_label if price == PRICE_ORDER[0] else '', price, round(m['消费'], 1), round(m['UV'], 1), round(m['可运营UV'], 1), round(m['新客数'], 1),
                f"{d['未购UV占比']}%", d['新客成本(DMP口径)'],
                d['可运营UV成本'], round(m['未购买UV'], 1), d['未购UV成本'],
                f"{d['老客占比']}%", f"{d['新客占比']}%",
                f"{d['新客转化率']}%", f"{d['UV到站率']}%",
                d['UV成本'], d['CPC'], f"{d['CTR']}%", d['新客客单']
            ])
            row_idx += 1

        # 总计行=各价格带加总
        m_ke = {}
        for k in ['消费','UV','可运营UV','新客数','未购买UV','展现量','点击量','新客实收','老客数']:
            m_ke[k] = sum(agg_metrics(by_price_ke.get(p, []))[k] for p in PRICE_ORDER)
        d_ke = calc_derived(m_ke)
        write_row(ws, row_idx, [
            week_label, '总计', round(m_ke['消费'], 1), round(m_ke['UV'], 1), round(m_ke['可运营UV'], 1), round(m_ke['新客数'], 1),
            f"{d_ke['未购UV占比']}%", d_ke['新客成本(DMP口径)'],
            d_ke['可运营UV成本'], round(m_ke['未购买UV'], 1), d_ke['未购UV成本'],
            f"{d_ke['老客占比']}%", f"{d_ke['新客占比']}%",
            f"{d_ke['新客转化率']}%", f"{d_ke['UV到站率']}%",
            d_ke['UV成本'], d_ke['CPC'], f"{d_ke['CTR']}%", d_ke['新客客单']
        ], bold=True)
        ke_end = row_idx
        row_idx += 1

        if ke_end >= ke_start:
            ws.merge_cells(start_row=ke_start, start_column=1, end_row=ke_end, end_column=1)
            c = ws.cell(row=ke_start, column=1)
            c.value = week_label
            c.alignment = ALIGN_C

    row_idx += 2

    # ══════════════════════════════════════════════════════════════════════
    # 1.5 客产素材内容情况（按笔记来源：客供/校园/合作广场）
    # ══════════════════════════════════════════════════════════════════════
    HEADERS_KE_SOURCE = ['笔记来源', '消费占比', '消费', 'UV', '可运营UV', '新客数', '未购UV占比',
                         '新客成本', '可运营UV成本', '未购买UV', '未购UV成本', '老客占比', '新客占比',
                         '新客转化率', 'UV到站率', 'UV成本', 'CPC', 'CTR', '新客客单']

    ws.cell(row=row_idx, column=1, value='客产素材内容情况').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(HEADERS_KE_SOURCE))
    row_idx += 1
    write_header_row(ws, row_idx, HEADERS_KE_SOURCE)
    row_idx += 1

    # 按 note_id 聚合（同一笔记多个 code 合并，笔记来源取第一个非空值）
    _by_note_ke = defaultdict(lambda: {
        'note_id': '', '笔记来源': '',
        '消费': 0.0, 'UV': 0.0, '可运营UV': 0.0, '新客数': 0.0,
        '未购买UV': 0.0, '实收金额': 0.0, '新客实收': 0.0,
        '展现量': 0.0, '点击量': 0.0,
    })
    for r in ke_rows:
        nid = str(r.get('笔记ID', '') or '').strip() or str(r.get('_code', '') or '')
        if not nid:
            continue
        agg = _by_note_ke[nid]
        if not agg['note_id']:
            agg['note_id'] = nid
        if not agg['笔记来源']:
            src_val = str(r.get('笔记来源', r.get('_note_source', '')) or '').strip()
            if src_val:
                agg['笔记来源'] = src_val
        agg['消费']    += sf(r.get('消费', 0))
        agg['UV']      += sf(r.get('UV', r.get('_dmp_uv', 0)))
        agg['可运营UV'] += sf(r.get('可运营UV', r.get('_dmp_op', 0)))
        agg['新客数']   += sf(r.get('新客数', r.get('_dmp_xk', 0)))
        agg['未购买UV'] += sf(r.get('未购买UV', r.get('_dmp_unpuv', 0)))
        agg['实收金额'] += sf(r.get('实收金额', r.get('_dmp_rev', 0)))
        agg['新客实收'] += sf(r.get('新客实收', r.get('_dmp_xrev', 0)))
        agg['展现量']   += sf(r.get('展现量', 0))
        agg['点击量']   += sf(r.get('点击量', 0))

    _note_ke_rows = []
    for v in _by_note_ke.values():
        _note_ke_rows.append({
            '笔记来源':   v['笔记来源'] or '未知',
            '消费':       v['消费'],
            '_dmp_uv':    v['UV'],
            '_dmp_op':    v['可运营UV'],
            '_dmp_xk':    v['新客数'],
            '_dmp_unpuv': v['未购买UV'],
            '_dmp_rev':   v['实收金额'],
            '_dmp_xrev':  v['新客实收'],
            '展现量':     v['展现量'],
            '点击量':     v['点击量'],
        })

    # 按笔记来源分组，按消费降序
    by_ke_source = defaultdict(list)
    for r in _note_ke_rows:
        src = str(r.get('笔记来源') or '').strip() or '未知'
        by_ke_source[src].append(r)

    ke_all_cost = sum(sf(r.get('消费')) for r in _note_ke_rows)
    # 固定四个类别顺序，没有数据也要输出空行
    FIXED_KE_SOURCES = ['客供', '校园', '合作']
    # 将"合作广场"归入"合作"
    def _normalize_ke_source(src):
        if src == '合作广场': return '合作'
        return src
    # 收集实际出现的来源（排除已固定的）
    extra_ke_sources = sorted(
        [s for s in by_ke_source if _normalize_ke_source(s) not in FIXED_KE_SOURCES],
        key=lambda x: -agg_metrics(by_ke_source[x])['消费']
    )
    # 合并"合作广场"到"合作"
    merged_by_source = defaultdict(list)
    for s, rows_s in by_ke_source.items():
        merged_by_source[_normalize_ke_source(s)].extend(rows_s)
    ordered_ke_sources = [(s, merged_by_source.get(s, [])) for s in FIXED_KE_SOURCES] + \
                         [(s, merged_by_source[s]) for s in extra_ke_sources]

    for src, src_rows in ordered_ke_sources:
        src_cost = agg_metrics(src_rows)['消费']
        src_pct = round(sdiv(src_cost, ke_all_cost) * 100, 1) if ke_all_cost else 0
        m_src = agg_metrics(src_rows)
        d_src = calc_derived(m_src)
        write_row(ws, row_idx, [
            src, f'{src_pct}%', round(m_src['消费'], 1), round(m_src['UV'], 1), round(m_src['可运营UV'], 1), round(m_src['新客数'], 1),
            f"{d_src['未购UV占比']}%", d_src['新客成本(DMP口径)'],
            d_src['可运营UV成本'], round(m_src['未购买UV'], 1), d_src['未购UV成本'],
            f"{d_src['老客占比']}%", f"{d_src['新客占比']}%",
            f"{d_src['新客转化率']}%", f"{d_src['UV到站率']}%",
            d_src['UV成本'], d_src['CPC'], f"{d_src['CTR']}%", d_src['新客客单']
        ])
        row_idx += 1

    # 总计行
    m_ke_tot = agg_metrics(ke_rows)
    d_ke_tot = calc_derived(m_ke_tot)
    write_row(ws, row_idx, [
        '总计', '100.0%', round(m_ke_tot['消费'], 1), round(m_ke_tot['UV'], 1), round(m_ke_tot['可运营UV'], 1), round(m_ke_tot['新客数'], 1),
        f"{d_ke_tot['未购UV占比']}%", d_ke_tot['新客成本(DMP口径)'],
        d_ke_tot['可运营UV成本'], round(m_ke_tot['未购买UV'], 1), d_ke_tot['未购UV成本'],
        f"{d_ke_tot['老客占比']}%", f"{d_ke_tot['新客占比']}%",
        f"{d_ke_tot['新客转化率']}%", f"{d_ke_tot['UV到站率']}%",
        d_ke_tot['UV成本'], d_ke_tot['CPC'], f"{d_ke_tot['CTR']}%", d_ke_tot['新客客单']
    ], bold=True)
    row_idx += 3

    # ══════════════════════════════════════════════════════════════════════
    # 2. 自产素材投放情况（按一级品类+二级品类层级）
    # ══════════════════════════════════════════════════════════════════════
    HEADERS_ZI = ['一级品类', '二级品类', '消费占比', '消费', 'UV', '可运营UV', '新客数', '未购UV占比',
                  '新客成本', '可运营UV成本', '未购买UV', '未购UV成本', '老客占比', '新客占比',
                  '新客转化率', 'UV到站率', 'UV成本', 'CPC', 'CTR', '新客客单']

    ws.cell(row=row_idx, column=1, value='自产素材投放情况').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(HEADERS_ZI))
    row_idx += 1
    write_header_row(ws, row_idx, HEADERS_ZI)
    row_idx += 1

    # 按一级品类分组（直接使用前端数据的"一级品类"字段，并标准化处理）
    by_yi_pin = defaultdict(list)
    for r in zi_rows:
        yi_pin_raw = r.get('一级品类', '') or ''
        yi_pin = normalize_category(yi_pin_raw) if yi_pin_raw else '未知'
        by_yi_pin[yi_pin].append(r)

    # 按消费排序一级品类
    sorted_yi_pins = sorted(by_yi_pin.items(), key=lambda x: -agg_metrics(x[1])['消费'])

    for yi_pin, yi_rows in sorted_yi_pins:
        yi_cost = agg_metrics(yi_rows)['消费']
        yi_pct = round(sdiv(yi_cost, zi_cost) * 100, 1) if zi_cost else 0

        # 二级品类先行（按消费降序）
        by_er_pin = defaultdict(list)
        for r in yi_rows:
            er_pin_raw = r.get('二级品类', '') or ''
            er_pin = normalize_category(er_pin_raw) if er_pin_raw else '未知'
            by_er_pin[er_pin].append(r)

        sorted_er_pins = sorted(by_er_pin.items(), key=lambda x: -agg_metrics(x[1])['消费'])
        for er_pin, er_rows in sorted_er_pins:
            er_cost = agg_metrics(er_rows)['消费']
            er_pct = round(sdiv(er_cost, zi_cost) * 100, 1) if zi_cost else 0
            m_er = agg_metrics(er_rows)
            d_er = calc_derived(m_er)
            write_row(ws, row_idx, [
                '', er_pin, f'{er_pct}%', round(m_er['消费'], 1), round(m_er['UV'], 1), round(m_er['可运营UV'], 1), round(m_er['新客数'], 1),
                f"{d_er['未购UV占比']}%", d_er['新客成本(DMP口径)'],
                d_er['可运营UV成本'], round(m_er['未购买UV'], 1), d_er['未购UV成本'],
                f"{d_er['老客占比']}%", f"{d_er['新客占比']}%",
                f"{d_er['新客转化率']}%", f"{d_er['UV到站率']}%",
                d_er['UV成本'], d_er['CPC'], f"{d_er['CTR']}%", d_er['新客客单']
            ])
            row_idx += 1

        # 一级品类汇总行（置底）
        m_yi = agg_metrics(yi_rows)
        d_yi = calc_derived(m_yi)
        write_row(ws, row_idx, [
            yi_pin, '', f'{yi_pct}%', round(m_yi['消费'], 1), round(m_yi['UV'], 1), round(m_yi['可运营UV'], 1), round(m_yi['新客数'], 1),
            f"{d_yi['未购UV占比']}%", d_yi['新客成本(DMP口径)'],
            d_yi['可运营UV成本'], round(m_yi['未购买UV'], 1), d_yi['未购UV成本'],
            f"{d_yi['老客占比']}%", f"{d_yi['新客占比']}%",
            f"{d_yi['新客转化率']}%", f"{d_yi['UV到站率']}%",
            d_yi['UV成本'], d_yi['CPC'], f"{d_yi['CTR']}%", d_yi['新客客单']
        ], bold=True)
        row_idx += 1

    # 总计行
    m_zi = agg_metrics(zi_rows)
    d_zi = calc_derived(m_zi)
    write_row(ws, row_idx, [
        '总计', '', '100.0%', round(m_zi['消费'], 1), round(m_zi['UV'], 1), round(m_zi['可运营UV'], 1), round(m_zi['新客数'], 1),
        f"{d_zi['未购UV占比']}%", d_zi['新客成本(DMP口径)'],
        d_zi['可运营UV成本'], round(m_zi['未购买UV'], 1), d_zi['未购UV成本'],
        f"{d_zi['老客占比']}%", f"{d_zi['新客占比']}%",
        f"{d_zi['新客转化率']}%", f"{d_zi['UV到站率']}%",
        d_zi['UV成本'], d_zi['CPC'], f"{d_zi['CTR']}%", d_zi['新客客单']
    ], bold=True)
    row_idx += 2

    # ══════════════════════════════════════════════════════════════════════
    # 3. 自产素材内容情况（按笔记来源）
    # ══════════════════════════════════════════════════════════════════════
    HEADERS_SOURCE = ['笔记来源', '消费占比', '消费', 'UV', '可运营UV', '新客数', '未购UV占比',
                      '新客成本', '可运营UV成本', '未购买UV', '未购UV成本', '老客占比', '新客占比',
                      '新客转化率', 'UV到站率', 'UV成本', 'CPC', 'CTR', '新客客单']

    ws.cell(row=row_idx, column=1, value='自产素材内容情况').font = FONT_BOLD
    ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=len(HEADERS_SOURCE))
    row_idx += 1
    write_header_row(ws, row_idx, HEADERS_SOURCE)
    row_idx += 1

    # 先按 note_id 聚合，同一笔记多个 code 合并，笔记来源取第一个非空值
    from collections import defaultdict as _dd4
    _by_note_src = _dd4(lambda: {
        'note_id': '', '笔记来源': '',
        '消费': 0.0, 'UV': 0.0, '可运营UV': 0.0, '新客数': 0.0,
        '未购买UV': 0.0, '实收金额': 0.0, '新客实收': 0.0,
        '展现量': 0.0, '点击量': 0.0,
    })
    for r in zi_rows:
        nid = str(r.get('笔记ID', '') or '').strip() or str(r.get('_code', '') or '')
        if not nid:
            continue
        agg = _by_note_src[nid]
        if not agg['note_id']:
            agg['note_id'] = nid
        if not agg['笔记来源']:
            src_val = str(r.get('笔记来源', r.get('_note_source', '')) or '').strip()
            if src_val:
                agg['笔记来源'] = src_val
        agg['消费']    += sf(r.get('消费', 0))
        agg['UV']      += sf(r.get('UV', r.get('_dmp_uv', 0)))
        agg['可运营UV'] += sf(r.get('可运营UV', r.get('_dmp_op', 0)))
        agg['新客数']   += sf(r.get('新客数', r.get('_dmp_xk', 0)))
        agg['未购买UV'] += sf(r.get('未购买UV', r.get('_dmp_unpuv', 0)))
        agg['实收金额'] += sf(r.get('实收金额', r.get('_dmp_rev', 0)))
        agg['新客实收'] += sf(r.get('新客实收', r.get('_dmp_xrev', 0)))
        agg['展现量']   += sf(r.get('展现量', 0))
        agg['点击量']   += sf(r.get('点击量', 0))
    # 聚合后的虚拟行列表（结构兼容 agg_metrics）
    _note_src_rows = []
    for v in _by_note_src.values():
        _note_src_rows.append({
            '笔记来源':  v['笔记来源'] or '未知',
            '消费':      v['消费'],
            '_dmp_uv':   v['UV'],
            '_dmp_op':   v['可运营UV'],
            '_dmp_xk':   v['新客数'],
            '_dmp_unpuv': v['未购买UV'],
            '_dmp_rev':  v['实收金额'],
            '_dmp_xrev': v['新客实收'],
            '展现量':    v['展现量'],
            '点击量':    v['点击量'],
        })

    # 按笔记来源分组
    by_source = defaultdict(list)
    for r in _note_src_rows:
        src = str(r.get('笔记来源') or '').strip() or '未知'
        by_source[src].append(r)

    all_cost = sum(sf(r.get('消费')) for r in _note_src_rows)

    sorted_sources = sorted(by_source.items(), key=lambda x: -agg_metrics(x[1])['消费'])
    for src, src_rows in sorted_sources:
        src_cost = agg_metrics(src_rows)['消费']
        src_pct = round(sdiv(src_cost, all_cost) * 100, 1) if all_cost else 0
        m_src = agg_metrics(src_rows)
        d_src = calc_derived(m_src)
        write_row(ws, row_idx, [
            src, f'{src_pct}%', round(m_src['消费'], 1), round(m_src['UV'], 1), round(m_src['可运营UV'], 1), round(m_src['新客数'], 1),
            f"{d_src['未购UV占比']}%", d_src['新客成本(DMP口径)'],
            d_src['可运营UV成本'], round(m_src['未购买UV'], 1), d_src['未购UV成本'],
            f"{d_src['老客占比']}%", f"{d_src['新客占比']}%",
            f"{d_src['新客转化率']}%", f"{d_src['UV到站率']}%",
            d_src['UV成本'], d_src['CPC'], f"{d_src['CTR']}%", d_src['新客客单']
        ])
        row_idx += 1

    # 总计行
    write_row(ws, row_idx, [
        '总计', '100.0%', round(m_zi['消费'], 1), round(m_zi['UV'], 1), round(m_zi['可运营UV'], 1), round(m_zi['新客数'], 1),
        f"{d_zi['未购UV占比']}%", d_zi['新客成本(DMP口径)'],
        d_zi['可运营UV成本'], round(m_zi['未购买UV'], 1), d_zi['未购UV成本'],
        f"{d_zi['老客占比']}%", f"{d_zi['新客占比']}%",
        f"{d_zi['新客转化率']}%", f"{d_zi['UV到站率']}%",
        d_zi['UV成本'], d_zi['CPC'], f"{d_zi['CTR']}%", d_zi['新客客单']
    ], bold=True)

    set_col_widths(ws, [12, 10, 10, 12, 10, 10, 10, 10, 12, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 12])
    print(f"  Sheet4 客产自产: 客产={len(ke_rows)}行, 自产={len(zi_rows)}行")

# ══════════════════════════════════════════════════════════════════════════
# Sheet5: 优质跑量素材（本月Top 10，按价格带+品类分组）
# 流程：
#   1. 计算本月日期范围
#   2. 从聚光API拉取本月creative数据
#   3. 从DMP获取本月数据（agent采集）
#   4. 合并数据，按新客数降序取Top 10
#   5. 用note API获取note_jump_url
# ══════════════════════════════════════════════════════════════════════════
def fetch_monthly_creative_data(start_date, end_date, note_mapping=None):
    """
    从聚光API拉取本月creative数据

    注意：聚光API不支持跨月查询，需要分批按周查询
    """
    from data_fetcher import DataFetcher
    from token_manager import TokenManager

    tm = TokenManager()
    df = DataFetcher(tm)

    # 解析日期
    start_dt = datetime.strptime(start_date, '%Y-%m-%d')
    end_dt = datetime.strptime(end_date, '%Y-%m-%d')

    all_rows = []
    seen_keys = set()  # 去重：note_id + campaign_id + date

    for acct in CONFIG['accounts']:
        acct_id = acct['id']
        acct_name = acct['name']
        print(f"  拉取账户 {acct_name} 本月数据...")

        # 分批查询（每周一批）
        batch_start = start_dt
        while batch_start <= end_dt:
            # 计算批次结束日期（最多7天）
            batch_end = min(batch_start + timedelta(days=6), end_dt)
            batch_start_str = batch_start.strftime('%Y-%m-%d')
            batch_end_str = batch_end.strftime('%Y-%m-%d')

            print(f"    批次: {batch_start_str} ~ {batch_end_str}")

            result = df.fetch(
                endpoint='creative',
                advertiser_id=acct_id,
                start_date=batch_start_str,
                end_date=batch_end_str,
                time_unit='SUMMARY',
                page_size=500
            )

            if result and result.get('data_list'):
                for row in result['data_list']:
                    # 按note_id汇总（去重）
                    note_id = str(row.get('note_id') or '').strip()
                    campaign_id = str(row.get('campaign_id') or '').strip()
                    key = f"{note_id}_{campaign_id}"

                    if key not in seen_keys:
                        seen_keys.add(key)
                        row['归属账户'] = acct_name
                        row['人群分类'] = '已购人群' if acct_name in ACCOUNT_PRICE else '未购人群'
                        all_rows.append(row)
                print(f"      获取 {len(result['data_list'])} 条，累计 {len(all_rows)} 条")

            batch_start = batch_end + timedelta(days=1)

    # 按note_id汇总数据
    if all_rows:
        all_rows = aggregate_by_note(all_rows)

    # 添加监测点位码（通过 note_id 查 note_mapping）
    if note_mapping:
        for r in all_rows:
            note_id = str(r.get('note_id') or '').strip()
            codes = note_mapping.get(note_id, [])
            r['监测点位码'] = codes[0] if codes else ''

    return all_rows

def aggregate_by_note(rows):
    """按note_id汇总数据"""
    from collections import defaultdict

    by_note = defaultdict(lambda: {
        'fee': 0, 'impression': 0, 'click': 0, 'interaction': 0,
        'note_id': '', 'campaign_name': '', '归属账户': '', '人群分类': '',
        '一级品类': '', '二级品类': ''
    })

    for r in rows:
        note_id = str(r.get('note_id') or '').strip()
        if not note_id:
            continue

        agg = by_note[note_id]
        agg['note_id'] = note_id
        agg['fee'] += sf(r.get('fee', 0))
        agg['impression'] += sf(r.get('impression', 0))
        agg['click'] += sf(r.get('click', 0))
        agg['interaction'] += sf(r.get('interaction', 0))

        # 保留第一条记录的其他字段
        if not agg['campaign_name']:
            agg['campaign_name'] = r.get('campaign_name', '')
            agg['归属账户'] = r.get('归属账户', '')
            agg['人群分类'] = r.get('人群分类', '')
            # 从计划名称解析品类
            yi_pin, er_pin = get_category_parts(r.get('campaign_name'))
            agg['一级品类'] = yi_pin
            agg['二级品类'] = er_pin

    return list(by_note.values())

def fetch_monthly_dmp_data(start_ms, end_ms):
    """
    从DMP获取本月数据（需要agent采集，这里先尝试读取缓存）

    Args:
        start_ms: 月初毫秒时间戳
        end_ms: 月末毫秒时间戳

    Returns:
        dict: {code: {UV, 新客数, ...}}
    """
    # 先尝试读取本月DMP缓存
    monthly_dmp_path = CONFIGS_DIR / 'dmp_monthly.json'
    if monthly_dmp_path.exists():
        with open(monthly_dmp_path, encoding='utf-8') as f:
            data = json.load(f)
        print(f"[DMP月度] 从缓存加载 {len(data)} 条")
        return data

    # 无缓存时提示需要agent采集
    print("[DMP月度] 未找到 dmp_monthly.json，需要agent采集本月DMP数据")
    print(f"[DMP月度] 时间范围: start_ms={start_ms}, end_ms={end_ms}")
    return {}

def fetch_note_urls(note_ids, month_start_str, api_month_end_str):
    """
    从聚光note API获取笔记链接（不使用filter，全量拉取后按 note_id 匹配）
    """
    from data_fetcher import DataFetcher
    from token_manager import TokenManager

    month_end_str = api_month_end_str
    tm = TokenManager()
    df = DataFetcher(tm)

    note_url_map = {}
    for acct in CONFIG['accounts']:
        result = df.fetch(
            endpoint='note',
            advertiser_id=acct['id'],
            start_date=month_start_str,
            end_date=month_end_str,
            time_unit='DAY',
            page_size=500
        )
        if result and result.get('data_list'):
            for row in result['data_list']:
                nid = str(row.get('note_id', '') or '').strip()
                url = str(row.get('note_jump_url', '') or '').strip()
                if nid and url and nid not in note_url_map:
                    note_url_map[nid] = url

    print(f"  共获取 {len(note_url_map)} 条笔记链接")
    return note_url_map

def build_sheet6(wb, rows):
    ws = wb.create_sheet('前端数据')
    HEADERS = ['时间', '笔记ID', '计划名称', '计划ID', '归属账户', '价格带', '投放版本', '投放模式', '消费', '展现量', '点击量', '监测点位码',
               '笔记来源', '一级品类', '二级品类', '人群', '人群分类', 'UV', '可运营UV', '新客数', '未购买UV',
               '实收金额', '新客实收', '老客数', 'APP打开', 'APP打开成本']
    write_header_row(ws, 1, HEADERS)

    sorted_rows = sorted(rows, key=lambda r: (r.get('价格带', '') or '', -sf(r.get('_dmp_xk', r.get('新客数', 0)))))
    for i, r in enumerate(sorted_rows, 2):
        yi_pin = r.get('一级品类', '') or ''
        er_pin = r.get('二级品类', '') or ''
        is_supp = r.get('_is_supplement', False)
        write_row(ws, i, [
            DATE_LABEL, r.get('笔记ID', ''), r.get('计划名称', ''), r.get('计划ID', ''), r.get('归属账户', r.get('账户名称', '')),
            r.get('价格带', ''), parse_placement(r.get('投放版本')), r.get('投放模式', ''),
            '' if is_supp else sf(r.get('消费')),
            '' if is_supp else sf(r.get('展现量')),
            '' if is_supp else sf(r.get('点击量')),
            r.get('_code', r.get('监测点位码', '')), r.get('笔记来源', r.get('_note_source', '')),
            yi_pin, er_pin, _parse_crowd_from_name(str(r.get('人群') or r.get('定向名称') or '').strip()), r.get('人群分类', ''),
            sf(r.get('_dmp_uv', r.get('UV', 0))), sf(r.get('_dmp_op', r.get('可运营UV', 0))),
            sf(r.get('_dmp_xk', r.get('新客数', 0))), sf(r.get('_dmp_unpuv', r.get('未购买UV', 0))),
            sf(r.get('_dmp_rev', r.get('实收金额', 0))), sf(r.get('_dmp_xrev', r.get('新客实收', 0))),
            sf(r.get('_dmp_lk', r.get('老客数', 0))),
            '' if is_supp else sf(r.get('app打开', 0)),
            '' if is_supp else sdiv(sf(r.get('消费')), sf(r.get('app打开', 0)))
        ])

    set_col_widths(ws, [12, 28, 40, 20, 20, 10, 12, 10, 12, 12, 12, 12, 12, 12, 12, 16, 12, 10, 10, 10, 10, 12, 12, 10, 12, 12])
    print(f"  Sheet6 前端数据: {len(rows)} 行")

# ══════════════════════════════════════════════════════════════════════════
# Sheet5: 月跑量数据（DMP驱动 → 价格带分组 → 新客数降序）# ══════════════════════════════════════════════════════════════════════════
# Sheet5: 月跑量数据（DMP驱动 → 价格带分组 → 新客数降序）
# ══════════════════════════════════════════════════════════════════════════
def build_sheet5(wb, dmp_data, this_week_key, code_mapping, note_mapping, period_start_str, period_end_str):
    """Sheet5: 月跑量数据 — DMP驱动 + 价格带分组 + 新客数降序"""
    s_start = datetime.strptime(period_start_str, '%Y-%m-%d')
    s_end   = datetime.strptime(period_end_str,   '%Y-%m-%d')

    # 跨月判断：跨月用本周 weekly 数据；不跨月用 monthly 合并数据
    is_cross_month = (s_start.month != s_end.month)
    if is_cross_month:
        # 跨月：直接用本周7天 DMP 数据
        sheet5_dmp = dmp_data.get('weekly', {}).get(this_week_key, {})
        s6_start_str = period_start_str
        s6_end_str   = period_end_str
        print(f'  [Sheet5] 跨月，使用本周weekly DMP: {len(sheet5_dmp)}条')
    else:
        # 不跨月：合并当月所有 monthly 数据
        monthly = dmp_data.get('monthly', {})
        sheet5_dmp = {}
        for ym, data in monthly.items():
            if not isinstance(data, dict):
                continue
            # 只取本月数据（ym 格式 2026-05）
            if not ym.startswith(s_end.strftime('%Y-%m')):
                continue
            for code, vals in data.items():
                if code not in sheet5_dmp:
                    sheet5_dmp[code] = dict(vals)
                else:
                    for k, v in vals.items():
                        sheet5_dmp[code][k] = sheet5_dmp[code].get(k, 0) + (v or 0)
        if not sheet5_dmp:
            # monthly 无本月数据，fallback 到本周 weekly
            sheet5_dmp = dmp_data.get('weekly', {}).get(this_week_key, {})
            print(f'  [Sheet5] 不跨月但monthly无数据，fallback到weekly: {len(sheet5_dmp)}条')
        else:
            print(f'  [Sheet5] 不跨月，使用monthly DMP: {len(sheet5_dmp)}条')
        s6_start_str = s_start.replace(day=1).strftime('%Y-%m-%d')
        s6_end_str   = period_end_str

    # 用 sheet5_dmp 替代传入的 dmp_data
    dmp_data = sheet5_dmp

    # 不跨月时周期从月初到本周末；跨月时用本周起止
    if is_cross_month:
        month_label = f"{s_start.month}.{s_start.day}-{s_end.month}.{s_end.day}"
    else:
        month_label = f"{s_end.month}.1-{s_end.month}.{s_end.day}"
    month_num   = s_end.month  # sheet名用结束月

    ws = wb.create_sheet(f'{month_num}月跑量数据')
    HEADERS = ['周期', '价格带', '品类', '笔记ID', 'DMP名称', '笔记截图', '笔记链接',
               '消费', '展现量', '新客数', 'UV']
    write_header_row(ws, 1, HEADERS)

    # ── Step 1: DMP → code_items（仅保留有 note_id 的） ────────────────────
    code_items = []
    for code, dmp in dmp_data.items():
        entry = code_mapping.get(code, {})
        if not entry:
            continue
        note_id = entry.get('note_id', '')
        if not note_id:
            continue
        code_items.append({
            'code': code, 'note_id': note_id,
            'point_name': entry.get('point_name', ''),
            'note_source': entry.get('note_source', ''),
            'placement': entry.get('placement', ''),
            'xk': sf(dmp.get('新客数', 0)),
            'uv': sf(dmp.get('UV', 0)),
            'fee': 0, 'impression': 0,
        })
    if not code_items:
        print("  Sheet5: DMP数据为空，跳过")
        return

    # ── Step 1.5: 按 note_id 聚合去重（同一笔记对应多个 code 时累加） ────
    from collections import defaultdict as _dd
    _by_note = _dd(lambda: {
        'code': '', 'note_id': '', 'point_name': '', 'note_source': '',
        'placement': '', 'xk': 0, 'uv': 0, 'fee': 0, 'impression': 0,
    })
    for item in code_items:
        nid = item['note_id']
        agg = _by_note[nid]
        if not agg['note_id']:          # 第一次出现，复制非数值字段
            agg['code']        = item['code']
            agg['note_id']     = nid
            agg['point_name']  = item['point_name']
            agg['note_source'] = item['note_source']
            agg['placement']   = item['placement']
        agg['xk']  += item['xk']
        agg['uv']  += item['uv']
        agg['fee'] += item['fee']
        agg['impression'] += item['impression']
    code_items = list(_by_note.values())
    print(f"  Sheet5 去重后: {len(code_items)} 个唯一笔记")

    # ── Step 2: 调聚光 creative API 匹配 note_id → 获取 acct_name/消费/展现 ─
    all_note_ids = set(item['note_id'] for item in code_items)
    note_creative = {}
    from token_manager import TokenManager
    from data_fetcher import DataFetcher
    tm = TokenManager()
    df = DataFetcher(tm)
    for acct in CONFIG['accounts']:
        result = df.fetch(
            endpoint='creative', advertiser_id=acct['id'],
            start_date=s6_start_str, end_date=s6_end_str,
            time_unit='SUMMARY', split_columns=['deliveryMode'], page_size=500
        )
        if not result or not result.get('data_list'):
            continue
        for r in result['data_list']:
            nid = str(r.get('note_id', '') or '').strip()
            if nid not in all_note_ids:
                continue
            if nid not in note_creative:
                note_creative[nid] = {
                    'campaign_name': r.get('campaign_name', ''),
                    'acct_name': acct['name'],
                    'fee': 0, 'impression': 0,
                }
            note_creative[nid]['fee']       += sf(r.get('fee', 0))
            note_creative[nid]['impression'] += sf(r.get('impression', 0))
    print(f"  聚光匹配 note_id: {len(note_creative)} / {len(all_note_ids)}")

    # ── Step 3: 从聚光 acct_name 推导价格带 + 品类，分组排序 ──────────────
    from collections import defaultdict
    KDJ_FROM_ACCT = {'低': '低客单', '中': '中客单', '高': '高客单'}
    groups = defaultdict(list)
    for item in code_items:
        nc = note_creative.get(item['note_id'], {})
        if nc:
            acct_name = nc.get('acct_name', '')
            if '美妆' in acct_name:
                price_band = '美妆'
            else:
                price_band = '其他'
                for seg in reversed(acct_name.split('-')):
                    if seg in KDJ_FROM_ACCT:
                        price_band = KDJ_FROM_ACCT[seg]
                        break
            campaign_name = nc.get('campaign_name', '')
            yi_pin, er_pin = get_category_parts(campaign_name)
            item['fee']        = sf(nc.get('fee', 0))
            item['impression'] = si(nc.get('impression', 0))
            item['placement']  = PLACEMENT_MAP.get(item.get('placement', ''), item.get('placement', ''))
        else:
            price_band = '其他'
            yi_pin, er_pin = '', ''
        item['price_band'] = price_band
        item['yi_pin']     = yi_pin
        item['er_pin']     = er_pin
        groups[price_band].append(item)
    for band in groups:
        groups[band].sort(key=lambda x: x['xk'], reverse=True)

    # ── Step 3.5: 全局新客数 Top 10，再重新分组 ──────────────────────────
    all_items = [item for items in groups.values() for item in items]
    all_items.sort(key=lambda x: x['xk'], reverse=True)
    top_items = [item for item in all_items if item["xk"] > 0]
    groups = defaultdict(list)
    for item in top_items:
        groups[item['price_band']].append(item)

    # ── Step 4: 按价格带分组写入 ──────────────────────────────────────────
    band_order = ['低客单', '中客单', '高客单', '美妆', '其他']
    row_idx = 2
    total_rows = 0
    for band in band_order:
        items = groups.get(band, [])
        if not items:
            continue
        merge_start = row_idx  # 同价格带合并起点
        for item in items:
            category = f"{item['yi_pin']}-{item['er_pin']}" if item['er_pin'] else item['yi_pin']
            write_row(ws, row_idx, [
                month_label,
                item['price_band'],
                category,
                item['note_id'],
                item['point_name'],
                '',               # 笔记截图留空
                '',               # 笔记链接留空
                round(item['fee'], 1) if item['fee'] > 0 else '',
                round(item['impression'], 1),
                round(item['xk'], 1),
                round(item['uv'], 1),
            ])
            row_idx += 1
            total_rows += 1
        # 合并同价格带单元格（B列）
        if total_rows > 0 and row_idx - 1 > merge_start:
            ws.merge_cells(start_row=merge_start, start_column=2, end_row=row_idx - 1, end_column=2)

    set_col_widths(ws, [12, 10, 10, 28, 40, 12, 50, 12, 10, 12, 10])
    print(f"  Sheet5 月跑量数据: {total_rows} 行")

def run_validation(rows, note_mapping, code_mapping, dmp_data):
    """
    校验前置（在生成 Sheet 之前调用）。
    rows 已经过 merge_dmp_data 处理，每行含 _code 字段。

    校验2（统一）：mapping 里所有 code，只要最终没被分配到行就记录。
                   不区分原因（笔记未返回 / 行数不足 / 精确匹配失败），一律捕获。
                   格式：{note_id, code, dmp_uv}
    校验6：DMP 有 UV，但 code 不在任何 mapping 中（无法回补）
           格式：{code, dmp_uv}
    patched 字段由 build_supplement_rows() 在原地填充。
    """
    # 已分配的 code 集合（出现在 rows 里的）
    assigned_codes = set()
    for r in rows:
        code = str(r.get('_code') or r.get('监测点位码') or '').strip()
        if code:
            assigned_codes.add(code)

    all_mapped_codes = set(code_mapping.keys())
    for codes in note_mapping.values():
        all_mapped_codes.update(codes)

    result = {
        'start_date': _start_dt.strftime('%Y-%m-%d'),
        'end_date':   _end_dt.strftime('%Y-%m-%d'),
        'check2': [],
        'check6': [],
    }

    # 校验2：mapping 里所有 code，只要没被分配到行就记录
    for note_id, codes in note_mapping.items():
        for c in codes:
            if c not in assigned_codes:
                result['check2'].append({
                    'note_id': note_id,
                    'code':    c,
                    'dmp_uv':  sf(dmp_data.get(c, {}).get('UV', 0)),
                })

    # 校验6：DMP 有 UV，但 code 不在任何 mapping 中
    for code, dmp_vals in dmp_data.items():
        uv = sf(dmp_vals.get('UV', 0))
        if uv > 0 and code not in all_mapped_codes:
            result['check6'].append({'code': code, 'dmp_uv': uv})

    return result


def build_supplement_rows(val_result, code_mapping, dmp_data):
    """
    对 check2 中 DMP UV > 0 的 code，尝试构造虚拟补行。
    条件：code_mapping[code] 中必须有 placement（G列）和 account（H列）。
    同时在 val_result 中原地标记 patched=True/False。
    返回虚拟行列表（可直接 extend 到 rows）。
    """
    KDJ_MAP_LOCAL = {
        '低': '低客单', '中': '中客单', '高': '高客单',
    }
    rows_out = []

    for item in val_result.get('check2', []):
        if item['dmp_uv'] <= 0:
            continue
        code  = item['code']
        entry = code_mapping.get(code, {})
        placement = str(entry.get('placement', '') or '').strip()
        account   = str(entry.get('account',   '') or '').strip()
        # placement 为空时，从计划名称 index[2] 推断版位
        if not placement:
            _cname_parts = str(entry.get('campaign_name', '') or '').split('-')
            _seg2 = _cname_parts[2].strip() if len(_cname_parts) > 2 else ''
            if '信' in _seg2:   placement = '信息流'
            elif '搜' in _seg2: placement = '搜索'
            elif '全' in _seg2: placement = '全站智投'
        if not placement or not account:
            item['patched'] = False
            continue

        dmp   = dmp_data.get(code, {})
        ke    = sf(dmp.get('客户数',   0))
        xk    = sf(dmp.get('新客数',   0))
        uv    = sf(dmp.get('UV',       0))
        unpuv = sf(dmp.get('未购买UV', 0))
        rev   = sf(dmp.get('实收金额', 0))
        xrev  = sf(dmp.get('新客实收', 0))
        op    = sf(dmp.get('可运营UV', 0))
        lk    = ke - xk
        # 价格带推导
        pb = ''
        if account:
            if '美妆' in account: pb = '美妆'
            else:
                for seg in reversed(account.split('-')):
                    if seg in ('低', '中', '高'):
                        pb = {'低': '低客单', '中': '中客单', '高': '高客单'}.get(seg, '')
                        break
        last_char = account[-1] if account else ''
        kdj   = KDJ_MAP_LOCAL.get(last_char, '')

        campaign_name_sup = entry.get('campaign_name', '')
        yi_pin_sup, er_pin_sup = get_category_parts(campaign_name_sup)
        crowd_sup = _parse_crowd_from_name(campaign_name_sup)
        # delivery_mode 从计划名称末尾推断（-自/-手）
        delivery_mode_sup = entry.get('delivery_mode', '') or parse_search_mode(campaign_name_sup) or ''

        sup_row = {
            '归属账户':   account,
            '投放版本':   placement,
            '价格带':     pb,
            '投放模式':   delivery_mode_sup,
            '客单价':     kdj,
            '笔记ID':     entry.get('note_id', item.get('note_id', '')),
            '监测点位码': code,
            '笔记来源':   entry.get('note_source', ''),
            '计划名称':   campaign_name_sup,
            '一级品类':   yi_pin_sup,
            '二级品类':   er_pin_sup,
            '人群':       crowd_sup,
            '消费':       None,
            '展现量':     None,
            '点击量':     None,
            '_code':      code,
            '_note_source': entry.get('note_source', ''),
            '_dmp_uv':    uv,
            '_dmp_unpuv': unpuv,
            '_dmp_op':    op,
            '_dmp_xk':    xk,
            '_dmp_rev':   rev,
            '_dmp_xrev':  xrev,
            '_dmp_ke':    ke,
            '_dmp_lk':    lk,
            '_is_supplement': True,
            '人群分类':   '已购人群',
        }
        item['patched'] = True
        rows_out.append(sup_row)

    return rows_out


def save_validation(val_result):
    """写 output/validation_{startMMDD}_{endMMDD}.json 并打印摘要"""
    start_dt = datetime.strptime(val_result['start_date'], '%Y-%m-%d')
    end_dt   = datetime.strptime(val_result['end_date'],   '%Y-%m-%d')
    fname    = f"validation_{start_dt.month}{start_dt.day:02d}_{end_dt.month}{end_dt.day:02d}.json"
    out_path = OUTPUT_DIR / fname
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(val_result, f, ensure_ascii=False, indent=2)

    c2        = val_result['check2']
    c6        = val_result['check6']
    c2_uv     = sum(1 for x in c2 if x['dmp_uv'] > 0)
    c2_patched= sum(1 for x in c2 if x['dmp_uv'] > 0 and x.get('patched', False))
    c6_total  = len(c6)
    total_uv  = c2_uv + c6_total
    total_pat = c2_patched

    print(f"\n[OK] 校验完成: {fname}")
    print(f"  校验2（code未分配）: 共 {len(c2)} 条，UV>0 的 {c2_uv} 条，已回补 {c2_patched} 个")
    print(f"  校验6（无mapping）  : 共 {c6_total} 条（全部UV>0，无法回补）")
    print(f"  【汇总】UV>0 缺失 {total_uv} 个，已回补 {total_pat} 个，无法回补 {total_uv - total_pat} 个")
    return out_path


# ══════════════════════════════════════════════════════════════════════════
# 主流程
# ══════════════════════════════════════════════════════════════════════════
def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print(f"唯品会周报 | 周期: {DATE_LABEL}")
    print(f"输出文件: {OUT_FILE}")
    print("=" * 60)

    # Step 0: 映射表已由 sync_weekly_mapping.py 同步
    code_mapping, note_mapping, _ = load_mapping()
    dmp_data = load_dmp_data()
    # 前端数据加载优先级: 显式指定文件 > JSON缓存 > API拉取
    start_str = _start_dt.strftime('%Y-%m-%d')
    end_str   = _end_dt.strftime('%Y-%m-%d')
    cache_json = OUTPUT_DIR / 'frontend_{}_{}.json'.format(
        start_str.replace('-',''), end_str.replace('-',''))

    if INPUT_FILE and __import__('pathlib').Path(INPUT_FILE).exists():
        ext = __import__('pathlib').Path(INPUT_FILE).suffix.lower()
        if ext == '.json':
            rows = load_frontend_data_from_json(INPUT_FILE)
        else:
            rows = load_frontend_data(INPUT_FILE)
    elif cache_json.exists() and not getattr(_args, 'no_fetch', False):
        # 检查缓存文件是否为空
        if cache_json.stat().st_size == 0:
            print(f'  [警告] 缓存文件为空: {cache_json}，删除后重新拉取')
            cache_json.unlink()
            print(f'  从聚光API拉取前端数据: {start_str} ~ {end_str}')
            rows = fetch_frontend_data(start_str, end_str)
        else:
            print(f'  使用JSON缓存: {cache_json}')
            rows = load_frontend_data_from_json(str(cache_json))
    else:
        print(f'  从聚光API拉取前端数据: {start_str} ~ {end_str}')
        rows = fetch_frontend_data(start_str, end_str)

    this_week_key = start_str.replace('-','') + '_' + end_str.replace('-','')
    this_dmp = dmp_data.get('weekly', {}).get(this_week_key, {})
    if not this_dmp:
        available = list(dmp_data.get('weekly', {}).keys())
        print(f'[警告] 本周 weekly[{this_week_key}] 无数据！dmp_data.json 现有keys: {available}')
        print(f'  请确认采集时间段与 --start-date {start_str} / --end-date {end_str} 完全一致')
    merge_dmp_data(rows, this_dmp, code_mapping)
    print(f"数据行数: {len(rows)}")

    # 上周对比数据
    last_start = (_start_dt - timedelta(days=7)).strftime('%Y-%m-%d')
    last_end   = (_start_dt - timedelta(days=1)).strftime('%Y-%m-%d')
    last_week_key = last_start.replace('-','') + '_' + last_end.replace('-','')
    last_dmp = dmp_data.get('weekly', {}).get(last_week_key, {})
    if not last_dmp:
        available = list(dmp_data.get('weekly', {}).keys())
        print(f'[警告] 上周 weekly[{last_week_key}] 无数据！dmp_data.json 现有keys: {available}')
        print(f'  请确认采集时间段与上周 {last_start} ~ {last_end} 完全一致')
    last_cache = OUTPUT_DIR / 'frontend_{}_{}.json'.format(last_start.replace('-',''), last_end.replace('-',''))
    print(f'  加载上周数据: {last_start} ~ {last_end}')
    if last_cache.exists() and last_cache.stat().st_size > 0:
        last_rows = load_frontend_data_from_json(str(last_cache))
    else:
        if last_cache.exists():
            print(f'  [警告] 上周缓存文件为空: {last_cache}，删除后重新拉取')
            last_cache.unlink()
        last_rows = fetch_frontend_data(last_start, last_end)
    merge_dmp_data(last_rows, last_dmp, code_mapping)
    print(f"上周数据行数: {len(last_rows)}")

    # ── 校验前置（生成 Sheet 之前）──────────────────────────────────────────
    print("\n执行数据校验...")
    val_result = run_validation(rows, note_mapping, code_mapping, this_dmp)  # Bug B fix: 传本周扁平DMP

    # ── 异常回补：UV>0 的 code 构造虚拟行，参与 Sheet1-4 聚合计算
    supplement_rows = build_supplement_rows(val_result, code_mapping, this_dmp)  # Bug B fix: 传本周扁平DMP
    if supplement_rows:
        print(f"  回补虚拟行: {len(supplement_rows)} 条")
    rows.extend(supplement_rows)  # Bug A fix: 直接扩展主数据集，Sheet1-4 和 Sheet6 统一使用

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    print("\n生成 Sheet1: 整体投放数据...")
    build_sheet1(wb, rows, last_rows)

    print("生成 Sheet2: 投放情况（按板块）...")
    build_sheet2(wb, rows, last_rows)

    print("生成 笔记投放明细...")
    build_sheet_note_detail(wb, rows)

    print("生成 Sheet3: RTA账户-测试情况...")
    build_sheet3(wb, rows, last_rows)

    print("生成 Sheet4: 客产自产-投放情况...")
    build_sheet4(wb, rows, last_rows)

    print("生成 Sheet5: 月跑量数据...")
    build_sheet5(wb, dmp_data, this_week_key, code_mapping, note_mapping, start_str, end_str)

    print("生成 Sheet6: 前端数据...")
    build_sheet6(wb, rows)

    wb.save(OUT_FILE)
    print(f"\n完成: {OUT_FILE}")

    # ── 写 validation.json ────────────────────────────────────────────────
    save_validation(val_result)

if __name__ == '__main__':
    main()
