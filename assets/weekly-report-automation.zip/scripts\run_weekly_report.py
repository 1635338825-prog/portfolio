#!/usr/bin/env python3
"""客户周报自动化主入口。"""

import argparse
from pathlib import Path

from report_builder import build_weekly_report


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs" / "weekly_report_config.json"
DEFAULT_ACCOUNTS = ROOT / "configs" / "accounts.json"


def main():
    parser = argparse.ArgumentParser(description="生成客户周报")
    parser.add_argument("--start-date", required=True, help="开始日期，格式 YYYY-MM-DD")
    parser.add_argument("--end-date", required=True, help="结束日期，格式 YYYY-MM-DD")
    parser.add_argument("--config", default=str(DEFAULT_CONFIG), help="配置文件路径")
    parser.add_argument(
        "--accounts",
        default=str(DEFAULT_ACCOUNTS),
        help="账户配置路径，默认 configs/accounts.json",
    )
    args = parser.parse_args()

    result = build_weekly_report(
        config_path=Path(args.config),
        accounts_path=Path(args.accounts),
        start_date=args.start_date,
        end_date=args.end_date,
    )

    print("周报生成完成")
    print(f"周报文件：{result['report_path']}")
    print(f"校验文件：{result['validation_path']}")
    print(f"数据行数：{result['row_count']}")
    print(f"请求账户数：{result['requested_account_count']}")
    print(f"匹配到账户数：{result['matched_account_count']}")


if __name__ == "__main__":
    main()
