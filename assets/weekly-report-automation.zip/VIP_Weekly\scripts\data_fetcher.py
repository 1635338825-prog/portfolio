"""
统一数据获取模块 - 支持所有小红书聚光广告API endpoint
"""
import requests
import time
from collections import defaultdict
from token_manager import TokenManager


# endpoint到API路径的映射
ENDPOINT_PATHS = {
    # 离线接口
    "account":     "/api/open/jg/data/report/offline/account",
    "campaign":    "/api/open/jg/data/report/offline/campaign",   # 计划级
    "unit":        "/api/open/jg/data/report/offline/unit",        # 单元级
    "note":        "/api/open/jg/data/report/offline/note",
    "creative":    "/api/open/jg/data/report/offline/creative",
    "keyword":     "/api/open/jg/data/report/offline/keyword",
    "search_word": "/api/open/jg/data/report/offline/search/word",
    # 实时接口
    "account_realtime":  "/api/open/jg/data/report/realtime/account",
    "keyword_realtime":  "/api/open/jg/data/report/realtime/keyword",
    "creative_realtime": "/api/open/jg/data/report/realtime/creativity",
}

# 支持 split_columns 的 endpoint
SPLIT_SUPPORTED = {"account", "creative", "campaign", "unit"}

# 支持 filters 的 endpoint
FILTER_SUPPORTED = {"note", "creative"}

BASE_URL = "https://adapi.xiaohongshu.com"

# 财务接口
FINANCE_PATH        = "/api/open/jg/account/order/info"
FINANCE_ACCT_TYPES  = [0, 1, 6]   # 0=现金 1=常规返货 6=赔付返货
FINANCE_OPERATE_TYPE = 3           # 消费扣款


def _parse_advertiser_id(advertiser_id):
    """将账户ID转为API所需格式：纯数字转int，否则保留字符串"""
    try:
        return int(advertiser_id)
    except (ValueError, TypeError):
        return advertiser_id


class DataFetcher:
    def __init__(self, token_manager: TokenManager):
        self.token_manager = token_manager

    # ──────────────────────────────────────────────────────────────
    # 广告数据接口
    # ──────────────────────────────────────────────────────────────
    def fetch(self, endpoint, advertiser_id, start_date, end_date,
              time_unit="DAY", split_columns=None, filters=None,
              marketing_target=None, bidding_strategy=None,
              optimize_target=None, placement=None,
              promotion_target=None, delivery_mode=None,
              build_type=None,
              sort_column=None, sort="desc",
              page_size=500, data_caliber=None,
              max_retries=2):
        """
        统一数据获取接口

        Args:
            endpoint: 接口类型
                离线: account / campaign / unit / note / creative / keyword / search_word
                实时: account_realtime / keyword_realtime / creative_realtime
            advertiser_id: 广告主ID
            start_date: 开始日期 yyyy-MM-dd
            end_date: 结束日期 yyyy-MM-dd
            time_unit: 时间粒度 DAY/HOUR/SUMMARY（离线接口）
            split_columns: 细分条件列表（account/creative/campaign/unit离线支持）
            filters: 过滤条件 FilterClause[]（仅note/creative离线支持）
            marketing_target: 营销目标过滤 integer[]
            bidding_strategy: 出价方式过滤 integer[]
            optimize_target: 推广目标过滤 integer[]
            placement: 广告类型过滤 integer[]
            promotion_target: 推广标的过滤 integer[]
            delivery_mode: 投放模式过滤 integer[]
            build_type: 投放方式过滤 integer[]（campaign/unit支持）
            sort_column: 排序字段
            sort: 排序方式 asc/desc
            page_size: 页大小（最大500）
            data_caliber: 归因时间类型 0=点击/计费时间 1=转化时间
            max_retries: 最大重试次数

        Returns:
            dict: {
                'data_list': [...],
                'aggregation_data': {...},
                'total_data': {...},
                'total_count': int
            }
            失败返回 None
        """
        path = ENDPOINT_PATHS.get(endpoint)
        if not path:
            print(f"不支持的endpoint: {endpoint}")
            return None

        url = f"{BASE_URL}{path}"
        is_realtime = endpoint.endswith("_realtime")

        # 实时账户接口不分页，单独处理
        if endpoint == "account_realtime":
            return self._fetch_realtime_account(
                url, advertiser_id, start_date, end_date,
                max_retries, need_hourly_data=(time_unit == "HOUR")
            )

        return self._fetch_with_pagination(
            url, endpoint, advertiser_id, start_date, end_date,
            time_unit, split_columns, filters,
            marketing_target, bidding_strategy, optimize_target,
            placement, promotion_target, delivery_mode,
            build_type,
            sort_column, sort, page_size, data_caliber,
            is_realtime, max_retries
        )

    # ──────────────────────────────────────────────────────────────
    # 财务流水接口
    # ──────────────────────────────────────────────────────────────
    def fetch_finance(self, advertiser_id, date_str, max_retries=2):
        """
        获取账户财务流水（消费扣款）

        Args:
            advertiser_id: 广告主ID
            date_str: 查询日期 yyyy-MM-dd
                      注意：财务次日入账，查昨天的广告消耗需传"今天"的日期
            max_retries: 最大重试次数

        Returns:
            dict: {
                '常规返货': float,
                '赔付返货': float,
                '现金': float,
                '总计': float,
                '返货消耗合计': float
            }
            失败返回空 dict {}
        """
        url = f"{BASE_URL}{FINANCE_PATH}"
        type_map = {0: '现金', 1: '常规返货', 6: '赔付返货'}

        for attempt in range(max_retries):
            try:
                token = self.token_manager.get_access_token()
                resp = requests.post(
                    url,
                    json={
                        'advertiser_id': _parse_advertiser_id(advertiser_id),
                        'start_time':    date_str,
                        'end_time':      date_str,
                        'page':          1,
                        'page_size':     50,
                        'account_types': FINANCE_ACCT_TYPES,
                    },
                    headers={'content-type': 'application/json', 'Access-Token': token},
                    timeout=15
                ).json()

                if resp.get('code') != 0:
                    print(f"  ⚠ 财务API失败 {advertiser_id}: code={resp.get('code')} {resp.get('msg','')}")
                    if self._is_token_error(resp):
                        if self._retry_token(attempt, max_retries):
                            continue
                    return {}

                summary = defaultdict(float)
                for d in resp.get('data', {}).get('account_trade_detail', []):
                    if d.get('operate_type') == FINANCE_OPERATE_TYPE:
                        atype = type_map.get(d.get('account_type'))
                        if atype:
                            summary[atype] += abs(float(str(d.get('order_amount', 0)))) / 100

                cj = summary['常规返货']
                pp = summary['赔付返货']
                cx = summary['现金']
                return {
                    '常规返货':    cj,
                    '赔付返货':    pp,
                    '现金':        cx,
                    '总计':        cj + pp + cx,
                    '返货消耗合计': cj + pp,
                }

            except Exception as e:
                if not self._handle_exception(e, attempt, max_retries):
                    return {}

        return {}

    # ──────────────────────────────────────────────────────────────
    # 内部实现
    # ──────────────────────────────────────────────────────────────
    def _fetch_realtime_account(self, url, advertiser_id,
                                start_date, end_date, max_retries,
                                need_hourly_data=False):
        """实时账户接口（不分页，返回汇总数据）"""
        for attempt in range(max_retries):
            try:
                access_token = self.token_manager.get_access_token()
                headers = {
                    "content-type": "application/json",
                    "Access-Token": access_token
                }
                payload = {
                    "advertiser_id": _parse_advertiser_id(advertiser_id),
                    "start_date": start_date,
                    "end_date": end_date
                }
                if need_hourly_data:
                    payload["need_hourly_data"] = True

                response = requests.post(url, json=payload, headers=headers, timeout=30)
                result = response.json()

                if result.get('success') and result.get('code') == 0:
                    data = result.get('data', {})
                    hourly_data = result.get('hourly_data', [])
                    if need_hourly_data and hourly_data:
                        return {
                            'data_list': hourly_data,
                            'aggregation_data': data,
                            'total_count': len(hourly_data)
                        }
                    return {
                        'data_list': [data] if data else [],
                        'aggregation_data': data,
                        'total_count': 1
                    }

                if self._is_token_error(result):
                    if self._retry_token(attempt, max_retries):
                        continue
                    return None

                pass  # silent: request failed
                return None

            except Exception as e:
                if not self._handle_exception(e, attempt, max_retries):
                    return None

        return None

    def _fetch_with_pagination(self, url, endpoint, advertiser_id,
                               start_date, end_date, time_unit,
                               split_columns, filters,
                               marketing_target, bidding_strategy,
                               optimize_target, placement,
                               promotion_target, delivery_mode,
                               build_type,
                               sort_column, sort, page_size,
                               data_caliber, is_realtime, max_retries):
        """分页获取数据"""
        all_data = []
        aggregation_data = None
        total_data = None
        page_num = 1

        while True:
            for attempt in range(max_retries):
                try:
                    access_token = self.token_manager.get_access_token()
                    headers = {
                        "content-type": "application/json",
                        "Access-Token": access_token
                    }
                    payload = {
                        "advertiser_id": _parse_advertiser_id(advertiser_id),
                        "start_date": start_date,
                        "end_date": end_date,
                        "page_num": page_num,
                        "page_size": page_size
                    }

                    # 离线接口专属参数
                    if not is_realtime:
                        if time_unit:
                            payload["time_unit"] = time_unit
                        if data_caliber is not None:
                            payload["data_caliber"] = data_caliber
                        if sort_column:
                            payload["sort_column"] = sort_column
                            payload["sort"] = sort

                        if split_columns and endpoint in SPLIT_SUPPORTED:
                            payload["split_columns"] = split_columns
                            # split 模式下过滤参数必须传（可为空数组）
                            payload.setdefault("marketing_target",  marketing_target or [])
                            payload.setdefault("bidding_strategy",  bidding_strategy or [])
                            payload.setdefault("optimize_target",   optimize_target or [])
                            payload.setdefault("placement",         placement or [])
                            payload.setdefault("promotion_target",  promotion_target or [])
                        else:
                            if marketing_target:  payload["marketing_target"]  = marketing_target
                            if bidding_strategy:  payload["bidding_strategy"]  = bidding_strategy
                            if optimize_target:   payload["optimize_target"]   = optimize_target
                            if placement:         payload["placement"]         = placement
                            if promotion_target:  payload["promotion_target"]  = promotion_target

                        # build_type：campaign/unit 支持，传了就加
                        if build_type is not None:
                            payload["build_type"] = build_type

                        if delivery_mode:
                            payload["delivery_mode"] = delivery_mode

                        if filters and endpoint in FILTER_SUPPORTED:
                            payload["filters"] = filters

                    response = requests.post(url, json=payload, headers=headers, timeout=30)
                    result = response.json()

                    if result.get('success') and result.get('code') == 0:
                        if not is_realtime:
                            resp_data   = result.get('data', {})
                            data_list   = resp_data.get('data_list', [])
                            total_count = resp_data.get('total_count', 0)

                            if page_num == 1:
                                aggregation_data = resp_data.get('aggregation_data')

                            all_data.extend(data_list)

                            if len(all_data) >= total_count or not data_list:
                                return {
                                    'data_list': all_data,
                                    'aggregation_data': aggregation_data,
                                    'total_count': total_count
                                }
                        else:
                            # 实时接口（关键词/创意）
                            data_list = (result.get('keyword_dtos') or
                                         result.get('creativity_dtos') or [])

                            if page_num == 1:
                                total_data = result.get('total_data')

                            page_info   = result.get('page', {})
                            total_count = page_info.get('total_count', 0)

                            all_data.extend(data_list)

                            if len(all_data) >= total_count or not data_list:
                                return {
                                    'data_list': all_data,
                                    'total_data': total_data,
                                    'total_count': total_count
                                }

                        page_num += 1
                        break  # 成功，进入下一页

                    if self._is_token_error(result):
                        if self._retry_token(attempt, max_retries):
                            continue
                        return None

                    pass  # silent: request failed
                    return None

                except Exception as e:
                    if not self._handle_exception(e, attempt, max_retries):
                        return None
            else:
                print("达到最大重试次数")
                return None

    def _is_token_error(self, result):
        msg  = result.get('msg', '').lower()
        code = result.get('code')
        return 'token' in msg or code in [401, 403, 50002]

    def _retry_token(self, attempt, max_retries):
        print(f"Token可能已过期，尝试刷新... (尝试 {attempt + 1}/{max_retries})")
        return self.token_manager.refresh_access_token()

    def _handle_exception(self, e, attempt, max_retries):
        print(f"请求异常: {str(e)}")
        if attempt < max_retries - 1:
            print(f"重试... (尝试 {attempt + 2}/{max_retries})")
            time.sleep(1)
            return True
        return False

