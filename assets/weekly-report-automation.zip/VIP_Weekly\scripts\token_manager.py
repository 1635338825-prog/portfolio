﻿"""Public token adapter: credentials are supplied by the user's private environment."""

import os
import time


class TokenManager:
    def __init__(self):
        self.access_token = os.getenv("PLATFORM_ACCESS_TOKEN", "")
        self.expires_at = 0

    def get_access_token(self):
        if not self.access_token:
            raise RuntimeError(
                "PLATFORM_ACCESS_TOKEN is not configured. Set it in your private environment."
            )
        return self.access_token

    def _is_expired(self):
        return bool(self.expires_at and time.time() >= self.expires_at)

    def _fetch_access_token(self):
        return self.get_access_token()

    def refresh_access_token(self):
        self.access_token = os.getenv("PLATFORM_ACCESS_TOKEN", "")
        return self.get_access_token()
