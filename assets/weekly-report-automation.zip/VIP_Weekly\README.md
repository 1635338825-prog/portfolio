﻿# 唯品会小红书聚光广告周报自动生成工具

自动化生成唯品会小红书聚光广告投放周报，包含数据分析、Excel 报表生成和飞书群自动推送。

## 功能特性

- 📊 **自动化数据采集**：从聚光 API 和 DMP 系统自动获取投放数据
- 📈 **智能数据分析**：自动生成 6 个维度的分析报表
- 📁 **Excel 报表生成**：输出格式化的多 Sheet Excel 文件
- 🤖 **飞书自动推送**：自动发送周报到指定飞书群
- ⚠️ **数据校验告警**：自动检测数据异常并发送告警
- 🔄 **完整重试机制**：所有 API 调用失败自动重试 3 次

## 系统要求

- Python 3.9+
- Windows 系统（PowerShell 支持）
- 飞书企业应用权限
- DMP 系统访问权限

## 快速开始

### 1. 安装依赖

```bash
pip install requests ddddocr openpyxl Pillow
```

### 2. 配置账户信息

编辑 `configs/vip_weekly_config.json`，按以下说明填写你的配置。

#### 2.1 飞书应用配置（⚠️ 必须填写）

你需要创建两个飞书企业应用：一个用于读取数据，一个用于发送消息。

打开 `configs/vip_weekly_config.json`，找到 `feishu` 和 `feishu_send` 部分，填写以下字段：

```json
{
  "feishu": {
    "app_id": "<填写你的飞书应用 App ID>",
    "app_secret": "<填写你的飞…ret>",
    "sheet_id": "<填写映射表所在的飞书表格 Sheet ID>",
    "target_group": "<填写接收周报的飞书群 Chat ID>"
  },
  "feishu_send": {
    "app_id": "<填写发送消息用的飞书应用 App ID>",
    "app_secret": "<填写发送消…ret>",
    "target_group": "<填写接收周报的飞书群 Chat ID>"
  }
}
```

**各字段说明：**

| 字段 | 说明 | 如何获取 |
|------|------|---------|
| `feishu.app_id` | 读取数据用的飞书应用 ID | [飞书开放平台](https://open.feishu.cn/) → 应用管理 → 凭证与基础信息 |
| `feishu.app_secret` | 读取数据用的飞书应用密钥 | 同上 |
| `feishu.sheet_id` | 映射表所在的飞书多维表格 Sheet ID | 打开飞书多维表格 → URL 中的 `?table=` 后面的值 |
| `feishu.target_group` | 接收周报的飞书群 Chat ID | 将飞书应用添加到目标群后，通过飞书 API 获取 |
| `feishu_send.app_id` | 发送消息用的飞书应用 ID | 同上，建议使用独立应用 |
| `feishu_send.app_secret` | 发送消息用的飞书应用密钥 | 同上 |
| `feishu_send.target_group` | 接收周报的飞书群 Chat ID | 同上 |

**飞书应用权限配置：**

- `feishu` 应用需要：读取多维表格权限（`bitable:app:readonly`）
- `feishu_send` 应用需要：发送消息（`im:message:send_as_bot`）+ 上传文件（`im:file`）权限

**如何获取群 Chat ID：**

1. 将飞书应用添加到目标群
2. 通过飞书开放平台 API 调试台调用「获取群列表」接口
3. 在返回结果中找到目标群的 `chat_id`

#### 2.2 DMP 系统配置（已预设）

DMP 系统账号信息**已随 Skill 预配置好**，无需修改。

如需更换 DMP 账号，可编辑 `configs/vip_weekly_config.json` 中的 `dmp` 字段。

#### 2.3 映射表配置（已预设）

映射表用于关联笔记 ID、监测点位码和计划 ID，**已随 Skill 预配置好**，无需修改。

如需更换映射表来源，可编辑 `configs/vip_weekly_config.json` 中的 `mapping_table` 字段。

#### 2.4 广告账户配置（已预设）

广告账户列表、价格带分类、RTA 策略等信息**已随 Skill 预配置好**，无需修改。

如需增减账户，可编辑 `configs/vip_weekly_config.json` 中的 `accounts`、`category_order`、`account_price` 等字段。

### 3. 运行周报生成

```bash
cd scripts

# 默认生成上周周报（上周四到本周三）
python run_weekly_report.py

# 指定日期范围
python run_weekly_report.py --start-date 2026-06-09 --end-date 2026-06-15

# 跨月时跳过月度数据采集
python run_weekly_report.py --start-date 2026-04-27 --end-date 2026-05-03 --skip-monthly
```

## 工作流程

```
Step 0: 同步映射表
  ↓
Step 1: 采集 DMP 数据（本周/上周/本月）
  ↓
Step 2: 拉取聚光 API 数据 + 生成分析报告
  ↓
Step 3: 发送周报到飞书群 + 校验告警
```

## 输出说明

### Excel 报表结构

| Sheet | 内容 | 说明 |
|-------|------|------|
| 1 | 整体投放数据 | 按价格带和投放版位汇总，含上周对比 |
| 2 | 投放情况（按板块） | 搜索/信息流/全站整体数据 |
| 3 | RTA 账户测试情况 | 已安装未购账户的测试数据 |
| 4 | 客产自产-投放情况 | 客产和自产数据对比 |
| 5 | N月跑量数据 | DMP 驱动的价格带分组分析 |
| 6 | 前端数据 | 原始数据明细，方便复查 |

### 输出文件

- `output/唯品会周报-M.DD-M.DD.xlsx` - 周报 Excel 文件
- `output/frontend_YYYYMMDD_YYYYMMDD.json` - 前端数据缓存
- `output/validation_xxx_xxx.json` - 数据校验结果

## 数据校验告警

系统会自动检测以下异常：

1. **映射表配置缺失**：监测点位码在映射表中有配置，但未在聚光数据中找到
2. **DMP 数据缺失**：DMP 有 UV 数据，但点位码不在映射表中

告警消息示例：

```
📋 周报校验告警 · 6月15日 - 6月21日

⚠️ 共 3 个监测点位码（UV 合计 15）未能纳入周报

① 映射表中有配置，但最终未分配到聚光行（共 2 条）
• code_001｜笔记 abc123｜DMP UV：10｜✅ 已回补

② DMP 有 UV，但点位码不在映射表中（共 1 条）
• code_002｜DMP UV：5｜❌ 无法回补
```

## 定时任务配置

可以使用 Windows 任务计划程序或 OpenClaw cron 配置定时执行：

### OpenClaw Cron 示例

```json
{
  "name": "唯品会周报",
  "schedule": {
    "kind": "cron",
    "expr": "0 11 * * 4",
    "tz": "Asia/Shanghai"
  },
  "payload": {
    "kind": "agentTurn",
    "message": "运行唯品会周报生成任务"
  }
}
```

## 故障排查

### 1. 映射表同步失败

**原因**：飞书 API 权限不足或网络问题

**解决**：
- 检查飞书应用权限配置
- 确认 `wiki_node_token` 和 `spreadsheet_token` 正确
- 查看 `configs/mapping.json` 是否有缓存数据（但建议不使用缓存）

### 2. DMP 登录失败

**原因**：验证码识别错误或账号密码错误

**解决**：
- 确认 DMP 账号密码正确
- 系统使用 ddddocr 自动识别验证码，失败会自动重试 3 次
- 如持续失败，检查 DMP 系统是否可访问

### 3. 飞书消息发送失败

**原因**：应用权限不足或群 Chat ID 错误

**解决**：
- 确认 `feishu_send` 应用已添加到目标群
- 检查 `target_group` Chat ID 是否正确
- 确认应用有发送消息和上传文件权限

### 4. 数据校验告警

**原因**：映射表配置不完整或数据源不一致

**解决**：
- 检查映射表是否包含所有监测点位码
- 确认 DMP 数据和聚光数据的时间范围一致
- 查看 `output/validation_xxx_xxx.json` 获取详细告警信息

## 目录结构

```
VIP_Weekly/
├── README.md                          # 本文件
├── SKILL.md                           # OpenClaw Skill 定义
├── configs/
│   ├── vip_weekly_config.json         # 账户和飞书配置（⚠️ 需要填写飞书应用配置）
│   ├── mapping.json                   # 映射表缓存（自动生成）
│   └── dmp_data.json                  # DMP 数据缓存（自动生成）
├── scripts/
│   ├── run_weekly_report.py           # 主入口脚本
│   ├── sync_weekly_mapping.py         # Step 0: 同步映射表
│   ├── dmp_collector_weekly.py        # Step 1: 采集 DMP 数据
│   ├── vip_weekly_analysis.py         # Step 2: 生成分析报告
│   ├── send_weekly_message.py         # Step 3: 发送飞书消息
│   ├── data_fetcher.py                # 聚光 API 工具层
│   └── token_manager.py               # Token 管理
└── output/                            # 运行时产出（自动生成）
    ├── 唯品会周报-x.xx-x.xx.xlsx
    ├── frontend_YYYYMMDD_YYYYMMDD.json
    └── validation_xxx_xxx.json
```

## 技术细节

### 数值精度规则

- **原始数据**（消费、展现、点击、UV）：取整
- **计算字段**（新客成本、CPC 等）：保留 1 位小数
- **占比/比率**：保留 1 位小数 + %

### 重试机制

所有 API 调用失败会自动重试 3 次：
- 飞书 API：token 获取、表格读取、消息发送
- DMP API：登录、数据导出
- 主脚本：子脚本失败重试 2 次

### 跨月处理

- **不跨月**（如 6.9-6.15）：采集本周 + 上周 + 本月数据
- **跨月**（如 4.27-5.3）：使用 `--skip-monthly` 参数，仅采集本周 + 上周数据

## 常见问题

**Q: 如何修改周报的日期范围？**  
A: 使用 `--start-date` 和 `--end-date` 参数指定，格式为 YYYY-MM-DD。

**Q: 映射表同步失败可以使用缓存吗？**  
A: 不建议。缓存可能导致数据不一致，建议排查问题后重新同步。

**Q: 如何查看详细的校验告警？**  
A: 查看 `output/validation_xxx_xxx.json` 文件，包含所有未纳入周报的监测点位码详情。

**Q: 可以同时生成多个账户的周报吗？**  
A: 可以。在 `vip_weekly_config.json` 的 `accounts` 数组中配置所有账户即可。

**Q: 飞书消息发送失败怎么办？**  
A: 检查 `feishu_send` 应用的权限配置，确认已添加到目标群，并查看日志排查具体错误。

## 许可证

本工具仅供内部使用。

---

*最后更新：2026-06-25*
