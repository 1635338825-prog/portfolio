#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
唯品会周报 - DMP 数据采集（纯 API 方式）
参考日报 dmp_daily_fetcher.py，支持多节点采集（本周/上周/本月）

用法:
  python dmp_collector_weekly.py --start-date 2026-06-09 --end-date 2026-06-15
  python dmp_collector_weekly.py --start-date 2026-04-27 --end-date 2026-05-03 --skip-monthly
"""

import sys
import json
import hashlib
import re
import io
from datetime import datetime, timezone, timedelta
from pathlib import Path

import requests
from openpyxl import load_workbook
import ddddocr

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.stderr.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = Path(__file__).parent
CONFIG_DIR = SCRIPT_DIR.parent / 'configs'
OUTPUT_DIR = SCRIPT_DIR.parent / 'output'

CST = timezone(timedelta(hours=8))


def get_config():
    config_path = CONFIG_DIR / 'vip_weekly_config.json'
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_dmp_data():
    """读取现有 dmp_data.json"""
    path = CONFIG_DIR / 'dmp_data.json'
    if path.exists():
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    return {'weekly': {}, 'monthly': {}}


def save_dmp_data(data):
    """写入 dmp_data.json"""
    path = CONFIG_DIR / 'dmp_data.json'
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f'    [SAVE] dmp_data.json 已更新')


def calc_timestamps(start_date_str, end_date_str):
    """
    计算所有采集节点的时间戳
    返回: {
        'nodes': [...],
        'cross_month': bool
    }
    """
    start_dt = datetime.strptime(start_date_str, '%Y-%m-%d')
    end_dt = datetime.strptime(end_date_str, '%Y-%m-%d')

    # 本周时间戳
    this_start = datetime(start_dt.year, start_dt.month, start_dt.day, 0, 0, 0, tzinfo=CST)
    this_end = datetime(end_dt.year, end_dt.month, end_dt.day, 23, 59, 59, tzinfo=CST)
    this_start_ms = int(this_start.timestamp() * 1000)
    this_end_ms = int(this_end.timestamp() * 1000)

    # 上周时间戳
    last_start = this_start - timedelta(days=7)
    last_end = this_end - timedelta(days=7)
    last_start_ms = int(last_start.timestamp() * 1000)
    last_end_ms = int(last_end.timestamp() * 1000)

    # 判断是否跨月
    cross_month = (start_dt.month != end_dt.month)

    nodes = [
        {
            'label': '本周',
            'key': f"{start_dt.strftime('%Y%m%d')}_{end_dt.strftime('%Y%m%d')}",
            'key_type': 'weekly',
            'start_ms': this_start_ms,
            'end_ms': this_end_ms,
        },
        {
            'label': '上周',
            'key': f"{last_start.strftime('%Y%m%d')}_{last_end.strftime('%Y%m%d')}",
            'key_type': 'weekly',
            'start_ms': last_start_ms,
            'end_ms': last_end_ms,
        },
    ]

    if not cross_month:
        # 本月：月初 ~ 本周日
        month_start = datetime(start_dt.year, start_dt.month, 1, 0, 0, 0, tzinfo=CST)
        month_start_ms = int(month_start.timestamp() * 1000)
        nodes.append({
            'label': '本月',
            'key': start_dt.strftime('%Y-%m'),
            'key_type': 'monthly',
            'start_ms': month_start_ms,
            'end_ms': this_end_ms,
        })

    return {'nodes': nodes, 'cross_month': cross_month}


def login(session, username, password, max_retries=3):
    """登录 DMP 系统"""
    ocr = ddddocr.DdddOcr(show_ad=False)
    login_url = 'https://dmp-media.vip.com/user/login'
    password_sha256 = hashlib.sha256(password.encode()).hexdigest()

    for attempt in range(max_retries):
        try:
            # 获取验证码
            captcha_url = 'https://dmp-media.vip.com/user/validateimg'
            captcha_resp = session.get(captcha_url, timeout=10)
            captcha_resp.raise_for_status()

            # 识别验证码
            captcha_code = ocr.classification(captcha_resp.content)
            print(f'[登录] 验证码识别: {captcha_code}')

            # 登录
            login_data = {
                'username': username,
                'password': password_sha256,
                'authCode': captcha_code
            }
            resp = session.post(login_url, data=login_data, timeout=10)
            resp.raise_for_status()
            result = resp.json()

            if result.get('code') == 0:
                print(f'[OK] DMP 登录成功')
                return True
            else:
                print(f'[重试] 登录失败: {result.get("msg")} (尝试 {attempt+1}/{max_retries})')
        except Exception as e:
            print(f'[重试] 登录异常: {e} (尝试 {attempt+1}/{max_retries})')

    raise Exception(f'DMP 登录失败（重试{max_retries}次）')


def fetch_export_data(session, base_url, start_ms, end_ms, max_retries=3):
    """获取 DMP 导出数据"""
    export_url = f'{base_url}/data/report/detail/export'
    params = {
        'channelId': 252,  # 小红书
        'startDate': start_ms,
        'endDate': end_ms
    }

    for attempt in range(max_retries):
        try:
            print(f'[获取] 调用 export API...')
            resp = session.get(export_url, params=params, timeout=60)

            if resp.url and 'login' in resp.url:
                print(f'[警告] Cookie 可能已过期')
                raise Exception('Cookie 过期')

            resp.raise_for_status()
            print(f'[OK] 获取到 {len(resp.content)} 字节数据')

            # 解析 Excel
            print(f'[解析] 使用 openpyxl 解析 Excel...')
            wb = load_workbook(io.BytesIO(resp.content))
            ws = wb.active

            # 提取数据
            result = {}
            for row in ws.iter_rows(min_row=2, values_only=True):
                if len(row) < 35:
                    continue
                code = str(row[5] or '').strip()
                if not code or len(code) != 8:
                    continue
                if not re.match(r'^[a-z0-9]{8}$', code):
                    continue

                def sf(v):
                    try:
                        return float(str(v).replace(',', ''))
                    except:
                        return 0.0

                result.setdefault(code, {
                    'UV': 0, '未购买UV': 0, '可运营UV': 0,
                    '客户数': 0, '新客数': 0, '实收金额': 0, '新客实收': 0
                })
                result[code]['UV'] += sf(row[13])
                result[code]['未购买UV'] += sf(row[15])
                result[code]['可运营UV'] += sf(row[19])
                result[code]['客户数'] += sf(row[30])
                result[code]['新客数'] += sf(row[31])
                result[code]['实收金额'] += sf(row[33])
                result[code]['新客实收'] += sf(row[34])

            wb.close()
            print(f'[OK] 解析完成，共 {len(result)} 个监测点位码')
            return result

        except Exception as e:
            print(f'[重试] 获取数据异常: {e} (尝试 {attempt+1}/{max_retries})')
            if 'Cookie' in str(e) or 'login' in str(e).lower():
                raise

    raise Exception(f'获取 DMP 数据失败（重试{max_retries}次）')


def main():
    import argparse
    parser = argparse.ArgumentParser(description='DMP 周报采集器')
    parser.add_argument('--start-date', required=True, help='周期开始 YYYY-MM-DD')
    parser.add_argument('--end-date', required=True, help='周期结束 YYYY-MM-DD')
    parser.add_argument('--skip-monthly', action='store_true', help='跨月时跳过 monthly 采集')
    args = parser.parse_args()

    # 计算采集节点
    ts_info = calc_timestamps(args.start_date, args.end_date)
    nodes = ts_info['nodes']

    if args.skip_monthly:
        nodes = [n for n in nodes if n['key_type'] != 'monthly']

    print(f'═══ DMP 周报采集 ═══')
    print(f'周期: {args.start_date} ~ {args.end_date}')
    print(f'跨月: {"是" if ts_info["cross_month"] else "否"}')
    print(f'采集节点: {len(nodes)} 个')
    for n in nodes:
        print(f'  - {n["label"]} => {n["key_type"]}[{n["key"]}]')
    print()

    # 读取配置
    config = get_config()
    dmp_config = config.get('dmp', {})
    username = dmp_config.get('username')
    password = dmp_config.get('password')
    base_url = dmp_config.get('base_url', 'https://dmp-media.vip.com')

    if not username or not password:
        raise Exception('配置文件中缺少 dmp.username 或 dmp.password')

    # 加载现有 dmp_data.json
    dmp_all = load_dmp_data()

    # 创建 session
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    })

    # 登录
    print('[登录] 连接 DMP 系统...')
    login(session, username, password)

    # 多节点采集循环
    success_count = 0
    for idx, node in enumerate(nodes):
        label = node['label']
        key = node['key']
        key_type = node['key_type']
        start_ms = node['start_ms']
        end_ms = node['end_ms']

        print(f'\n{"-"*50}')
        print(f'[节点 {idx+1}/{len(nodes)}] {label} | {key_type}[{key}]')
        print(f'  时间戳: {start_ms} ~ {end_ms}')

        try:
            # 获取数据
            export_data = fetch_export_data(session, base_url, start_ms, end_ms)

            if not export_data:
                print(f'  [WARN] {label}: 解析结果为空')
                continue

            # 合并写入 dmp_data.json
            if key_type not in dmp_all:
                dmp_all[key_type] = {}
            dmp_all[key_type][key] = export_data
            save_dmp_data(dmp_all)

            success_count += 1
            print(f'  [OK] {label} => {key_type}[{key}]: {len(export_data)} codes')

        except Exception as e:
            print(f'  [FAIL] {label}: {e}')
            # Cookie 过期时重新登录
            if 'Cookie' in str(e) or 'login' in str(e).lower():
                print('  尝试重新登录...')
                try:
                    login(session, username, password)
                except:
                    pass

    # 完成
    print(f'\n{"="*50}')
    print(f'采集完成: {success_count}/{len(nodes)} 个节点成功')

    if success_count == 0:
        print('[FAIL] 所有节点均采集失败')
        sys.exit(1)
    else:
        print(f'[DONE] dmp_data.json 已更新')


if __name__ == '__main__':
    main()
