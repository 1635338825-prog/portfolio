﻿---
name: vip-weekly-report
description: 唯品会小红书聚光广告周报生成（v3.0 纯脚本版）。当用户提到"唯品会周报"、"跑周报"、"生成周报"时，运行主入口脚本即可自动完成全流程。
---

# 唯品会周报 Skill

## 版本
**v3.0 — 纯脚本版（2026-06-17 重构）**

### 重构内容
- Step 0 映射表同步：agent PowerShell → Python requests（`sync_weekly_mapping.py`）
- Step 1 DMP 数据获取：Playwright + pytesseract → requests + ddddocr（`dmp_collector_weekly.py`）
- Step 3 消息发送：agent message 工具 → Python requests 飞书 API（`send_weekly_message.py`）
- 新增主入口脚本（`run_weekly_report.py`），一条命令跑完全流程
- `vip_weekly_analysis.py` 去掉内置的 `sync_mapping()` 调用，映射表同步由独立脚本负责
- **不需要 agent 介入**，cron 直接调脚本即可

---

## 快速启动（一条命令）

```bash
cd C:\Users\Administrator\.openclaw\workspace\skills\VIP_Weekly\scripts

# 默认用上周日期（周一~周日）
python run_weekly_report.py

# 手动指定日期
python run_weekly_report.py --start-date 2026-06-09 --end-date 2026-06-15

# 跨月时跳过 monthly 采集
python run_weekly_report.py --start-date 2026-04-27 --end-date 2026-05-03 --skip-monthly
```

---

## 目录结构

```
VIP_Weekly/
├── SKILL.md                         # 本文件
├── configs/
│   ├── vip_weekly_config.json       # 账户配置、飞书配置、DMP 凭据
│   ├── mapping.json                 # 笔记映射（sync_weekly_mapping.py 自动同步）
│   └── dmp_data.json                # DMP 数据（dmp_collector_weekly.py 生成）
├── scripts/
│   ├── run_weekly_report.py         # 【主入口】串联所有步骤
│   ├── sync_weekly_mapping.py       # Step 0: 飞书 API 同步映射表
│   ├── dmp_collector_weekly.py      # Step 1: DMP export API 获取数据
│   ├── vip_weekly_analysis.py       # Step 2: 主报告脚本（生成 6 个 Sheet）
│   ├── send_weekly_message.py       # Step 3: 飞书 API 发送消息
│   ├── data_fetcher.py              # 聚光 API 工具层
│   └── token_manager.py             # Token 管理（多账户支持）
└── output/                          # 运行时产出
    ├── 唯品会周报-x.xx-x.xx.xlsx    # 周报 Excel
    ├── frontend_YYYYMMDD_YYYYMMDD.json  # 前端数据缓存
    └── validation_xxx_xxx.json      # 校验结果
```

---

## 完整流程

```
Step 0:   sync_weekly_mapping.py     → 飞书 API 同步映射表
Step 1:   dmp_collector_weekly.py    → DMP export API 获取数据（多节点：本周/上周/本月）
Step 2:   vip_weekly_analysis.py     → 主报告脚本（生成 6 个 Sheet 的 Excel）
Step 3:   send_weekly_message.py     → 飞书 API 发送周报 + 校验告警
```

---

## 配置文件

### vip_weekly_config.json

```json
{
  "accounts": [
    {"id": <ACCOUNT_ID>,  "name": "唯品会-破圈-低",   "category": "穿戴", "rta": "唯品会排已购-1（A人群）"},
    {"id": <ACCOUNT_ID>, "name": "唯品会-破圈-中",   "category": "穿戴", "rta": "唯品会排已购-1（A人群）"},
    {"id": <ACCOUNT_ID>,  "name": "唯品会-破圈-高",   "category": "穿戴", "rta": "唯品会排已购-1（A人群）"},
    {"id": <ACCOUNT_ID>, "name": "唯品会-破圈-美妆", "category": "美妆", "rta": "唯品会排已购-1（A人群）"},
    {"id": <ACCOUNT_ID>, "name": "唯品会-破圈-中-1", "category": "穿戴", "rta": "唯品会排已购-1（A人群）"},
    {"id": <ACCOUNT_ID>, "name": "唯品会-破圈-低-1", "category": "穿戴", "rta": "唯品会已安装（B人群）"},
    {"id": <ACCOUNT_ID>, "name": "唯品会-破圈-中-2", "category": "穿戴", "rta": "唯品会排已购-1（A人群）"}
  ],
  "category_order": ["穿戴", "美妆"],
  "account_price": {
    "唯品会-破圈-低": "低客单",
    "唯品会-破圈-中": "中客单",
    "唯品会-破圈-中-1": "中客单",
    "唯品会-破圈-低-1": "低客单",
    "唯品会-破圈-中-2": "中客单",
    "唯品会-破圈-高": "高客单",
    "唯品会-破圈-美妆": "美妆"
  },
  "rta_account": "唯品会-破圈-美妆",
  "mapping_table": {
    "wiki_node_token": "<WIKI_NODE_TOKEN>",
    "sheet_account": "AuEYcm",
    "sheet_note": "a947b3",
    "spreadsheet_token": "<SPREADSHEET_TOKEN>"
  },
  "feishu": {
    "app_id": "cli_a95deb74e7789cd1",
    "app_secret": "***",
    "sheet_id": "ewETi0",
    "target_group": "oc_2d12c1a7f22101ed81b0f0cae377cc1f"
  },
  "dmp": {
    "login_url": "https://dmp-media.vip.com/index.html#/report-detail",
    "username": "小红书追投-破圈",
    "password": "***"
  }
}
```

---

## 各步骤详细说明

### Step 0: 同步映射表（sync_weekly_mapping.py）

从飞书表格同步笔记映射关系，生成 3 个索引：
- `code_mapping`: 监测点位码 → 笔记信息
- `note_mapping`: 笔记 ID → 监测点位码列表
- `campaign_mapping`: 计划 ID → 监测点位码

**重试机制：** 每个飞书 API 调用失败重试 3 次

**失败处理：** ⚠️ **同步失败必须中止任务**，不使用缓存（避免数据错误）

### Step 1: 获取 DMP 数据（dmp_collector_weekly.py）

**API 接口：**
```
GET https://dmp-media.vip.com/data/report/detail/export
参数: channelId=252, startDate=报告日00:00时间戳, endDate=报告日23:59时间戳
```

**采集节点规则：**

| 情况 | 采集节点 | 说明 |
|------|---------|------|
| 不跨月（如 6.9-6.15） | weekly[本周] + weekly[上周] + monthly[本月] | Sheet5 用月初~周末数据 |
| 跨月（如 4.27-5.3） | weekly[本周] + weekly[上周] | 加 `--skip-monthly`，Sheet5 用本周数据 |

**处理流程：**
1. 登录 DMP（验证码 + SHA256 加密密码，重试 3 次）
2. 循环采集各节点（本周/上周/本月）
3. 调用 export API 获取 Excel 文件（重试 3 次）
4. 用 openpyxl 在内存中解析 Excel
5. 按监测点位码聚合 7 个字段
6. 写入 configs/dmp_data.json

**输出格式：**
```json
{
  "weekly": {
    "20260609_20260615": {"<code>": {"UV": 38, "新客数": 3, ...}},
    "20260602_20260608": {"<code>": {"UV": 22, ...}}
  },
  "monthly": {
    "2026-06": {"<code>": {"UV": 107, ...}}
  }
}
```

### Step 2: 生成周报（vip_weekly_analysis.py）

主报告脚本：
- 拉取聚光创意数据（本周 + 上周）
- 关联监测点位码（cursor 机制）
- 注入 DMP 数据
- 生成 6 个 Sheet 的 Excel
- 输出校验结果

**注意：** 映射表同步已由 `sync_weekly_mapping.py` 完成，本脚本不再调用 `sync_mapping()`

### Step 3: 发送消息（send_weekly_message.py）

1. 获取 tenant_access_token（重试 3 次）
2. 上传周报 Excel 到飞书（重试 3 次）
3. 构造文字摘要（总消费、新客数、新客成本）
4. 构造校验告警（如有 UV>0 的缺失）
5. 发送文件消息 + 文本消息到飞书群（重试 3 次）

---

## 重试机制汇总

| 脚本 | 重试内容 | 次数 |
|------|---------|------|
| sync_weekly_mapping.py | 飞书 API（token / spreadsheet / 读取） | 各 3 次 |
| dmp_collector_weekly.py | DMP 登录（验证码） | 3 次 |
| dmp_collector_weekly.py | DMP export API（含 Cookie 过期重登录） | 3 次 |
| send_weekly_message.py | 飞书 API（token / 上传 / 发送） | 各 3 次 |
| run_weekly_report.py | 子脚本失败重试 | 2 次 |

---

## 报告说明

### Sheet 结构

| Sheet | 名称 | 说明 |
|-------|------|------|
| 1 | 整体投放数据 | 价格带 + 投放版位，含上周对比 |
| 2 | 投放情况（按板块） | 搜索/信息流/全站整体，含上周对比 |
| 3 | 已安装未购RTA账户-测试情况 | 账户测试情况，含上周对比 |
| 4 | 客产自产-投放情况 | 客产含上周对比，自产=全量 |
| 5 | N月跑量数据 | DMP 驱动，价格带分组，新客数 Top10 |
| 6 | 前端数据 | 原始数据+补丁行，方便复查 |

### 账户配置

| 账户ID | 名称 | 价格带 | 人群 |
|--------|------|--------|------|
| <ACCOUNT_ID> | 唯品会-破圈-低 | 低客单 | A人群（已购）|
| <ACCOUNT_ID> | 唯品会-破圈-中 | 中客单 | A人群（已购）|
| <ACCOUNT_ID> | 唯品会-破圈-高 | 高客单 | A人群（已购）|
| <ACCOUNT_ID> | 唯品会-破圈-美妆 | 美妆 | A人群（已购）|
| <ACCOUNT_ID> | 唯品会-破圈-中-1 | 中客单 | A人群（已购）|
| <ACCOUNT_ID> | 唯品会-破圈-低-1 | 低客单 | B人群（已安装未购）|
| <ACCOUNT_ID> | 唯品会-破圈-中-2 | 中客单 | A人群（已购）|

---

## 校验告警

主脚本运行后读取 `output/validation_xxx_xxx.json`，按格式发送告警：

```
📋 周报校验告警 · M月DD日 - M月DD日

⚠️ 共 X 个监测点位码（UV 合计 N）未能纳入周报，已回补 Y 个，无法回补 Z 个

① 映射表中有配置，但最终未分配到聚光行（共 A 条）
• {code}｜笔记 {note_id}...｜DMP UV：{n}｜✅ 已回补

② DMP 有 UV，但点位码不在映射表中（无法回补）（共 B 条）
• {code}｜DMP UV：{n}｜❌ 无法回补
```

---

## 数值精度

| 字段类型 | 规则 | 示例 |
|---------|------|------|
| 原始数据（消费、展现、点击、UV） | 取整 | 4712 |
| 计算字段（新客成本、CPC 等） | 保留 1 位小数 | 23.5 |
| 占比/比率 | 保留 1 位小数 + % | 12.3% |

---

## 依赖

- Python 3.9+：`requests`、`ddddocr`、`openpyxl`、`Pillow`
- Tesseract OCR（已弃用，改用 ddddocr）

---

*最后更新：2026-06-17 v3.0 纯脚本版重构*
