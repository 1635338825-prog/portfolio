#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
唯品会周报 - 飞书消息发送
发送周报 Excel + 校验告警到飞书群

用法:
  python send_weekly_message.py --date "6.9-6.15"
"""

import sys
import json
from pathlib import Path
from datetime import datetime

import requests
from openpyxl import load_workbook

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.stderr.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = Path(__file__).parent
CONFIG_DIR = SCRIPT_DIR.parent / 'configs'
OUTPUT_DIR = SCRIPT_DIR.parent / 'output'

FEISHU_API_BASE = 'https://open.feishu.cn/open-apis'


def get_config():
    """读取配置"""
    config_path = CONFIG_DIR / 'vip_weekly_config.json'
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def get_tenant_token(app_id, app_secret, max_retries=3):
    """获取 tenant_access_token"""
    url = f'{FEISHU_API_BASE}/auth/v3/tenant_access_token/internal'
    data = {'app_id': app_id, 'app_secret': app_secret}

    for attempt in range(max_retries):
        try:
            resp = requests.post(url, json=data, timeout=10)
            resp.raise_for_status()
            result = resp.json()
            if result.get('code') == 0:
                print(f'[OK] tenant token获取成功')
                return result['tenant_access_token']
            print(f'[重试] 获取token失败: {result.get("msg")} ({attempt+1}/{max_retries})')
        except Exception as e:
            print(f'[重试] 获取token异常: {e} ({attempt+1}/{max_retries})')

    raise Exception(f'tenant token获取失败（重试{max_retries}次）')


def upload_file(tenant_token, file_path, max_retries=3):
    """上传文件到飞书"""
    url = f'{FEISHU_API_BASE}/im/v1/files'
    headers = {'Authorization': f'Bearer {tenant_token}'}

    for attempt in range(max_retries):
        try:
            with open(file_path, 'rb') as f:
                files = {'file': (file_path.name, f)}
                data = {
                    'file_type': 'stream',
                    'file_name': file_path.name
                }
                resp = requests.post(url, headers=headers, data=data, files=files, timeout=30)
                resp.raise_for_status()
                result = resp.json()
                if result.get('code') == 0:
                    file_key = result['data']['file_key']
                    print(f'[OK] 文件上传成功: {file_path.name} -> {file_key}')
                    return file_key
                print(f'[重试] 上传失败: {result.get("msg")} ({attempt+1}/{max_retries})')
        except Exception as e:
            print(f'[重试] 上传异常: {e} ({attempt+1}/{max_retries})')

    raise Exception(f'文件上传失败（重试{max_retries}次）')


def send_message(tenant_token, chat_id, msg_type, content, max_retries=3):
    """发送消息到飞书群"""
    url = f'{FEISHU_API_BASE}/im/v1/messages'
    headers = {'Authorization': f'Bearer {tenant_token}'}
    params = {'receive_id_type': 'chat_id'}
    data = {
        'receive_id': chat_id,
        'msg_type': msg_type,
        'content': json.dumps(content)
    }

    for attempt in range(max_retries):
        try:
            resp = requests.post(url, headers=headers, params=params, json=data, timeout=10)
            resp.raise_for_status()
            result = resp.json()
            if result.get('code') == 0:
                msg_id = result['data']['message_id']
                print(f'[OK] 消息发送成功: {msg_id}')
                return msg_id
            print(f'[重试] 发送失败: {result.get("msg")} ({attempt+1}/{max_retries})')
        except Exception as e:
            print(f'[重试] 发送异常: {e} ({attempt+1}/{max_retries})')

    raise Exception(f'消息发送失败（重试{max_retries}次）')


def build_validation_alert(validation_data, date_label):
    """构造校验告警文字"""
    if not validation_data:
        return None

    # 统计
    item_count = 0
    total_uv = 0
    patched_count = 0
    unpatched_count = 0

    check2_items = []
    check6_items = []

    # 处理 check2
    for item in validation_data.get('check2', []):
        uv = item.get('dmp_uv', 0)
        if uv > 0:
            item_count += 1
            total_uv += uv
            patched = item.get('patched', False)
            if patched:
                patched_count += 1
            else:
                unpatched_count += 1
            check2_items.append(item)

    # 处理 check6
    for item in validation_data.get('check6', []):
        uv = item.get('dmp_uv', 0)
        if uv > 0:
            item_count += 1
            total_uv += uv
            unpatched_count += 1
        check6_items.append(item)

    if item_count == 0:
        return None

    # 构造告警文字
    lines = [
        f'📋 周报校验告警 · {date_label}',
        '',
        f'⚠️ 共 {item_count} 个监测点位码（UV 合计 {total_uv}）未能纳入周报，已回补 {patched_count} 个，无法回补 {unpatched_count} 个',
        ''
    ]

    if check2_items:
        lines.append(f'**① 映射表中有配置，但最终未分配到聚光行**（共 {len(check2_items)} 条）')
        for item in check2_items[:10]:
            code = item.get('code', '')
            note_id = item.get('note_id', '')[:8]
            uv = item.get('dmp_uv', 0)
            patched = item.get('patched', False)
            status = '✅ 已回补' if patched else '❌ 无法回补'
            lines.append(f'• {code}｜笔记 {note_id}...｜DMP UV：{uv}｜{status}')
        lines.append('')

    if check6_items:
        lines.append(f'**② DMP 有 UV，但点位码不在映射表中（无法回补）**（共 {len(check6_items)} 条）')
        for item in check6_items[:10]:
            code = item.get('code', '')
            uv = item.get('dmp_uv', 0)
            lines.append(f'• {code}｜DMP UV：{uv}｜❌ 无法回补')

    return '\n'.join(lines)


def build_summary(xlsx_path, date_label):
    """从 Excel 读取摘要数据"""
    wb = load_workbook(xlsx_path)

    # Sheet1: 整体投放数据
    # 查找"合计"行获取总消费
    ws1 = wb['整体投放数据']

    total_cost = 0
    total_new_customer = 0
    total_new_customer_cost = 0

    for row in ws1.iter_rows(values_only=True):
        if row and len(row) > 3:
            # 查找"合计"行（第3列是"合计"）
            if row[2] and '合计' in str(row[2]):
                total_cost = float(row[5] or 0)  # 消费列（第6列）
                total_new_customer = float(row[8] or 0)  # 新客数列（第9列）
                total_new_customer_cost = float(row[10] or 0)  # 新客成本列（第11列）
                break

    summary = f"""【唯品会】{date_label} 周报数据
总消费：{total_cost:.1f} 元
新客数：{total_new_customer:.0f}
新客成本(DMP口径)：{total_new_customer_cost:.1f} 元"""

    return summary


def main():
    import argparse
    parser = argparse.ArgumentParser(description='发送周报飞书消息')
    parser.add_argument('--date', required=True, help='周期标签，如 "6.9-6.15"')
    args = parser.parse_args()

    date_label = args.date

    try:
        # 读取配置
        config = get_config()
        feishu_config = config.get('feishu_send', config.get('feishu', {}))

        app_id = feishu_config.get('app_id')
        app_secret = feishu_config.get('app_secret')
        target_group = feishu_config.get('target_group')

        if not app_id or not app_secret:
            raise Exception('配置文件中缺少 feishu.app_id 或 feishu.app_secret')

        if not target_group:
            print('[WARN] 未配置 target_group，跳过消息发送')
            return

        # 获取 tenant token
        print(f'\n[1/4] 获取 tenant token...')
        tenant_token = get_tenant_token(app_id, app_secret)

        # 上传 Excel
        xlsx_path = OUTPUT_DIR / f'唯品会周报-{date_label}.xlsx'
        if not xlsx_path.exists():
            raise Exception(f'Excel 文件不存在: {xlsx_path}')

        print(f'\n[2/4] 上传 Excel 文件...')
        file_key = upload_file(tenant_token, xlsx_path)

        # 发送文件消息
        print(f'\n[3/4] 发送周报文件...')
        file_content = {
            'file_key': file_key,
            'file_name': f'唯品会周报-{date_label}.xlsx'
        }
        send_message(tenant_token, target_group, 'file', file_content)

        # 构造并发送摘要
        print(f'\n[4/4] 发送摘要和告警...')

        # 构造摘要
        summary = build_summary(xlsx_path, date_label)

        # 读取校验结果
        # 从 date_label 解析日期范围
        parts = date_label.replace(' ', '').split('-')
        if len(parts) >= 4:
            start_month = parts[0]
            start_day = parts[1]
            end_month = parts[2]
            end_day = parts[3]
            validation_fname = f'validation_{start_month}{start_day}_{end_month}{end_day}.json'
        else:
            validation_fname = None

        validation_alert = None
        if validation_fname:
            validation_path = OUTPUT_DIR / validation_fname
            if validation_path.exists():
                with open(validation_path, 'r', encoding='utf-8') as f:
                    validation_data = json.load(f)
                validation_alert = build_validation_alert(validation_data, date_label)

        # 组合消息
        message_text = summary
        if validation_alert:
            message_text += '\n\n' + validation_alert

        send_message(tenant_token, target_group, 'text', {'text': message_text})

        print(f'\n✅ 消息发送完成')
        print('=' * 50)

    except Exception as e:
        print(f'\n✗ 消息发送失败: {e}')
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
