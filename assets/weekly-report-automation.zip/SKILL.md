---
name: weekly-report-automation
label: 客户周报自动化助手
description: 帮助员工生成客户广告投放周报。适用于需要将多源数据映射为统一口径、生成固定格式报表、输出校验摘要，并沉淀为可复用周报流程的场景。
---

# 客户周报自动化助手

这个 Skill 用来把客户周报流程标准化：在私有环境接入业务数据，按计划标识和点位码建立跨源映射，按配置计算指标、执行校验回补，并生成固定结构的周报文件。

## 使用目标

- 减少每周手工整理数据的重复工作。
- 固定周报结构，避免不同周口径不一致。
- 把数据接入、字段映射、计算、回补和输出拆分，便于复用到其他客户。
- 支持统计级和明细级两类数据路径，为不同报表结构提供统一处理框架。
- 作品集版本只保留通用模板，不包含真实客户名、账户标识、登录状态、密钥、连接地址、缓存或历史产出。

## 目录结构

```text
weekly-report-automation/
├── SKILL.md
├── README.md
├── configs/
│   ├── accounts.example.json
│   └── weekly_report_config.json
├── scripts/
│   ├── run_weekly_report.py
│   └── report_builder.py
└── output/
```

## 快速开始

```bash
cp configs/accounts.example.json configs/accounts.json
python scripts/run_weekly_report.py --start-date 2026-06-01 --end-date 2026-06-07 --accounts configs/accounts.json
```

`accounts.json` 由使用者在本地填写账户 ID，不能提交到公开仓库。默认会读取 `configs/weekly_report_config.json`；没有提供本地数据文件时，脚本会按账户 ID 生成一份空白周报格式，方便验证交付流程。

## 工作流程

1. 确认周报周期，例如“上周”或指定起止日期。
2. 读取配置文件，确认客户名称、分组维度和指标口径。
3. 复制账户配置示例并填入需要出报的账户 ID。
4. 在私有环境读取或拉取业务数据；公开版使用空白数据验证报表流程。
5. 按计划标识、点位码或其他配置键完成跨源映射。
6. 按配置聚合指标，计算成本、点击率、转化率等派生字段。
7. 执行字段完整性和指标口径校验；必要时按私有规则执行异常回补。
8. 生成周报文件和校验摘要，返回输出路径、数据行数和异常提示。

## 配置说明

`configs/weekly_report_config.json` 只放通用配置：

- `client_label`：客户展示名，使用占位名称。
- `date_range`：默认日期范围。
- `groups`：报告分组维度。
- `metrics`：需要统计的指标。
- `derived_metrics`：由基础指标计算出的字段。
- `sheets`：周报文件中的页面结构。
- `mapping_keys`：跨源映射所需的通用字段名称，不填真实标识。
- `validation`：字段完整性、指标口径和异常回补的校验规则。
- `accounts.json`：使用者本地维护的账户 ID 列表；只读取，不写入公开包。

不要把真实客户名、登录状态、密钥、连接地址或历史数据写进配置。

## 输出说明

脚本会在 `output/` 下生成：

- `weekly_report_YYYYMMDD_YYYYMMDD.csv`
- `validation_YYYYMMDD_YYYYMMDD.json`

如果本地安装了 `openpyxl`，也可以扩展为 Excel 输出。

## 交付检查

交付前检查：

- 是否已经删除真实客户名、账户 ID、计划 ID、点位码和其他业务标识。
- 是否没有保存登录状态、Cookie、令牌、密钥、连接地址、缓存和历史产出。
- 周报周期是否正确。
- 指标口径是否在配置中可追溯。
- 输出文件是否能直接打开。
