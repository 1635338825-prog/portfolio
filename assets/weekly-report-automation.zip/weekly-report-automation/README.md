# 客户周报自动化模板

这是一个脱敏后的周报自动化 Skill 模板，用来展示如何把广告投放周报流程沉淀成可复用工具。

## 包含内容

- `SKILL.md`：使用说明和流程约束
- `configs/weekly_report_config.json`：通用配置模板
- `scripts/run_weekly_report.py`：主入口
- `scripts/report_builder.py`：本地数据聚合和文件生成
- `output/`：运行时输出目录

## 不包含内容

这个作品集版本不会包含：

- 真实客户名
- 真实账号
- 登录状态
- 密钥
- 连接地址
- 历史周报文件
- 历史明细数据

## 运行示例

```bash
cd scripts
python run_weekly_report.py --start-date 2026-06-01 --end-date 2026-06-07
```

运行后会在 `output/` 下生成周报 CSV 和校验摘要。

## 适合复用的场景

- 每周固定生成客户投放报告
- 多个数据文件需要统一清洗和聚合
- 报表结构固定，但客户配置不同
- 需要把人工整理流程改成可重复执行的脚本

## 扩展方式

1. 在 `configs/weekly_report_config.json` 中添加新的分组和指标。
2. 在 `report_builder.py` 中补充计算逻辑。
3. 将真实数据读取方式放在私有环境中维护，不写入作品集版本。
