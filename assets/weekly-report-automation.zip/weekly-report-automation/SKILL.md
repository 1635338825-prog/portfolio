---
name: weekly-report-automation
label: 客户周报自动化助手
description: 帮助员工生成客户广告投放周报。适用于需要把多份本地数据整理成固定格式周报、生成 Excel 或 CSV 文件、输出校验摘要，并沉淀为可复用周报流程的场景。
---

# 客户周报自动化助手

这个 Skill 用来把客户周报流程标准化：读取本地数据、按配置计算指标、生成固定结构的周报文件，并输出校验摘要。

## 使用目标

- 减少每周手工整理数据的重复工作。
- 固定周报结构，避免不同周口径不一致。
- 把配置、脚本和输出分开，便于复用到其他客户。
- 作品集版本只保留通用模板，不包含真实客户名、登录状态、密钥、连接地址或历史产出。

## 目录结构

```text
weekly-report-automation/
├── SKILL.md
├── README.md
├── configs/
│   └── weekly_report_config.json
├── scripts/
│   ├── run_weekly_report.py
│   └── report_builder.py
└── output/
```

## 快速开始

```bash
cd scripts
python run_weekly_report.py --start-date 2026-06-01 --end-date 2026-06-07
```

默认会读取 `configs/weekly_report_config.json`。如果没有提供本地数据文件，脚本会生成一份示例周报，方便验证流程。

## 工作流程

1. 确认周报周期，例如“上周”或指定起止日期。
2. 读取配置文件，确认客户名称、分组维度和指标口径。
3. 读取本地数据文件；如果没有数据文件，则使用示例数据。
4. 按配置聚合指标，计算成本、点击率、转化率等派生字段。
5. 生成周报文件和校验摘要。
6. 返回输出路径、数据行数和异常提示。

## 配置说明

`configs/weekly_report_config.json` 只放通用配置：

- `client_label`：客户展示名，使用占位名称。
- `date_range`：默认日期范围。
- `groups`：报告分组维度。
- `metrics`：需要统计的指标。
- `derived_metrics`：由基础指标计算出的字段。
- `sheets`：周报文件中的页面结构。

不要把真实客户名、登录状态、密钥、连接地址或历史数据写进配置。

## 输出说明

脚本会在 `output/` 下生成：

- `weekly_report_YYYYMMDD_YYYYMMDD.csv`
- `validation_YYYYMMDD_YYYYMMDD.json`

如果本地安装了 `openpyxl`，也可以扩展为 Excel 输出。

## 交付检查

交付前检查：

- 是否已经删除真实客户名和真实账号。
- 是否没有保存登录状态、密钥、连接地址和历史产出。
- 周报周期是否正确。
- 指标口径是否在配置中可追溯。
- 输出文件是否能直接打开。
