# 小红书聚光广告API接口速查

基础域名: https://adapi.xiaohongshu.com

## 离线接口（Offline）

核心数据（展点消）最早在**次日10点**产出。

| 层级 | 路径 | 支持split_columns | 支持filters | 支持time_unit | 最大page_size |
|------|------|-------------------|-------------|---------------|---------------|
| 账户 | /api/open/jg/data/report/offline/account | ✅ 全量 | ❌ | DAY/HOUR/SUMMARY | 500 |
| 笔记 | /api/open/jg/data/report/offline/note | ❌ | ✅ | DAY/HOUR/SUMMARY | 500 |
| 创意 | /api/open/jg/data/report/offline/creative | ✅ 全量 | ✅ | DAY/HOUR/SUMMARY | 500 |
| 关键词 | /api/open/jg/data/report/offline/keyword | ❌ | ❌ | DAY/HOUR/SUMMARY | 500 |
| 搜索词 | /api/open/jg/data/report/offline/search/word | ❌ | ❌ | DAY/HOUR/SUMMARY | 500 |

> ⚠️ **关键词 & 搜索词接口返回粒度说明**
> 
> 这两个接口返回的是「词 × 广告单元」粒度，即同一个关键词/搜索词在多个广告单元中投放时，会返回多行。
> `time_unit=SUMMARY` 只聚合了时间维度，**不会按词文本去重**。
> 
> **引擎已自动处理**：report_engine 对 keyword/search_word endpoint 会在输出前自动按词文本 groupby 聚合（cumulative字段求和，ratio字段由 calculated_metrics 重算）。
> Config 无需任何额外配置，但 **ratio字段（acp/cpm/ctr/各成本）必须写在 `calculated_metrics` 中**，不能放 `metrics` 直接取值，否则聚合后数值错误。

### 离线接口通用请求参数
- advertiser_id (long, 必填)
- start_date (string, 必填, yyyy-MM-dd)
- end_date (string, 必填, yyyy-MM-dd)
- time_unit (string, 可选, 默认DAY)
- page_num (int, 可选, 默认1)
- page_size (int, 可选, 默认20, 最大500)
- sort_column (string, 可选)
- sort (string, 可选, asc/desc)
- data_caliber (int, 可选, 0=计费时间/点击时间, 1=转化时间)

### 离线接口通用过滤参数（账户/创意层级支持）
- marketing_target (integer[])
- bidding_strategy (integer[])
- optimize_target (integer[])
- placement (integer[])
- promotion_target (integer[])
- delivery_mode (integer[])

### split_columns 可选值（账户/创意层级）
marketingTarget, deliveryMode, placement, optimizeTarget, biddingStrategy,
promotionTarget, jumpType, countryName, province, city, gender, age, device,
targetDetail, keyword, searchFeedType, itemId, pageId, liveRedId
（商品/落地页/直播间笔记只能三选一）

### 离线接口通用响应结构
```json
{
  "code": 0, "success": true, "msg": "成功",
  "data": {
    "total_count": 100,
    "data_list": [...],        // 明细数据
    "aggregation_data": {...}  // 汇总数据
  }
}
```

## 实时接口（Realtime）

数据即时可用，支持拉取小时数据（仅当天）。

| 层级 | 路径 | 支持split_columns | 最大page_size |
|------|------|-------------------|---------------|
| 账户 | /api/open/jg/data/report/realtime/account | ❌ | 无分页（返回汇总） |
| 关键词 | /api/open/jg/data/report/realtime/keyword | ❌ | 100 |
| 创意 | /api/open/jg/data/report/realtime/creativity | ❌ | 100 |

注意：实时接口**无笔记层级**和**搜索词层级**。

### 实时接口通用请求参数
- advertiser_id (long, 必填)
- start_date (string, 必填)
- end_date (string, 必填)
- need_hourly_data (bool, 可选, 仅支持当天)

### 实时接口响应结构
账户实时：直接返回 data (DataReportDTO) + hourly_data
关键词/创意实时：返回分页列表 + total_data汇总

## 简单投接口（Easy Promotion）

简单投是聚光的简化投放模式，数据来自独立接口，与普通投放**不重叠**。

| 层级 | 路径 | 支持split_columns | 支持time_unit | 最大page_size |
|------|------|-------------------|---------------|---------------|
| 简单投笔记 | /api/open/jg/data/report/offline/easy/promotion/note | city, keyword, noteId | DAY/SUMMARY | 500 |

### 简单投接口限制

| 参数 | 支持 | 说明 |
|------|------|------|
| `city` | ✅ | 城市维度，需映射到省份后合并 |
| `keyword` | ✅ | 关键词维度 |
| `noteId` | ✅ | 笔记维度 |
| `province` | ❌ | 不支持，用 city 代替 |
| `deliveryMode` | ❌ | 不支持 |
| `optimizeTarget` | ❌ | 不支持 |

### 简单投请求参数
- advertiser_id (long, 必填)
- start_date (string, 必填, yyyy-MM-dd)
- end_date (string, 必填, yyyy-MM-dd)
- time_unit (string, 可选, 默认SUMMARY)
- split_columns (string[], 可选)
- page_num (int, 可选, 默认1)
- page_size (int, 可选, 默认20, 最大500)

### 简单投响应结构
```json
{
  "code": 0, "success": true, "msg": "成功",
  "data": {
    "total_count": 100,
    "data_list": [...]  // 无 aggregation_data，需手动计算汇总
  }
}
```

### 混合模式数据合并

当用户需要同时包含普通投放和简单投数据时：

1. **分别拉取**：普通投放用 account 接口，简单投用 easy 接口
2. **简单投预处理**：
   - 分日数据按 time 字段聚合（同一天多条笔记合并）
   - 城市数据 city → province 映射后合并
3. **累加型字段相加**：fee, impression, click, message_consult, initiative_message, msg_leads_num
4. **ratio 字段清空**：所有已计算的 ratio 字段丢弃
5. **ratio 重算**：用合并后的累加值重新计算（见 SKILL.md 中的 ratio 重算公式表）

**核心约束**：ratio 字段不能直接用 API 返回值，合并后必须重新计算。

## HEADER（所有接口通用）
- Content-Type: application/json
- Access-Token: {token}
