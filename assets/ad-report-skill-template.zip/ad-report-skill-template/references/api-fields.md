# 小红书聚光广告API字段参考

> 所有指标直接使用API返回值。不需要标注类型或是否可累加。
> 自定义计算需求通过config的calculated_metrics + formula实现。

## 业务字段（仅特定接口返回）

| 字段 | 类型 | 说明 | 接口 |
|------|------|------|------|
| time | string | 时间 | 离线全部 |
| note_id | string | 笔记id | 笔记/创意 |
| note_title | string | 笔记标题 | 笔记/创意 |
| note_image | string | 笔记图片 | 笔记/创意 |
| note_jump_url | string | 笔记链接 | 笔记/创意 |
| campaign_id | string/long | 计划id | 创意/关键词 |
| campaign_name | string | 计划名称 | 创意/关键词 |
| unit_id | string/long | 单元id | 创意/关键词 |
| unit_name | string | 单元名称 | 创意/关键词 |
| creativity_id | long | 创意id | 创意 |
| creativity_name | string | 创意名称 | 创意 |
| keyword | string | 关键词 | 关键词 |
| keyword_id | long | 关键词id | 关键词 |
| search_word | string | 搜索词 | 搜索词 |
| page_id | string | 落地页id | 账户(细分) |
| item_id | string | 商品id | 账户(细分) |
| province | string | 省份 | 账户(细分) |
| city | string | 城市 | 账户(细分) |
| placement | string | 广告类型 | 账户(细分) |
| optimize_target | string | 优化目标 | 账户(细分) |
| delivery_mode | string | 投放模式 | 账户(细分) |

## 基础指标

| 字段 | 说明 |
|------|------|
| fee | 消费(元) |
| impression | 展现量 |
| click | 点击量 |
| ctr | 点击率 |
| acp | 平均点击成本 |
| cpm | 千次展现费用 |

## 笔记互动指标

| 字段 | 说明 |
|------|------|
| like | 点赞 |
| comment | 评论 |
| collect | 收藏 |
| follow | 关注 |
| share | 分享 |
| interaction | 互动量 |
| cpi | 平均互动成本 |
| action_button_click | 行动按钮点击量 |
| action_button_ctr | 行动按钮点击率 |
| screenshot | 截图 |
| pic_save | 保存图片 |
| reserve_pv | 预告组件点击 |

## 直播间互动指标

| 字段 | 说明 |
|------|------|
| clk_live_entry_pv | 直播间观看次数 |
| clk_live_entry_pv_cost | 直播间观看成本 |
| clk_live_avg_view_time | 人均停留时长(分钟) |
| clk_live_all_follow | 直播间新增粉丝量 |
| clk_live_5s_entry_pv | 有效观看次数 |
| clk_live_5s_entry_uv_cost | 有效观看成本 |
| clk_live_comment | 直播间评论次数 |

## 笔记种草指标

| 字段 | 说明 |
|------|------|
| search_cmt_click | 搜索组件点击量 |
| search_cmt_click_cvr | 搜索组件点击转化率 |
| search_cmt_after_read | 搜后阅读量 |
| search_cmt_after_read_avg | 平均搜后阅读篇数 |
| i_user_num | 新增种草人群 |
| ti_user_num | 新增深度种草人群 |
| i_user_price | 种草人群成本 |
| ti_user_price | 深度种草人群成本 |

## 电商转化指标-购买兴趣

| 字段 | 说明 |
|------|------|
| goods_visit | 进店访问量 |
| goods_visit_price | 进店访问成本 |
| seller_visit | 商品访客量 |
| seller_visit_price | 商品访客成本 |
| shopping_cart_add | 商品加购量 |
| add_cart_price | 商品加购成本 |

## 电商转化指标-7日转化

| 字段 | 说明 |
|------|------|
| presale_order_num_7d | 7日预售订单量 |
| presale_order_gmv_7d | 7日预售订单金额 |
| goods_order | 7日下单订单量 |
| goods_order_price | 7日下单订单成本 |
| rgmv | 7日下单金额 |
| roi | 7日下单ROI |
| success_goods_order | 7日支付订单量 |
| click_order_cvr | 7日支付转化率 |
| purchase_order_price_7d | 7日支付订单成本 |
| purchase_order_gmv_7d | 7日支付金额 |
| purchase_order_roi_7d | 7日支付ROI |

## 电商转化指标-直播间转化

| 字段 | 说明 |
|------|------|
| clk_live_room_order_num | 直播间支付订单量 |
| live_average_order_cost | 直播间支付订单成本 |
| clk_live_room_rgmv | 直播间支付金额 |
| clk_live_room_roi | 直播间支付ROI |

## 销售线索指标

| 字段 | 说明 |
|------|------|
| leads | 表单提交 |
| leads_cpl | 表单成本 |
| landing_page_visit | 落地页访问量 |
| leads_button_impression | 表单按钮曝光量 |
| valid_leads | 有效表单 |
| valid_leads_cpl | 有效表单成本 |
| leads_cvr | 表单转化率 |
| phone_call_cnt | 电话拨打 |
| phone_call_succ_cnt | 电话接通 |
| wechat_copy_cnt | 微信复制 |
| wechat_copy_succ_cnt | 微信加为好友 |
| identity_certi_cnt | 身份认证 |
| commodity_buy_cnt | 付费 |

## 私信营销指标

| 字段 | 说明 |
|------|------|
| message_user | 私信进线人数 |
| message | 私信开口条数 |
| message_consult | 私信进线数 |
| message_fst_reply_time_avg | 平均响应时长(分) |
| fst_message_reply_in_45s_rate | 45s首响率 |
| message_reply_in_3min_rate | 3分钟回复率 |
| message_reply_in_1min_rate | 1分钟回复率 |
| message_reply_in_30s_rate | 30秒回复率 |
| initiative_message | 私信开口数 |
| message_consult_cpl | 私信进线成本 |
| initiative_message_cpl | 私信开口成本 |
| msg_leads_num | 私信留资数 |
| msg_leads_cost | 私信留资成本 |

## 行业商品销量指标（7/15/30日）

以7日为例（15/30日字段后缀改为_15/_30）：

| 字段 | 说明 |
|------|------|
| external_goods_visit_7 | 行业商品点击量 |
| external_goods_visit_price_7 | 行业商品点击成本 |
| external_goods_visit_rate_7 | 行业商品点击转化率 |
| external_goods_order_7 | 成交订单量(7日) |
| external_rgmv_7 | GMV(7日) |
| external_goods_order_price_7 | 成交订单成本(7日) |
| external_goods_order_rate_7 | 成交订单转化率(7日) |
| external_roi_7 | ROI(7日) |

## 外链专属指标

| 字段 | 说明 |
|------|------|
| external_leads | 外链转化数 |
| external_leads_cpl | 平均外链转化成本 |

## 企微营销指标

| 字段 | 说明 |
|------|------|
| add_wechat_count | 添加企微量 |
| add_wechat_cost | 添加企微成本 |
| add_wechat_suc_count | 成功添加企微量 |
| add_wechat_suc_cost | 成功添加企微成本 |
| wechat_talk_count | 企微开口量 |
| wechat_talk_cost | 企微开口成本 |

## 门店营销指标

| 字段 | 说明 |
|------|------|
| shop_poi_click_num | 组件点击量 |
| shop_poi_page_pv | 门店页面访问量 |
| shop_poi_page_visit_price | 门店页面访问成本 |
| shop_poi_page_navigate_click | 导航栏按钮点击量 |

## 关键词指标（仅关键词/搜索相关接口）

| 字段 | 说明 |
|------|------|
| word_avg_location | 平均位次 |
| word_impression_rate_first | 首位曝光占比 |
| word_impression_rate_third | 前三位曝光占比 |
| word_click_rate_first | 首位点击占比 |
| word_click_rate_third | 前三位点击占比 |
| word_impression_rate_all | 全坑位曝光占比 |
| word_click_rate_all | 全坑位点击占比 |

## APP内转化/唤端指标

| 字段 | 说明 |
|------|------|
| invoke_app_open_cnt | APP打开量 |
| invoke_app_open_cost | APP打开成本 |
| invoke_app_enter_store_cnt | APP进店量 |
| invoke_app_enter_store_cost | APP进店成本 |
| invoke_app_engagement_cnt | APP互动量 |
| invoke_app_engagement_cost | APP互动成本 |
| invoke_app_payment_cnt | APP支付次数 |
| invoke_app_payment_cost | APP支付成本 |
| invoke_app_payment_amount | APP支付金额 |
| invoke_app_payment_roi | APP支付ROI |
| invoke_app_payment_unit_price | APP支付单价 |
| search_invoke_button_click_cnt | APP打开按钮点击量 |
| search_invoke_button_click_cost | APP打开按钮点击成本 |

## 应用下载指标

| 字段 | 说明 |
|------|------|
| app_download_button_click_cnt | 下载按钮点击 |
| app_download_button_click_ctr | 下载按钮点击率 |
| app_download_button_click_cost | 下载按钮点击成本 |
| app_activate_cnt | 激活数 |
| app_activate_cost | 激活成本 |
| app_activate_ctr | 激活率 |
| app_register_cnt | 注册数 |
| app_register_cost | 注册成本 |
| app_register_ctr | 注册率 |
| first_app_pay_cnt | 首次付费数 |
| first_app_pay_cost | 首次付费成本 |
| first_app_pay_ctr | 首次付费率 |
| current_app_pay_cnt | 当日付费次数 |
| current_app_pay_cost | 当日付费成本 |
| app_key_action_cnt | 关键行为数 |
| app_key_action_cost | 关键行为成本 |
| app_key_action_ctr | 关键行为率 |
| app_pay_cnt_7d | 7日付费次数 |
| app_pay_cost_7d | 7日付费成本 |
| app_pay_amount | 付费金额 |
| app_pay_roi | 付费ROI |
| app_activate_amount_1d | 当日LTV |
| app_activate_amount_3d | 三日LTV |
| app_activate_amount_7d | 七日LTV |
| app_activate_amount_1d_roi | 当日广告付费ROI |
| app_activate_amount_3d_roi | 三日广告付费ROI |
| app_activate_amount_7d_roi | 七日广告付费ROI |
| retention_1d_cnt | 次留 |
| retention_3d_cnt | 3日留存 |
| retention_7d_cnt | 7日留存 |

## 小红盟数据

| 字段 | 说明 |
|------|------|
| jd_active_user_num | 站外活跃行为UV |
| jd_active_user_num_cvr_new | 站外活跃率 |
| jd_active_user_num_cpl | 站外活跃成本 |
| jd_task_fee | 任务期消费 |
| jd_task_read_user_cnt | 任务期阅读UV |

## 小程序指标

| 字段 | 说明 |
|------|------|
| wechat_applets_open_cnt | 微信打开按钮点击次数 |
| wechat_applets_pay_cnt | 小程序付费次数 |
| wechat_applets_activate_cnt | 小程序激活次数 |
| wechat_applets_pay_amount | 小程序付费总金额 |
| wechat_applets_pay_amount_3d | 激活后三日付费总金额 |
| wechat_applets_pay_amount_7d | 激活后七日付费总金额 |
| wechat_applets_pay_cnt_3d | 激活后三日付费次数 |
| wechat_applets_pay_cnt_7d | 激活后七日付费次数 |

## 视频播放指标（仅创意层级）

| 字段 | 说明 |
|------|------|
| video_play_cnt | 视频播放量 |
| video_play_5s_cnt | 5s播放量 |
| video_play_5s_rate | 5s完播率 |
