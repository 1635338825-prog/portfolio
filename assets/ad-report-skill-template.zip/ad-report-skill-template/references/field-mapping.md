# 业务术语 ↔ API字段映射表

> 只记录业务术语与API名称**不一致**的条目。完全一致的不收录。
> 每次需求处理后，发现新的不一致映射，立即追加。

## 指标映射（metrics 的 field）

| API中文 | API英文 | 业务中文 | 业务英文 |
|---------|---------|----------|----------|
| 平均点击成本 | acp | CPC | CPC |
| 平均千次展现费用 | cpm | CPM | CPM |
| 平均互动成本 | cpi | CPE | CPE |
| 私信开口条数 | message | 开口条数 | — |
| 私信进线数 | message_consult | 进线数/进线 | — |
| 私信开口数 | initiative_message | 开口数/开口 | — |
| APP打开按钮点击量 | search_invoke_button_click_cnt | 笔记唤端组件点击量 | — |
| 私信进线人数 | message_user | 进线人数 | — |

## 维度映射（split_columns 的值）

| API维度值 | 业务术语 | 说明 |
|----------|---------|------|
| placement | 投放点位/广告类型 | 信息流/搜索/全站智投/视频流 |
| deliveryMode | 投放模式 | 手动投放/自动投放 |
| optimizeTarget | 优化目标/推广目标 | API返回数字码，engine内有枚举映射 |
| province | 地域/省份 | — |
| city | 城市 | — |
| gender | 性别 | — |
| age | 年龄 | — |
| device | 平台/设备 | — |
| marketingTarget | 营销诉求 | — |
| biddingStrategy | 出价方式 | — |

## 简单投接口字段说明

简单投接口路径：`/api/open/jg/data/report/offline/easy/promotion/note`

### 支持的维度（split_columns）

| 维度 | 说明 | 注意事项 |
|------|------|----------|
| city | 城市 | 需映射到省份后合并 |
| keyword | 关键词 | — |
| noteId | 笔记ID | — |

**不支持的维度**：province（用 city 代替）、deliveryMode、optimizeTarget

### 字段映射

简单投接口的字段与普通投放一致，参见上方指标映射表。

### 混合模式注意事项

当普通投放 + 简单投数据合并时：
- 累加型字段（fee, impression, click 等）直接相加
- **ratio 字段必须重新计算**，不能直接用 API 返回值
- 重算公式见 calculation-rules.md 的「简单投混合模式 ratio 重算规则」
