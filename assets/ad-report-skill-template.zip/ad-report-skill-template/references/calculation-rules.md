# 计算规则知识库

> 记录API没有但业务需要的自定义计算公式。
> 每次需求处理后，发现新规则立即追加。
> engine 通过 calculated_metrics 的 formula 表达式执行计算。
>
> **写入边界**：
> - ✅ 写入：API字段表（api-fields.md）中**不存在**的业务指标，如进线转开口率、留资率
> - ✅ 写入：keyword/search_word section 的 ratio 字段公式（聚合后重算用）
> - ❌ 不写入：API已有的字段（如 acp、cpm、msg_leads_cost），直接在 metrics 里取值即可

## 自定义计算指标

| 指标名 | formula表达式 | 来源场景 |
|--------|---------------|----------|
| 进线率 | message_consult / click | 美莱留资周报 |
| 进线转开口率 | initiative_message / message_consult | 美莱留资周报 |
| 开口转留资率 | msg_leads_num / initiative_message | 美莱留资周报 |
| 留资率 | msg_leads_num / message_consult | 水滴周报 |
| 搜索消耗占比 | 关键词层级fee汇总 / 账户层级fee | 美莱留资周报（跨层级，需特殊处理） |

## 简单投混合模式 ratio 重算规则

当普通投放 + 简单投数据合并时，所有 ratio 字段必须重新计算：

| 字段 | formula | 说明 |
|------|---------|------|
| CPC（点击成本） | fee / click | 同 ACP |
| CPM（千次展现成本） | fee / impression * 1000 | |
| ACP（平均消费） | fee / click | 同 CPC |
| 进线成本 | fee / message_consult | |
| 开口成本 | fee / initiative_message | |
| 留资成本 | fee / msg_leads_num | |
| 点击率 | click / impression | |
| 进线率 | message_consult / click | |
| 开口率 | initiative_message / message_consult | 分母是进线数 |
| 留资率 | msg_leads_num / initiative_message | 分母是开口数 |

**核心约束**：
- 累加型字段（fee, impression, click 等）直接相加
- ratio 字段全部清空，等合并后重算
- 不能直接用 API 返回的已计算值

## 多账户合并 ratio 重算规则

当多个广告主账户数据合并时，ratio 字段同样需要重算：

| 字段 | formula | 说明 |
|------|---------|------|
| CPC | fee / click | |
| CPM | fee / impression * 1000 | |
| 点击率 | click / impression | |
| 进线率 | message_consult / click | |
| 开口率 | initiative_message / message_consult | |
| 留资率 | msg_leads_num / initiative_message | |

**配置方式**：
- 累加型字段放 `metrics`
- ratio 字段放 `calculated_metrics`，写 formula 表达式
