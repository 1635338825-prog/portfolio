"""
统一数据获取模块 - 支持所有小红书聚光广告API endpoint
"""
import requests
import time
from token_manager import TokenManager


# endpoint到API路径的映射
ENDPOINT_PATHS = {
    # 离线接口
    "account": "/api/open/jg/data/report/offline/account",
    "note": "/api/open/jg/data/report/offline/note",
    "creative": "/api/open/jg/data/report/offline/creative",
    "keyword": "/api/open/jg/data/report/offline/keyword",
    "search_word": "/api/open/jg/data/report/offline/search/word",
    # 简单投接口
    "easy_note": "/api/open/jg/data/report/offline/easy/promotion/note",
    # 实时接口
    "account_realtime": "/api/open/jg/data/report/realtime/account",
    "keyword_realtime": "/api/open/jg/data/report/realtime/keyword",
    "creative_realtime": "/api/open/jg/data/report/realtime/creativity",
}

# 简单投接口支持的split_columns
EASY_SPLIT_SUPPORTED = {"city", "keyword", "noteId"}

# 支持split_columns的endpoint
SPLIT_SUPPORTED = {"account", "creative"}

# 支持filters的endpoint
FILTER_SUPPORTED = {"note", "creative"}

BASE_URL = "https://adapi.xiaohongshu.com"


class DataFetcher:
    def __init__(self, token_manager: TokenManager):
        self.token_manager = token_manager

    def fetch_easy_note(self, advertiser_id, start_date, end_date,
                        time_unit="SUMMARY", split_columns=None,
                        page_size=500, max_retries=2):
        """
        简单投笔记数据获取

        Args:
            advertiser_id: 广告主ID
            start_date: 开始日期 yyyy-MM-dd
            end_date: 结束日期 yyyy-MM-dd
            time_unit: 时间粒度 DAY/SUMMARY
            split_columns: 细分条件列表，仅支持 city/keyword/noteId
            page_size: 页大小 (最大500)
            max_retries: 最大重试次数

        Returns:
            dict: {
                'data_list': [...],         # 明细数据列表
                'total_count': int           # 总条数
            }
            失败返回 None
        """
        path = ENDPOINT_PATHS.get("easy_note")
        url = f"{BASE_URL}{path}"

        all_data = []
        page_num = 1

        while True:
            for attempt in range(max_retries):
                try:
                    access_token = self.token_manager.get_access_token_for_advertiser(advertiser_id)
                    headers = {
                        "content-type": "application/json",
                        "Access-Token": access_token
                    }

                    payload = {
                        "advertiser_id": int(advertiser_id),
                        "start_date": start_date,
                        "end_date": end_date,
                        "page_num": page_num,
                        "page_size": page_size
                    }

                    if time_unit:
                        payload["time_unit"] = time_unit

                    # split_columns (仅支持 city/keyword/noteId)
                    if split_columns:
                        # 验证 split_columns 是否在支持范围内
                        valid_splits = [s for s in split_columns if s in EASY_SPLIT_SUPPORTED]
                        if valid_splits:
                            payload["split_columns"] = valid_splits

                    response = requests.post(url, json=payload, headers=headers, timeout=30)
                    result = response.json()

                    if result.get('success') and result.get('code') == 0:
                        resp_data = result.get('data', {})
                        data_list = resp_data.get('data_list', [])
                        total_count = resp_data.get('total_count', 0)

                        all_data.extend(data_list)

                        if len(all_data) >= total_count or not data_list:
                            return {
                                'data_list': all_data,
                                'total_count': total_count
                            }

                        page_num += 1
                        break

                    if self._is_token_error(result):
                        if self._retry_token(attempt, max_retries, advertiser_id):
                            continue
                        return None

                    print(f"简单投请求失败: {result.get('msg', '未知错误')}")
                    return None

                except Exception as e:
                    if not self._handle_exception(e, attempt, max_retries):
                        return None
            else:
                print("简单投达到最大重试次数")
                return None

        return {'data_list': all_data, 'total_count': len(all_data)} if all_data else None

    def fetch(self, endpoint, advertiser_id, start_date, end_date,
              time_unit="DAY", split_columns=None, filters=None,
              marketing_target=None, bidding_strategy=None,
              optimize_target=None, placement=None,
              promotion_target=None, delivery_mode=None,
              sort_column=None, sort="desc",
              page_size=500, data_caliber=None,
              max_retries=2):
        """
        统一数据获取接口

        Args:
            endpoint: 接口类型 (account/note/creative/keyword/search_word)
                      加 _realtime 后缀使用实时接口
            advertiser_id: 广告主ID
            start_date: 开始日期 yyyy-MM-dd
            end_date: 结束日期 yyyy-MM-dd
            time_unit: 时间粒度 DAY/HOUR/SUMMARY (离线接口)
            split_columns: 细分条件列表 (仅account/creative离线支持)
            filters: 过滤条件 FilterClause[] (仅note/creative离线支持)
            marketing_target: 营销目标过滤 integer[]
            bidding_strategy: 出价方式过滤 integer[]
            optimize_target: 推广目标过滤 integer[]
            placement: 广告类型过滤 integer[]
            promotion_target: 推广标的过滤 integer[]
            delivery_mode: 投放模式过滤 integer[]
            sort_column: 排序字段
            sort: 排序方式 asc/desc
            page_size: 页大小 (最大500)
            data_caliber: 归因时间类型 0=点击/计费时间 1=转化时间
            max_retries: 最大重试次数

        Returns:
            dict: {
                'data_list': [...],         # 明细数据列表
                'aggregation_data': {...},   # 汇总数据(离线接口)
                'total_data': {...},         # 汇总数据(实时接口)
                'total_count': int           # 总条数
            }
            失败返回 None
        """
        path = ENDPOINT_PATHS.get(endpoint)
        if not path:
            print(f"不支持的endpoint: {endpoint}")
            return None

        url = f"{BASE_URL}{path}"
        is_realtime = endpoint.endswith("_realtime")

        # 实时账户接口不分页，直接请求
        if endpoint == "account_realtime":
            return self._fetch_realtime_account(url, advertiser_id,
                                                 start_date, end_date,
                                                 max_retries,
                                                 need_hourly_data=(time_unit == "HOUR"))

        # 其他接口支持分页
        return self._fetch_with_pagination(
            url, endpoint, advertiser_id, start_date, end_date,
            time_unit, split_columns, filters,
            marketing_target, bidding_strategy, optimize_target,
            placement, promotion_target, delivery_mode,
            sort_column, sort, page_size, data_caliber,
            is_realtime, max_retries
        )

    def _fetch_realtime_account(self, url, advertiser_id,
                                 start_date, end_date, max_retries,
                                 need_hourly_data=False):
        """实时账户接口（不分页，返回汇总数据）"""
        for attempt in range(max_retries):
            try:
                access_token = self.token_manager.get_access_token_for_advertiser(advertiser_id)
                headers = {
                    "content-type": "application/json",
                    "Access-Token": access_token
                }
                payload = {
                    "advertiser_id": int(advertiser_id),
                    "start_date": start_date,
                    "end_date": end_date
                }
                if need_hourly_data:
                    payload["need_hourly_data"] = True

                response = requests.post(url, json=payload, headers=headers, timeout=30)
                result = response.json()

                if result.get('success') and result.get('code') == 0:
                    data = result.get('data', {})
                    # hourly_data在顶层，不在data里
                    hourly_data = result.get('hourly_data', [])
                    if need_hourly_data and hourly_data:
                        return {
                            'data_list': hourly_data,
                            'aggregation_data': data,
                            'total_count': len(hourly_data)
                        }
                    return {
                        'data_list': [data] if data else [],
                        'aggregation_data': data,
                        'total_count': 1
                    }

                if self._is_token_error(result):
                    if self._retry_token(attempt, max_retries, advertiser_id):
                        continue
                    return None

                print(f"请求失败: {result.get('msg', '未知错误')}")
                return None

            except Exception as e:
                if not self._handle_exception(e, attempt, max_retries):
                    return None

        return None

    def _fetch_with_pagination(self, url, endpoint, advertiser_id,
                                start_date, end_date, time_unit,
                                split_columns, filters,
                                marketing_target, bidding_strategy,
                                optimize_target, placement,
                                promotion_target, delivery_mode,
                                sort_column, sort, page_size,
                                data_caliber, is_realtime, max_retries):
        """分页获取数据"""
        all_data = []
        aggregation_data = None
        total_data = None
        page_num = 1

        while True:
            for attempt in range(max_retries):
                try:
                    access_token = self.token_manager.get_access_token_for_advertiser(advertiser_id)
                    headers = {
                        "content-type": "application/json",
                        "Access-Token": access_token
                    }

                    payload = {
                        "advertiser_id": int(advertiser_id),
                        "start_date": start_date,
                        "end_date": end_date,
                        "page_num": page_num,
                        "page_size": page_size
                    }

                    # 离线接口参数
                    if not is_realtime:
                        if time_unit:
                            payload["time_unit"] = time_unit
                        if data_caliber is not None:
                            payload["data_caliber"] = data_caliber
                        if sort_column:
                            payload["sort_column"] = sort_column
                            payload["sort"] = sort

                        # split_columns (仅account/creative)
                        if split_columns and endpoint in SPLIT_SUPPORTED:
                            payload["split_columns"] = split_columns
                            # 添加空数组过滤参数
                            payload.setdefault("marketing_target",
                                               marketing_target or [])
                            payload.setdefault("bidding_strategy",
                                               bidding_strategy or [])
                            payload.setdefault("optimize_target",
                                               optimize_target or [])
                            payload.setdefault("placement",
                                               placement or [])
                            payload.setdefault("promotion_target",
                                               promotion_target or [])
                        else:
                            # 非split场景也支持过滤
                            if marketing_target:
                                payload["marketing_target"] = marketing_target
                            if bidding_strategy:
                                payload["bidding_strategy"] = bidding_strategy
                            if optimize_target:
                                payload["optimize_target"] = optimize_target
                            if placement:
                                payload["placement"] = placement
                            if promotion_target:
                                payload["promotion_target"] = promotion_target

                        if delivery_mode:
                            payload["delivery_mode"] = delivery_mode

                        # filters (仅note/creative)
                        if filters and endpoint in FILTER_SUPPORTED:
                            payload["filters"] = filters

                    response = requests.post(url, json=payload,
                                             headers=headers, timeout=30)
                    result = response.json()

                    if result.get('success') and result.get('code') == 0:
                        # 离线接口响应结构
                        if not is_realtime:
                            resp_data = result.get('data', {})
                            data_list = resp_data.get('data_list', [])
                            total_count = resp_data.get('total_count', 0)

                            if page_num == 1:
                                aggregation_data = resp_data.get(
                                    'aggregation_data')

                            all_data.extend(data_list)

                            if len(all_data) >= total_count or not data_list:
                                return {
                                    'data_list': all_data,
                                    'aggregation_data': aggregation_data,
                                    'total_count': total_count
                                }
                        else:
                            # 实时接口响应结构（关键词/创意）
                            # 实时关键词: keyword_dtos / 实时创意: creativity_dtos
                            data_list = (result.get('keyword_dtos') or
                                         result.get('creativity_dtos') or [])

                            if page_num == 1:
                                total_data = result.get('total_data')

                            page_info = result.get('page', {})
                            total_count = page_info.get('total_count', 0)

                            all_data.extend(data_list)

                            if len(all_data) >= total_count or not data_list:
                                return {
                                    'data_list': all_data,
                                    'total_data': total_data,
                                    'total_count': total_count
                                }

                        page_num += 1
                        break  # 成功，进入下一页

                    if self._is_token_error(result):
                        if self._retry_token(attempt, max_retries, advertiser_id):
                            continue
                        return None

                    print(f"请求失败: {result.get('msg', '未知错误')}")
                    return None

                except Exception as e:
                    if not self._handle_exception(e, attempt, max_retries):
                        return None
            else:
                # for循环正常结束（所有重试都失败）
                print("达到最大重试次数")
                return None

        # ⑩ Fix: 移除死代码（while循环内部已覆盖所有退出路径，此行永远不可达）

    def _is_token_error(self, result):
        """判断是否为token过期错误"""
        msg = result.get('msg', '').lower()
        code = result.get('code')
        return 'token' in msg or code in [401, 403, 50002]

    def _retry_token(self, attempt, max_retries, advertiser_id=None):
        """尝试刷新token"""
        print(f"Token可能已过期，尝试刷新... (尝试 {attempt + 1}/{max_retries})")
        if advertiser_id is not None:
            return self.token_manager.refresh_for_advertiser(advertiser_id)
        return self.token_manager.refresh_access_token()

    def _handle_exception(self, e, attempt, max_retries):
        """处理请求异常，返回是否可以继续"""
        print(f"请求异常: {str(e)}")
        if attempt < max_retries - 1:
            print(f"重试... (尝试 {attempt + 2}/{max_retries})")
            time.sleep(1)
            return True
        return False
