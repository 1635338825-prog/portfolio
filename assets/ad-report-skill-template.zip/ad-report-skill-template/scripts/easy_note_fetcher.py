"""
简单投笔记专用接口拉取
endpoint: /api/open/jg/data/report/offline/easy/promotion/note
"""
import requests
import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from token_manager import TokenManager

BASE_URL = "https://adapi.xiaohongshu.com"
EASY_NOTE_PATH = "/api/open/jg/data/report/offline/easy/promotion/note"


def fetch_easy_note(advertiser_id, start_date, end_date,
                    time_unit="SUMMARY", page_size=500):
    """拉取简单投笔记数据"""
    tm = TokenManager()
    access_token = tm.get_access_token_for_advertiser(advertiser_id)
    headers = {
        "content-type": "application/json",
        "Access-Token": access_token
    }

    all_data = []
    aggregation_data = None
    page_num = 1

    while True:
        payload = {
            "advertiser_id": int(advertiser_id),
            "start_date": start_date,
            "end_date": end_date,
            "time_unit": time_unit,
            "page_num": page_num,
            "page_size": page_size
        }

        resp = requests.post(
            f"{BASE_URL}{EASY_NOTE_PATH}",
            json=payload, headers=headers, timeout=30
        )
        result = resp.json()

        if not (result.get('success') and result.get('code') == 0):
            print(f"请求失败: {result.get('msg')}")
            return None

        data = result.get('data', {})
        data_list = data.get('data_list', [])
        total_count = data.get('total_count', 0)

        if page_num == 1:
            aggregation_data = data.get('aggregation_data', {})

        all_data.extend(data_list)

        if len(all_data) >= total_count or not data_list:
            break
        page_num += 1

    return {
        'data_list': all_data,
        'aggregation_data': aggregation_data,
        'total_count': total_count
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--advertiser-id", type=int, default=8002419)
    parser.add_argument("--start", default="2026-06-01")
    parser.add_argument("--end", default="2026-06-08")
    args = parser.parse_args()

    result = fetch_easy_note(args.advertiser_id, args.start, args.end)
    if result:
        print(f"总条数: {result['total_count']}")
        print(f"汇总数据:")
        agg = result['aggregation_data']
        for k in ['fee', 'impression', 'click', 'ctr', 'acp', 'cpm',
                  'message_consult', 'initiative_message', 'msg_leads_num']:
            print(f"  {k}: {agg.get(k)}")
        print(f"\n明细数据 ({len(result['data_list'])} 条):")
        for row in result['data_list']:
            print(f"  [{row.get('note_id')}] {row.get('note_title', '')[:20]} "
                  f"消耗:{row.get('fee')} 开口:{row.get('initiative_message')} 留资:{row.get('msg_leads_num')}")
