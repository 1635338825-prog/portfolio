"""
报告引擎 - 读取config配置，调用data_fetcher获取数据，生成Excel报告

用法:
    python report_engine.py --config configs/meilai-weekly.json \
                            --start 2026-03-03 --end 2026-03-09 \
                            [--accounts 12345,67890] \
                            [--token YOUR_ACCESS_TOKEN] \
                            [--token-config path/to/token_config.json]
"""
import argparse
import json
import sys
import os
from pathlib import Path
from datetime import datetime, timedelta

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill

# 添加scripts目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from data_fetcher import DataFetcher
from token_manager import TokenManager


# ============================================================
# 枚举值映射
# ============================================================

DELIVERY_MODE_MAP = {0: "手动投放", "0": "手动投放", 1: "自动投放", "1": "自动投放"}

PLACEMENT_MAP = {
    1: "信息流", "1": "信息流", 2: "搜索", "2": "搜索",
    4: "全站智投", "4": "全站智投", 7: "视频流", "7": "视频流"
}

OPTIMIZE_TARGET_MAP = {
    0: "点击量", 1: "互动量", 3: "表单提交量", 4: "商品下单量",
    5: "私信咨询量", 6: "观看量", 11: "商品访客量", 12: "落地页访问量",
    13: "私信开口量", 14: "直播间有效观看量", 15: "消费意向量",
    16: "种草值", 17: "商品7日下单ROI", 18: "站外转化量",
    19: "行业商品访问", 20: "TI人群规模", 21: "行业商品成单",
    22: "表单提交量-有效表单", 23: "预告笔记点击量",
    24: "直播间支付订单量", 25: "直播间支付ROI",
    26: "APP打开", 27: "APP进店", 28: "APP互动", 29: "APP支付",
    30: "种草人群规模", 31: "深度种草人群规模",
    32: "添加企微量", 33: "成功添加企微量", 34: "企微开口量",
    35: "APP打开（唤起）", 36: "APP进店（唤起）",
    37: "APP互动（唤起）", 38: "APP成交-订单数（唤起）",
    41: "商品1日下单ROI", 42: "直播预约量", 43: "APP打开按钮点击量",
    50: "私信留资量", 60: "APP下载按钮点击量",
    61: "APP激活", 62: "APP注册", 63: "APP关键行为", 64: "APP付费",
}
# 补充字符串key
OPTIMIZE_TARGET_MAP.update({str(k): v for k, v in list(OPTIMIZE_TARGET_MAP.items()) if isinstance(k, int)})

# ④ Fix: ratio字段不应跨账户累加，仅累加型字段才能直接相加
# 这些字段在多账户合并时需通过calculated_metrics公式重算
RATIO_FIELDS = {
    'acp', 'cpm', 'ctr', 'cpi',
    'message_consult_cpl', 'initiative_message_cpl', 'msg_leads_cost',
    'leads_cpl', 'valid_leads_cpl', 'leads_cvr', 'click_order_cvr',
    'goods_visit_price', 'seller_visit_price', 'add_cart_price', 'goods_order_price',
    'live_average_order_cost', 'purchase_order_price_7d', 'purchase_order_roi_7d',
    'clk_live_entry_pv_cost', 'clk_live_5s_entry_uv_cost', 'clk_live_avg_view_time',
    'invoke_app_open_cost', 'invoke_app_enter_store_cost', 'invoke_app_engagement_cost',
    'invoke_app_payment_cost', 'invoke_app_payment_roi', 'invoke_app_payment_unit_price',
    'app_activate_cost', 'app_activate_ctr', 'app_register_cost', 'app_register_ctr',
    'first_app_pay_cost', 'first_app_pay_ctr', 'app_key_action_cost', 'app_key_action_ctr',
    'app_pay_cost_7d', 'app_pay_roi', 'add_wechat_cost', 'add_wechat_suc_cost',
    'wechat_talk_cost', 'shop_poi_page_visit_price', 'i_user_price', 'ti_user_price',
    'jd_active_user_num_cvr_new', 'jd_active_user_num_cpl',
    'external_goods_visit_price_7', 'external_goods_visit_rate_7',
    'external_goods_order_price_7', 'external_goods_order_rate_7', 'external_roi_7',
    'external_goods_order_price_15', 'external_goods_order_rate_15', 'external_roi_15',
    'external_goods_order_price_30', 'external_goods_order_rate_30', 'external_roi_30',
    'search_cmt_click_cvr', 'fst_message_reply_in_45s_rate',
    'message_reply_in_3min_rate', 'message_reply_in_1min_rate', 'message_reply_in_30s_rate',
    'action_button_ctr', 'app_download_button_click_ctr', 'app_download_button_click_cost',
    'search_invoke_button_click_cost',
    'word_avg_location', 'word_impression_rate_first', 'word_impression_rate_third',
    'word_click_rate_first', 'word_click_rate_third',
    'word_impression_rate_all', 'word_click_rate_all',
    'roi', 'clk_live_room_roi',
    'app_activate_amount_1d_roi', 'app_activate_amount_3d_roi', 'app_activate_amount_7d_roi',
    'purchase_order_roi_7d', 'external_goods_order_rate_7', 'external_goods_order_rate_15',
    'external_goods_order_rate_30', 'message_fst_reply_time_avg',
}

DIMENSION_LABEL_MAPS = {
    "deliveryMode": ("delivery_mode", "投放模式", DELIVERY_MODE_MAP),
    "placement": ("placement", "广告类型", PLACEMENT_MAP),
    "optimizeTarget": ("optimize_target", "优化目标", OPTIMIZE_TARGET_MAP),
    "province": ("province", "地域", None),
    "city": ("city", "城市", None),
    "gender": ("gender", "性别", None),
    "age": ("age", "年龄", None),
    "device": ("device", "平台", None),
    "marketingTarget": ("marketing_target", "营销诉求", None),
    "biddingStrategy": ("bidding_strategy", "出价方式", None),
}


# ============================================================
# 工具函数
# ============================================================

def safe_float(value, default=0.0):
    """安全转换为float"""
    if value is None or value == '' or value == '-':
        return default
    try:
        if isinstance(value, str) and '%' in value:
            return float(value.replace('%', ''))
        return float(value)
    except (ValueError, TypeError):
        return default


def safe_int(value, default=0):
    """安全转换为int"""
    if value is None or value == '' or value == '-':
        return default
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return default


def parse_percentage(value):
    """解析百分比字符串 '1.72%' -> 1.72"""
    if isinstance(value, str) and '%' in value:
        return float(value.replace('%', ''))
    return float(value) if value else 0


def _eval_formula(formula, raw_data):
    """安全执行表达式公式，用raw_data中的字段值代入计算
    
    支持: 四则运算、括号、字段名引用
    示例: "fee / click", "(click + interaction) / impression * 100"
    """
    import re
    # 提取公式中的字段名（非数字、非运算符的标识符）
    tokens = re.findall(r'[a-zA-Z_][a-zA-Z0-9_]*', formula)
    # 构建安全的变量字典
    variables = {}
    for token in tokens:
        variables[token] = safe_float(raw_data.get(token, 0))
    try:
        # 只允许数学运算，禁止内置函数调用
        result = eval(formula, {"__builtins__": {}}, variables)
        return float(result) if result is not None and not (
            isinstance(result, float) and (result != result)) else 0  # NaN check
    except (ZeroDivisionError, TypeError, ValueError):
        return 0


def calculate_previous_period(start_date, end_date):
    """根据当前周期计算上一个同等长度的周期"""
    start_dt = datetime.strptime(start_date, "%Y-%m-%d")
    end_dt = datetime.strptime(end_date, "%Y-%m-%d")
    period_days = (end_dt - start_dt).days + 1
    prev_end_dt = start_dt - timedelta(days=1)
    prev_start_dt = prev_end_dt - timedelta(days=period_days - 1)
    return prev_start_dt.strftime("%Y-%m-%d"), prev_end_dt.strftime("%Y-%m-%d")


# ============================================================
# 核心引擎
# ============================================================

class ReportEngine:
    def __init__(self, config, fetcher, start_date, end_date, accounts=None):
        """
        Args:
            config: dict, 报告配置
            fetcher: DataFetcher实例
            start_date: 开始日期
            end_date: 结束日期
            accounts: 账户ID列表 (覆盖config中的accounts)
        """
        self.config = config
        self.fetcher = fetcher
        self.start_date = start_date
        self.end_date = end_date
        self.accounts = accounts or config.get("accounts", [])
        self.report_name = config.get("report_name", "报告")
        self.period_days = (
            datetime.strptime(end_date, "%Y-%m-%d") -
            datetime.strptime(start_date, "%Y-%m-%d")
        ).days + 1
        self._today = datetime.now().strftime("%Y-%m-%d")

    def _get_accounts(self, cfg):
        """获取section的账户列表，支持section级别覆盖"""
        return cfg.get("accounts") or self.accounts

    def _resolve_endpoint(self, endpoint, query_date):
        """根据查询日期自动选择实时/离线接口
        日期是今天 → realtime，历史日期 → offline
        """
        if query_date == self._today:
            return f"{endpoint}_realtime"
        return endpoint

    def run(self):
        """执行报告生成，返回 {sheet_name: [(section_name, DataFrame), ...]}"""
        sheets = {}
        sections = self.config.get("sections", [])

        for section_cfg in sections:
            section_type = section_cfg.get("type", "standard")
            name = section_cfg.get("name", "未命名")
            sheet_name = section_cfg.get("sheet_name", "报告")

            print(f"正在处理: {name} ...")

            if section_type == "standard":
                df = self._process_standard_section(section_cfg)
            elif section_type == "comparison":
                df = self._process_comparison_section(section_cfg)
            elif section_type == "daily_average":
                df = self._process_daily_average_section(section_cfg)
            else:
                print(f"  未知section类型: {section_type}, 跳过")
                continue

            if df is not None and not df.empty:
                sheets.setdefault(sheet_name, []).append((name, df))
                print(f"  完成: {len(df)} 行")
            else:
                print(f"  无数据")

        return sheets

    # ----------------------------------------------------------
    # Standard Section
    # ----------------------------------------------------------

    def _process_standard_section(self, cfg):
        """处理标准数据section"""
        endpoint = cfg.get("endpoint", "account")
        time_unit = cfg.get("time_unit", "DAY")
        merge_accounts = cfg.get("merge_accounts", False)
        split_columns = cfg.get("split_columns")
        metrics = cfg.get("metrics", [])
        calculated_metrics = cfg.get("calculated_metrics", [])
        summary_row = cfg.get("summary_row", True)
        sort_by = cfg.get("sort_by")
        sort_order = cfg.get("sort_order", "desc")
        filter_zero = cfg.get("filter_zero", True)
        hour_start = cfg.get("hour_start")
        hour_end = cfg.get("hour_end")
        # 投放模式: "normal"(普通投放) | "easy"(简单投) | "mixed"(混合)
        delivery_mode = cfg.get("delivery_mode", "normal")
        # ⑨ Fix: api_type已无效（引擎按日期自动选接口），此行仅保留兼容性，不使用
        # api_type = cfg.get("api_type", "offline")

        # 获取所有账户数据
        fetch_endpoint = self._resolve_endpoint(endpoint, self.start_date)
        accounts = self._get_accounts(cfg)
        all_accounts_data = {}
        
        for adv_id in accounts:
            # 根据投放模式获取数据
            if delivery_mode == "easy":
                # 仅简单投
                data = self.fetcher.fetch_easy_note(
                    adv_id, self.start_date, self.end_date,
                    time_unit=time_unit, split_columns=split_columns
                )
            elif delivery_mode == "mixed":
                # 混合模式：同时获取普通投放和简单投数据，然后合并
                normal_data = self.fetcher.fetch(
                    fetch_endpoint, adv_id, self.start_date, self.end_date,
                    time_unit=time_unit, split_columns=split_columns
                )
                easy_data = self.fetcher.fetch_easy_note(
                    adv_id, self.start_date, self.end_date,
                    time_unit=time_unit, split_columns=split_columns
                )
                # 合并数据
                data = self._merge_delivery_data(normal_data, easy_data, time_unit, split_columns)
            else:
                # 普通投放（默认）
                data = self.fetcher.fetch(
                    fetch_endpoint, adv_id, self.start_date, self.end_date,
                    time_unit=time_unit, split_columns=split_columns
                )
            
            if data and hour_start is not None and hour_end is not None:
                # 筛选特定小时段（左闭右开：hour_start <= hour < hour_end）
                filtered = [item for item in data.get('data_list', [])
                           if self._extract_hour(str(item.get('time', ''))) is not None
                           and hour_start <= self._extract_hour(str(item.get('time', ''))) < hour_end]
                data['data_list'] = filtered
            if data:
                all_accounts_data[adv_id] = data

        if not all_accounts_data:
            return None

        # ③ Fix: 自动判断是否需要按词文本聚合（keyword/search_word API返回词×单元粒度）
        # 不依赖config参数，引擎自动处理，对调用方透明
        if endpoint == 'keyword':
            group_by = "关键词"
        elif endpoint == 'search_word':
            group_by = "搜索词"
        else:
            group_by = None

        # ① Fix: 确定总计行的第一列标签（不同endpoint第一列不同）
        if split_columns:
            label_col = None  # _build_summary_row内部处理
        elif endpoint == 'keyword':
            label_col = "关键词"
        elif endpoint == 'search_word':
            label_col = "搜索词"
        elif endpoint in ('note', 'creative'):
            # note/creative第一列来自metrics，取第一个metric的header
            fm = metrics[0] if metrics else None
            label_col = (fm if isinstance(fm, str) else fm.get("header", "")) if fm else ""
        else:
            label_col = "时间"  # account + DAY/HOUR/SUMMARY

        if merge_accounts:
            df = self._merge_and_build(all_accounts_data, cfg)
        else:
            # 不合并：每个账户独立输出
            dfs = []
            for adv_id, data in all_accounts_data.items():
                if group_by:
                    # keyword/search_word: 先不算calculated_metrics，聚合后再算
                    sub_df = self._build_dataframe(data.get('data_list', []),
                                                    metrics, [],
                                                    split_columns)
                    if not sub_df.empty:
                        sub_df = self._group_and_recalculate(
                            sub_df, group_by, metrics, calculated_metrics)
                        if summary_row:
                            agg = data.get('aggregation_data', {})
                            if agg:
                                summary = self._build_summary_row(
                                    agg, metrics, calculated_metrics,
                                    split_columns, label_col=label_col)
                                sub_df = pd.concat(
                                    [sub_df, pd.DataFrame([summary])],
                                    ignore_index=True)
                        dfs.append(sub_df)
                else:
                    sub_df = self._build_dataframe(data.get('data_list', []),
                                                    metrics, calculated_metrics,
                                                    split_columns)
                    if not sub_df.empty:
                        if summary_row:
                            agg = data.get('aggregation_data', {})
                            if agg:
                                summary = self._build_summary_row(
                                    agg, metrics, calculated_metrics,
                                    split_columns, label_col=label_col)
                                sub_df = pd.concat(
                                    [sub_df, pd.DataFrame([summary])],
                                    ignore_index=True)
                        dfs.append(sub_df)
            df = pd.concat(dfs, ignore_index=True) if dfs else pd.DataFrame()

        if df.empty:
            return df

        # 添加对比指标列（如昨日同时段消耗、环比）
        df = self._apply_compare_metrics(df, cfg)

        # 仅输出汇总行（summary_only模式）
        summary_only = cfg.get("summary_only", False)
        if summary_only and '时间' in df.columns:
            mask_total = df['时间'].astype(str) == '总计'
            if mask_total.any():
                df = df[mask_total].reset_index(drop=True)

        # 过滤零值行
        if filter_zero and '消费' in df.columns:
            # 保留总计行
            mask_total = df.iloc[:, 0].astype(str) == '总计'
            mask_nonzero = df['消费'].apply(lambda x: safe_float(x)) > 0
            df = df[mask_total | mask_nonzero]

        # 排序
        # C Fix: sort_by 可能是 API 字段名（如 "fee"），列名是 header（如 "消费"）
        # 先尝试直接匹配，再从 metrics 中找对应 header
        sort_col = sort_by
        if sort_by and sort_by not in df.columns:
            for m in metrics:
                if isinstance(m, dict) and m.get("field") == sort_by:
                    candidate = m.get("header", "")
                    if candidate in df.columns:
                        sort_col = candidate
                        break

        if sort_col and sort_col in df.columns:
            # 分离总计行
            mask_total = df.iloc[:, 0].astype(str) == '总计'
            data_rows = df[~mask_total]
            total_rows = df[mask_total]
            ascending = sort_order == "asc"
            data_rows = data_rows.sort_values(
                by=sort_col, ascending=ascending,
                key=lambda s: s.apply(safe_float))
            df = pd.concat([data_rows, total_rows], ignore_index=True)
        elif '时间' in df.columns:
            mask_total = df['时间'].astype(str) == '总计'
            data_rows = df[~mask_total].sort_values(by='时间')
            total_rows = df[mask_total]
            df = pd.concat([data_rows, total_rows], ignore_index=True)

        return df

    # ----------------------------------------------------------
    # 简单投混合模式数据合并
    # ----------------------------------------------------------

    # 累加型字段：合并时直接相加
    CUMULATIVE_FIELDS = {
        'fee', 'impression', 'click', 'interaction',
        'message_consult', 'initiative_message', 'msg_leads_num',
        'valid_leads', 'leads_num', 'click_order',
        'goods_visit', 'seller_visit', 'add_cart', 'goods_order',
        'live_average_order', 'purchase_order_7d',
        'clk_live_entry_pv', 'clk_live_5s_entry_uv',
        'invoke_app_open', 'invoke_app_enter_store',
        'invoke_app_engagement', 'invoke_app_payment',
        'app_activate', 'app_register', 'first_app_pay',
        'app_pay_7d', 'add_wechat', 'add_wechat_suc',
        'wechat_talk', 'shop_poi_page_visit',
        'i_user', 'ti_user', 'jd_active_user_num',
        'external_goods_visit_7', 'external_goods_order_7',
        'external_goods_visit_15', 'external_goods_order_15',
        'external_goods_visit_30', 'external_goods_order_30',
        'search_cmt_click', 'fst_message_reply_in_45s',
        'message_reply_in_3min', 'message_reply_in_1min', 'message_reply_in_30s',
        'action_button_click', 'app_download_button_click',
        'search_invoke_button_click',
        'roi_amount', 'clk_live_room_roi_amount',
        'app_activate_amount_1d', 'app_activate_amount_3d', 'app_activate_amount_7d',
        'purchase_order_amount_7d',
    }

    def _merge_delivery_data(self, normal_data, easy_data, time_unit, split_columns):
        """合并普通投放和简单投数据

        核心约束：ratio字段不能直接用API返回值，合并后必须重新计算。
        引擎只负责累加型字段相加，ratio由calculated_metrics公式重算。

        Args:
            normal_data: 普通投放API返回的dict (含data_list)
            easy_data: 简单投API返回的dict (含data_list)
            time_unit: 时间粒度
            split_columns: 细分条件

        Returns:
            dict: 合并后的数据 {data_list: [...], total_count: int}
        """
        normal_rows = (normal_data or {}).get('data_list', [])
        easy_rows = (easy_data or {}).get('data_list', [])

        if not normal_rows and not easy_rows:
            return None

        # 简单投数据预处理：city→province映射
        if split_columns and 'province' in split_columns:
            easy_rows = self._map_city_to_province(easy_rows)

        # 确定分组键
        if split_columns:
            group_key = self._get_dimension_field(split_columns[0])
        elif time_unit in ('DAY', 'HOUR'):
            group_key = 'time'
        else:
            group_key = None

        if group_key:
            # 按分组键聚合
            merged = {}
            for row in normal_rows + easy_rows:
                key = row.get(group_key, '')
                if key not in merged:
                    merged[key] = dict(row)  # 复制第一行作为基础
                else:
                    # 累加型字段相加
                    for field in self.CUMULATIVE_FIELDS:
                        merged[key][field] = (
                            safe_float(merged[key].get(field, 0)) +
                            safe_float(row.get(field, 0))
                        )
            merged_list = list(merged.values())
        else:
            # SUMMARY模式：全部累加
            merged_row = {}
            for row in normal_rows + easy_rows:
                if not merged_row:
                    merged_row = dict(row)
                else:
                    for field in self.CUMULATIVE_FIELDS:
                        merged_row[field] = (
                            safe_float(merged_row.get(field, 0)) +
                            safe_float(row.get(field, 0))
                        )
            merged_list = [merged_row] if merged_row else []

        # 清除所有ratio字段，让calculated_metrics重算
        for row in merged_list:
            for field in list(row.keys()):
                if field in RATIO_FIELDS:
                    row[field] = 0

        return {
            'data_list': merged_list,
            'total_count': len(merged_list),
            # 混合模式无aggregation_data，总计行由引擎手动累加
        }

    def _map_city_to_province(self, rows):
        """将简单投的city字段映射到province

        简单投不支持province维度，只支持city。
        当config要求province时，需要将city映射到province后合并。
        """
        from city_province_map import CITY_TO_PROVINCE
        mapped = {}
        for row in rows:
            city = row.get('city', '')
            province = CITY_TO_PROVINCE.get(city, city)
            row['province'] = province
            key = province
            if key not in mapped:
                mapped[key] = dict(row)
            else:
                for field in self.CUMULATIVE_FIELDS:
                    mapped[key][field] = (
                        safe_float(mapped[key].get(field, 0)) +
                        safe_float(row.get(field, 0))
                    )
        return list(mapped.values())

    def _merge_and_build(self, all_accounts_data, cfg):
        """合并多账户数据并构建DataFrame"""
        metrics = cfg.get("metrics", [])
        calculated_metrics = cfg.get("calculated_metrics", [])
        split_columns = cfg.get("split_columns")
        summary_row = cfg.get("summary_row", True)
        time_unit = cfg.get("time_unit", "DAY")

        # 确定分组键
        if split_columns:
            group_key = self._get_dimension_field(split_columns[0])
        elif time_unit in ("DAY", "HOUR"):
            group_key = "time"
        else:
            group_key = None

        # 收集所有原始数据行
        all_rows = []
        for data in all_accounts_data.values():
            all_rows.extend(data.get('data_list', []))

        if not all_rows:
            return pd.DataFrame()

        if group_key:
            # 按group_key分组，累加原始值
            grouped = {}
            for row in all_rows:
                key = row.get(group_key, '')
                if key not in grouped:
                    grouped[key] = {}
                for field in self._get_raw_fields(metrics):
                    grouped[key][field] = (
                        grouped[key].get(field, 0) +
                        safe_float(row.get(field, 0))
                    )

            # 构建结果
            result_rows = []
            for key, raw_data in grouped.items():
                result_row = self._build_merged_row(
                    key, raw_data, metrics, calculated_metrics,
                    split_columns)
                result_rows.append(result_row)

            df = pd.DataFrame(result_rows)
        else:
            # SUMMARY模式，直接累加所有数据
            merged = {}
            for row in all_rows:
                for field in self._get_raw_fields(metrics):
                    merged[field] = (
                        merged.get(field, 0) +
                        safe_float(row.get(field, 0)))

            result_row = self._build_merged_row(
                None, merged, metrics, calculated_metrics, split_columns)
            df = pd.DataFrame([result_row])

        # 添加汇总总计行：优先使用API的aggregation_data（含ratio字段均已算好）
        if summary_row and group_key:
            # 单账户：直接取aggregation_data
            # 多账户：将各账户aggregation_data的累加型字段求和（ratio字段此时需用calculated_metrics）
            merged_agg = {}
            for data in all_accounts_data.values():
                agg = data.get('aggregation_data') or {}
                for k, v in agg.items():
                    merged_agg[k] = merged_agg.get(k, 0) + safe_float(v)

            if merged_agg:
                total_row = self._build_merged_row(
                    "总计", merged_agg, metrics, calculated_metrics, split_columns)
            else:
                # fallback：aggregation_data为空时手动累加（仅累加型字段可信）
                total_raw = {}
                for row in all_rows:
                    for field in self._get_raw_fields(metrics):
                        total_raw[field] = (
                            total_raw.get(field, 0) +
                            safe_float(row.get(field, 0)))
                total_row = self._build_merged_row(
                    "总计", total_raw, metrics, calculated_metrics, split_columns)

            df = pd.concat(
                [df, pd.DataFrame([total_row])], ignore_index=True)

        return df

    def _build_merged_row(self, key_value, raw_data, metrics,
                           calculated_metrics, split_columns):
        """根据累加后的原始数据构建一行"""
        row = {}

        # 第一列：维度或时间
        if split_columns:
            dim_name = self._get_dimension_label(split_columns[0])
            value_map = self._get_dimension_value_map(split_columns[0])
            if value_map and key_value is not None and key_value != "总计":
                row[dim_name] = value_map.get(key_value,
                                               value_map.get(str(key_value),
                                                             str(key_value)))
            else:
                row[dim_name] = key_value if key_value else "-"
        elif key_value is not None:
            row["时间"] = key_value

        # 添加各指标（全部直接取API返回值）
        for m in metrics:
            if isinstance(m, str):
                header, field = m, m
            else:
                header = m.get("header", m.get("field", ""))
                field = m.get("field", "")
            row[header] = raw_data.get(field, 0)

        # 添加自定义计算指标（支持formula表达式）
        for cm in calculated_metrics:
            header = cm.get("header", cm.get("name", ""))
            fmt = cm.get("format", "number")
            formula = cm.get("formula")

            if formula:
                # 表达式引擎：用raw_data中的字段值代入公式计算
                val = _eval_formula(formula, raw_data)
            else:
                # 兼容旧格式：numerator / denominator * multiplier
                num_field = cm.get("numerator", "")
                den_field = cm.get("denominator", "")
                multiplier = cm.get("multiplier", 1)
                num = safe_float(raw_data.get(num_field, 0))
                den = safe_float(raw_data.get(den_field, 0))
                val = (num / den * multiplier) if den > 0 else 0

            if fmt == "percentage":
                row[header] = f"{round(val * 100, 2)}%" if val else "0.00%"
            else:
                row[header] = round(val, 2) if val else 0

        return row

    def _build_dataframe(self, data_list, metrics, calculated_metrics,
                          split_columns):
        """从API data_list构建DataFrame（不合并场景）"""
        rows = []
        for item in data_list:
            row = {}
            # 第一列
            if split_columns:
                dim_field = self._get_dimension_field(split_columns[0])
                dim_label = self._get_dimension_label(split_columns[0])
                value_map = self._get_dimension_value_map(split_columns[0])
                raw_val = item.get(dim_field, '')
                if value_map:
                    row[dim_label] = value_map.get(raw_val,
                                                    value_map.get(str(raw_val),
                                                                  str(raw_val)))
                else:
                    row[dim_label] = raw_val if raw_val else "未知"
            else:
                # ② Fix: 用elif确保互斥，避免keyword/note同时出现"时间"和实体列
                # note_id/creativity_id 通过metrics配置输出，不做特殊处理
                # search_word 同 keyword 逻辑
                if 'keyword' in item:
                    row["关键词"] = item.get('keyword', '')
                elif 'search_word' in item:
                    row["搜索词"] = item.get('search_word', '')
                elif 'note_id' in item or 'creativity_id' in item:
                    pass  # 由metrics配置控制输出，不添加额外列
                elif 'time' in item:
                    row["时间"] = item['time']

            # 指标（直接取API返回值）
            for m in metrics:
                if isinstance(m, str):
                    row[m] = item.get(m, '')
                else:
                    header = m.get("header", m.get("field", ""))
                    field = m.get("field", "")
                    row[header] = item.get(field, '')

            # 自定义计算（支持formula表达式）
            for cm in calculated_metrics:
                header = cm.get("header", cm.get("name", ""))
                fmt = cm.get("format", "number")
                formula = cm.get("formula")

                if formula:
                    val = _eval_formula(formula, item)
                else:
                    num_field = cm.get("numerator", "")
                    den_field = cm.get("denominator", "")
                    multiplier = cm.get("multiplier", 1)
                    num = safe_float(item.get(num_field, 0))
                    den = safe_float(item.get(den_field, 0))
                    val = (num / den * multiplier) if den > 0 else 0

                if fmt == "percentage":
                    row[header] = f"{round(val * 100, 2)}%" if val else "0.00%"
                else:
                    row[header] = round(val, 2) if val else 0

            rows.append(row)

        return pd.DataFrame(rows)

    def _build_summary_row(self, agg_data, metrics, calculated_metrics,
                            split_columns, label_col=None):
        """从aggregation_data构建总计行
        
        Args:
            label_col: 总计行第一列的列名（由_process_standard_section传入）
                      split_columns场景由内部确定，其他场景必须传入
        """
        row = {}
        # ① Fix: 第一列不再硬编码为"时间"，由调用方传入label_col
        if split_columns:
            dim_label = self._get_dimension_label(split_columns[0])
            row[dim_label] = "总计"
        elif label_col:
            row[label_col] = "总计"
        else:
            row["时间"] = "总计"  # fallback

        # A Fix: 跳过与 label_col 同名的 metric，避免覆盖"总计"标签
        # 注意运算符优先级，必须用 if/elif/else 而非内联三元
        if split_columns:
            _label = self._get_dimension_label(split_columns[0])
        elif label_col:
            _label = label_col
        else:
            _label = "时间"

        for m in metrics:
            if isinstance(m, str):
                if m == _label:
                    continue
                row[m] = agg_data.get(m, '')
            else:
                header = m.get("header", m.get("field", ""))
                field = m.get("field", "")
                if header == _label:
                    continue
                row[header] = agg_data.get(field, '')

        for cm in calculated_metrics:
            header = cm.get("header", cm.get("name", ""))
            fmt = cm.get("format", "number")
            formula = cm.get("formula")

            if formula:
                val = _eval_formula(formula, agg_data)
            else:
                num_field = cm.get("numerator", "")
                den_field = cm.get("denominator", "")
                multiplier = cm.get("multiplier", 1)
                num = safe_float(agg_data.get(num_field, 0))
                den = safe_float(agg_data.get(den_field, 0))
                val = (num / den * multiplier) if den > 0 else 0

            if fmt == "percentage":
                row[header] = f"{round(val * 100, 2)}%" if val else "0.00%"
            else:
                row[header] = round(val, 2) if val else 0

        return row

    def _group_and_recalculate(self, df, group_col, metrics, calculated_metrics):
        """按文本列聚合去重，聚合后对calculated_metrics重新计算
        
        用于keyword/search_word endpoint：API返回词×单元粒度，需按词文本聚合。
        累加型字段直接sum，ratio型字段通过calculated_metrics公式重算。
        
        Args:
            df: 原始DataFrame（未聚合）
            group_col: 聚合列名，如"关键词"/"搜索词"
            metrics: section的metrics配置（用于构建header→field映射）
            calculated_metrics: section的calculated_metrics配置
        """
        if group_col not in df.columns:
            return df

        # 将非group列转为数值（无法转换的填0）
        for col in df.columns:
            if col != group_col:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

        # 按词文本分组求和（cumulative字段正确，ratio字段此处结果仅为中间值）
        grouped = df.groupby(group_col, as_index=False).sum()

        # 建立 header→field 映射，供formula中的字段名引用
        header_to_field = {}
        for m in metrics:
            if isinstance(m, str):
                header_to_field[m] = m
            else:
                h = m.get("header", m.get("field", ""))
                f = m.get("field", "")
                if h and f:
                    header_to_field[h] = f

        # 对每行重新计算calculated_metrics（基于已聚合的分子/分母）
        for cm in calculated_metrics:
            header = cm.get("header", cm.get("name", ""))
            fmt = cm.get("format", "number")
            formula = cm.get("formula")

            results = []
            for _, row in grouped.iterrows():
                # 用field名构建item供formula引用
                item = {f: safe_float(row.get(h, 0))
                        for h, f in header_to_field.items()
                        if h in row.index}

                if formula:
                    val = _eval_formula(formula, item)
                else:
                    num = safe_float(item.get(cm.get("numerator", ""), 0))
                    den = safe_float(item.get(cm.get("denominator", ""), 0))
                    val = (num / den * cm.get("multiplier", 1)) if den > 0 else 0

                if fmt == "percentage":
                    results.append(f"{round(val * 100, 2)}%" if val else "0.00%")
                else:
                    results.append(round(val, 2) if val else 0)

            grouped[header] = results

        return grouped

    # ----------------------------------------------------------
    # Comparison Section (环比)
    # ----------------------------------------------------------

    def _process_comparison_section(self, cfg):
        """处理环比对比section"""
        compare_period = cfg.get("compare_period", "previous_same_length")
        metrics = cfg.get("metrics", [])
        calculated_metrics = cfg.get("calculated_metrics", [])
        endpoint = cfg.get("endpoint", "account")
        api_type = cfg.get("api_type", "offline")
        hour_start = cfg.get("hour_start")
        hour_end = cfg.get("hour_end")

        # 计算对比周期
        if compare_period == "yesterday_same_hours":
            # 昨日同时段对比
            start_dt = datetime.strptime(self.start_date, "%Y-%m-%d")
            prev_start = (start_dt - timedelta(days=1)).strftime("%Y-%m-%d")
            prev_end = prev_start
        else:
            prev_start, prev_end = calculate_previous_period(
                self.start_date, self.end_date)

        # 获取本期和上期数据
        accounts = self._get_accounts(cfg)
        current_raw = self._fetch_and_merge_summary(
            endpoint, self.start_date, self.end_date,
            hour_start=hour_start, hour_end=hour_end, api_type=api_type,
            accounts=accounts)
        prev_raw = self._fetch_and_merge_summary(
            endpoint, prev_start, prev_end,
            hour_start=hour_start, hour_end=hour_end, api_type=api_type,
            accounts=accounts)

        if current_raw is None and prev_raw is None:
            return None

        current_raw = current_raw or {}
        prev_raw = prev_raw or {}

        # 构建标签
        if hour_start is not None and hour_end is not None:
            cur_label = f"{self.start_date} {hour_start}:00~{hour_end}:00"
            prev_label = f"{prev_start} {hour_start}:00~{hour_end}:00"
        else:
            cur_label = f"{self.start_date}~{self.end_date}"
            prev_label = f"{prev_start}~{prev_end}"

        # 构建本期行
        current_row = self._build_merged_row(
            cur_label, current_raw, metrics, calculated_metrics, None)

        # 构建上期行
        prev_row = self._build_merged_row(
            prev_label, prev_raw, metrics, calculated_metrics, None)

        # 计算环比行
        comparison_row = {"时间": "环比"}
        all_headers = [m.get("header", m) if isinstance(m, dict) else m
                       for m in metrics]
        all_headers += [cm.get("header", cm.get("name", ""))
                        for cm in calculated_metrics]
        for header in all_headers:
            cur_val = safe_float(current_row.get(header, 0))
            prev_val = safe_float(prev_row.get(header, 0))
            if prev_val != 0:
                change = ((cur_val - prev_val) / abs(prev_val)) * 100
                comparison_row[header] = f"{change:.2f}%"
            else:
                comparison_row[header] = "-"

        return pd.DataFrame([current_row, prev_row, comparison_row])

    def _fetch_and_merge_summary(self, endpoint, start_date, end_date,
                                  hour_start=None, hour_end=None,
                                  api_type=None, accounts=None):
        """获取所有账户的SUMMARY数据并合并
        
        如果指定hour_start/hour_end，则获取HOUR数据并筛选特定时段后聚合
        """
        accounts = accounts or self.accounts
        if hour_start is not None and hour_end is not None:
            return self._fetch_hour_range_summary(
                endpoint, start_date, end_date, hour_start, hour_end,
                api_type, accounts=accounts)
        
        merged = {}
        for adv_id in accounts:
            data = self.fetcher.fetch(
                endpoint, adv_id, start_date, end_date,
                time_unit="SUMMARY")
            if data:
                agg = data.get('aggregation_data') or {}
                # 如果是SUMMARY且只有data_list
                if not agg and data.get('data_list'):
                    for item in data['data_list']:
                        agg = item
                        break
                for key, val in agg.items():
                    # B Fix: 多账户时ratio字段不能累加（由calculated_metrics重算）
                    # 单账户时API的aggregation_data已正确，直接取值
                    if len(accounts) > 1 and key in RATIO_FIELDS:
                        continue
                    merged[key] = merged.get(key, 0) + safe_float(val)
        return merged if merged else None

    def _fetch_hour_range_summary(self, endpoint, start_date, end_date,
                                   hour_start, hour_end, api_type=None,
                                   accounts=None):
        """获取HOUR数据，筛选特定小时段，聚合后返回"""
        merged = {}
        accounts = accounts or self.accounts
        fetch_endpoint = self._resolve_endpoint(endpoint, start_date)
        for adv_id in accounts:
            data = self.fetcher.fetch(
                fetch_endpoint, adv_id, start_date, end_date,
                time_unit="HOUR")
            if data:
                for item in data.get('data_list', []):
                    # time字段可能是 "16" / "16:00" / "2026-03-13 16:00:00" 等格式
                    time_val = str(item.get('time', ''))
                    hour = self._extract_hour(time_val)
                    if hour is not None and hour_start <= hour < hour_end:
                        for key, val in item.items():
                            if key == 'time':
                                continue
                            merged[key] = merged.get(key, 0) + safe_float(val)
        return merged if merged else None

    @staticmethod
    def _extract_hour(time_str):
        """从时间字符串中提取小时数
        
        支持格式:
        - "16" (纯数字)
        - "16:00" 
        - "2026-03-12 16:00 - 16:59" (离线HOUR格式)
        - "2026-03-12 16:00:00"
        """
        import re
        time_str = str(time_str).strip()
        # 纯数字: "16"
        if time_str.isdigit():
            return int(time_str)
        # 匹配日期后的第一个 HH:MM
        m = re.search(r'(\d{1,2}):\d{2}', time_str)
        if m:
            return int(m.group(1))
        return None

    # ----------------------------------------------------------
    # Compare Metrics（对比指标列）
    # ----------------------------------------------------------

    def _apply_compare_metrics(self, df, cfg):
        """在DataFrame上添加对比指标列（如昨日同时段消耗、消耗环比）"""
        compare_metrics = cfg.get("compare_metrics", [])
        if not compare_metrics or df is None or df.empty:
            return df

        endpoint = cfg.get("endpoint", "account")
        hour_start = cfg.get("hour_start")
        hour_end = cfg.get("hour_end")

        # 计算对比周期
        compare_period = compare_metrics[0].get("compare_period",
                                                 "yesterday_same_hours")
        start_dt = datetime.strptime(self.start_date, "%Y-%m-%d")
        if compare_period == "yesterday_same_hours":
            prev_start = (start_dt - timedelta(days=1)).strftime("%Y-%m-%d")
            prev_end = prev_start
        else:
            prev_start, prev_end = calculate_previous_period(
                self.start_date, self.end_date)

        # 获取对比数据
        prev_hour_map = {}  # {hour: {field: value}}
        prev_total = {}

        accounts = self._get_accounts(cfg)
        if hour_start is not None and hour_end is not None:
            prev_endpoint = self._resolve_endpoint(endpoint, prev_start)
            for adv_id in accounts:
                data = self.fetcher.fetch(
                    prev_endpoint, adv_id, prev_start, prev_end,
                    time_unit="HOUR")
                if data:
                    for item in data.get('data_list', []):
                        hour = self._extract_hour(str(item.get('time', '')))
                        if hour is not None and hour_start <= hour < hour_end:
                            if hour not in prev_hour_map:
                                prev_hour_map[hour] = {}
                            for k, v in item.items():
                                if k == 'time':
                                    continue
                                prev_hour_map[hour][k] = (
                                    prev_hour_map[hour].get(k, 0) +
                                    safe_float(v))
            # 汇总
            for hdata in prev_hour_map.values():
                for k, v in hdata.items():
                    prev_total[k] = prev_total.get(k, 0) + v
        else:
            prev_total = (self._fetch_and_merge_summary(
                endpoint, prev_start, prev_end, accounts=accounts) or {})

        # field -> header 映射（用于环比时查找当前值）
        field_to_header = {}
        for m in cfg.get("metrics", []):
            if isinstance(m, str):
                field_to_header[m] = m
            else:
                field_to_header[m.get("field", "")] = m.get(
                    "header", m.get("field", ""))

        # 添加对比列
        for cm in compare_metrics:
            header = cm.get("header", "")
            field = cm.get("field", "")
            cm_type = cm.get("type", "value")  # value 或 ratio

            col_values = []
            for _, row in df.iterrows():
                time_val = str(row.get("时间", ""))
                if time_val == "总计":
                    prev = prev_total
                else:
                    hour = self._extract_hour(time_val)
                    prev = (prev_hour_map.get(hour, {})
                            if hour is not None else prev_total)

                prev_val = safe_float(prev.get(field, 0))

                if cm_type == "ratio":
                    cur_header = field_to_header.get(field, field)
                    cur_val = safe_float(row.get(cur_header, 0))
                    if prev_val != 0:
                        ratio = ((cur_val - prev_val) /
                                 abs(prev_val)) * 100
                        col_values.append(f"{ratio:.2f}%")
                    else:
                        col_values.append("-")
                else:
                    col_values.append(prev_val)

            df[header] = col_values

        return df

    # ----------------------------------------------------------
    # Daily Average Section
    # ----------------------------------------------------------

    def _process_daily_average_section(self, cfg):
        """处理日均计算section"""
        metrics = cfg.get("metrics", [])
        calculated_metrics = cfg.get("calculated_metrics", [])
        endpoint = cfg.get("endpoint", "account")

        # 获取SUMMARY数据
        accounts = self._get_accounts(cfg)
        raw = self._fetch_and_merge_summary(
            endpoint, self.start_date, self.end_date, accounts=accounts)
        if not raw:
            return None

        # 构建日均行
        row = {"日期": f"{self.start_date}~{self.end_date}"}
        for m in metrics:
            if isinstance(m, str):
                header, field = m, m
            else:
                header = m.get("header", m.get("field", ""))
                field = m.get("field", "")
            val = safe_float(raw.get(field, 0))
            row[header] = round(val / self.period_days, 2)

        for cm in calculated_metrics:
            header = cm.get("header", cm.get("name", ""))
            fmt = cm.get("format", "number")
            formula = cm.get("formula")

            if formula:
                val = _eval_formula(formula, raw)
            else:
                num_field = cm.get("numerator", "")
                den_field = cm.get("denominator", "")
                multiplier = cm.get("multiplier", 1)
                num = safe_float(raw.get(num_field, 0))
                den = safe_float(raw.get(den_field, 0))
                val = (num / den * multiplier) if den > 0 else 0

            if fmt == "percentage":
                row[header] = f"{round(val * 100, 2)}%" if val else "0.00%"
            else:
                row[header] = round(val, 2) if val else 0

        return pd.DataFrame([row])

    # ----------------------------------------------------------
    # 辅助方法
    # ----------------------------------------------------------

    def _get_raw_fields(self, metrics):
        """从metrics定义中提取所有需要累加的原始字段"""
        fields = set()
        for m in metrics:
            if isinstance(m, str):
                fields.add(m)
            else:
                fields.add(m.get("field", ""))
        fields.discard("")
        return fields

    def _get_dimension_field(self, split_col):
        """获取维度对应的API字段名"""
        info = DIMENSION_LABEL_MAPS.get(split_col)
        return info[0] if info else split_col

    def _get_dimension_label(self, split_col):
        """获取维度的中文标签"""
        info = DIMENSION_LABEL_MAPS.get(split_col)
        return info[1] if info else split_col

    def _get_dimension_value_map(self, split_col):
        """获取维度值的映射表"""
        info = DIMENSION_LABEL_MAPS.get(split_col)
        return info[2] if info else None


# ============================================================
# Excel输出
# ============================================================

def save_to_excel(sheets_data, output_path):
    """
    保存报告到Excel

    Args:
        sheets_data: {sheet_name: [(section_name, DataFrame), ...]}
        output_path: 输出文件路径
    """
    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        for sheet_name, sections in sheets_data.items():
            current_row = 0
            for section_name, df in sections:
                # 写section标题
                title_df = pd.DataFrame([[section_name]])
                title_df.to_excel(writer, sheet_name=sheet_name,
                                  startrow=current_row,
                                  index=False, header=False)
                current_row += 1

                # 写数据
                df.to_excel(writer, sheet_name=sheet_name,
                            startrow=current_row, index=False)
                current_row += len(df) + 2  # 数据 + 表头 + 空行

    # 格式化
    format_excel(output_path)
    print(f"报告已保存: {output_path}")


def format_excel(filepath):
    """格式化Excel样式"""
    wb = load_workbook(filepath)

    title_fill = PatternFill(start_color="4472C4", end_color="4472C4",
                             fill_type="solid")
    title_font = Font(bold=True, color="FFFFFF", size=12)
    header_fill = PatternFill(start_color="366092", end_color="366092",
                              fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")
    total_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2",
                             fill_type="solid")
    total_font = Font(bold=True)
    center = Alignment(horizontal="center", vertical="center")

    for ws in wb.worksheets:
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row):
            first_val = str(row[0].value) if row[0].value else ""

            # section标题行（单独一个单元格有值，其余为空）
            non_empty = sum(1 for c in row if c.value is not None)
            if non_empty == 1 and first_val and first_val != "总计":
                for cell in row:
                    cell.fill = title_fill
                    cell.font = title_font
                    cell.alignment = center
                continue

            # 总计行
            if first_val == "总计":
                for cell in row:
                    cell.fill = total_fill
                    cell.font = total_font
                continue

            # 尝试检测表头行（跟在标题行后面的行，多个非空单元格）
            # 通过检查上一行是否为标题行来判断
            row_idx = row[0].row
            if row_idx > 1:
                prev_val = str(ws.cell(row=row_idx - 1, column=1).value or "")
                prev_non_empty = sum(
                    1 for c in ws[row_idx - 1] if c.value is not None)
                if prev_non_empty == 1 and prev_val:
                    # 当前行是表头
                    for cell in row:
                        cell.fill = header_fill
                        cell.font = header_font
                        cell.alignment = center

        # 自动列宽
        for col in ws.columns:
            max_len = 0
            col_letter = col[0].column_letter
            for cell in col:
                try:
                    max_len = max(max_len, len(str(cell.value or "")))
                except:
                    pass
            ws.column_dimensions[col_letter].width = min(max_len + 3, 50)

    wb.save(filepath)


# ============================================================
# 命令行入口
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="报告引擎")
    parser.add_argument("--config", required=True, help="配置文件路径")
    parser.add_argument("--start", required=True, help="开始日期 yyyy-MM-dd")
    parser.add_argument("--end", required=True, help="结束日期 yyyy-MM-dd")
    parser.add_argument("--accounts", help="账户ID列表(逗号分隔)，覆盖config")
    parser.add_argument("--token", help="直接传入access_token")
    parser.add_argument("--token-config", help="token配置文件路径")
    parser.add_argument("--output", help="输出文件路径")
    args = parser.parse_args()

    # 加载config
    with open(args.config, 'r', encoding='utf-8') as f:
        config = json.load(f)

    # 初始化token
    tm = TokenManager()
    if args.token:
        tm.set_token(args.token)
    elif args.token_config:
        tm.load_config(args.token_config)
    else:
        # 尝试从config中加载
        token_config = config.get("token_config")
        if token_config:
            tm.load_config(token_config)

    fetcher = DataFetcher(tm)

    # 账户列表
    accounts = None
    if args.accounts:
        accounts = [a.strip() for a in args.accounts.split(",")]

    # 输出路径
    if args.output:
        output_path = args.output
    else:
        script_dir = Path(__file__).parent.parent
        output_dir = script_dir / "output"
        output_dir.mkdir(exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_name = config.get("report_name", "report")
        output_path = str(
            output_dir / f"{report_name}_{args.start}_{args.end}_{timestamp}.xlsx")

    # 执行
    engine = ReportEngine(config, fetcher, args.start, args.end, accounts)
    sheets = engine.run()

    if sheets:
        save_to_excel(sheets, output_path)
    else:
        print("所有section均无数据，未生成报告")


if __name__ == "__main__":
    main()
