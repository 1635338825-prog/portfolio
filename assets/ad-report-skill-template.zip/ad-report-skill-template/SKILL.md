---
name: juguang-client-skill-template
description: 为具体客户创建独立的聚光广告报告 skill 的通用模板。当用户需要为某个客户（如"佛山美莱"、"唯品会"等）创建专属的周报/日报/时报 skill 时，使用此模板快速生成。
---

# 聚光客户报告 Skill 模板

## 概述

这是一个**模板 skill**，用于为具体客户快速生成独立的聚光广告报告 skill。

**使用场景**：
- 用户说"帮我创建一个XX客户的周报 skill"
- 用户说"以后直接说'跑XX周报'就行"

**输出**：一个独立的 skill 目录，包含：
- 该客户的报告配置（configs/）
- 执行脚本（scripts/）
- 接口文档和计算公式（references/）
- 生成的报告（output/）

## 目录结构

```
juguang-client-skill-template/
├── SKILL.md                          # 本文档
├── configs/                          # 配置模板
│   └── _template.json                # 通用配置模板
├── references/                       # 参考文档（复制到新 skill）
│   ├── api-endpoints.md              # 聚光 API 接口说明
│   ├── api-fields.md                 # API 指标全集
│   ├── calculation-rules.md          # 计算公式
│   └── field-mapping.md              # 字段映射
├── scripts/                          # 脚本（复制到新 skill）
│   ├── report_engine.py              # 报告生成引擎
│   ├── data_fetcher.py               # 统一取数层
│   ├── token_manager.py              # 代理账户映射与 token
│   ├── easy_note_fetcher.py          # 简单投笔记取数
│   └── city_province_map.py          # 城市→省份映射
└── output/                           # 生成的报告（新 skill 独立维护）
```

## 创建新客户 Skill 的流程

### 预检：检查客户信息

在开始创建之前，先检查是否已有该客户的信息：

1. **检查现有 skill**：搜索 `skills/` 目录下是否已有该客户的 skill
2. **检查现有 config**：搜索 `configs/` 目录下是否已有该客户的配置
3. **检查记忆**：搜索 MEMORY.md 或 memory/ 目录中是否有该客户的历史记录

**如果找到**：直接复用现有信息，跳到「执行流程」。

**如果没找到**：进入下面的引导流程。

---

### 第一步：引导用户提供客户信息

如果缺少客户信息，按以下顺序引导用户提供：

**必须信息**：

| 信息 | 说明 | 引导话术 |
|------|------|----------|
| 客户名称 | 品牌/公司名 | "请问客户名称是什么？" |
| 广告主账户 | 账户名或广告主ID | "请提供广告主账户名或广告主ID，如果有多个账户请一并提供" |
| 投放模式 | 普通投放/简单投/混合 | "这个账户是普通投放、简单投、还是两者都有？" |

**可选信息**（可以后续补充）：

| 信息 | 说明 | 引导话术 |
|------|------|----------|
| Skill 名称 | 英文短名（用于目录名） | 根据客户名称自动生成，如 `meilai-weekly` |
| 报告类型 | 周报/日报/时报 | "你需要周报、日报还是时报？" |

**引导示例**：

> "我需要一些信息来创建这个 skill：
> 1. 客户名称是什么？
> 2. 广告主账户名或ID是什么？如果有多个账户请一并提供
> 3. 投放模式是普通投放、简单投、还是两者都有？"

---

### 第二步：引导用户提供报告格式

如果缺少报告格式，按以下方式引导：

**方式一：直接发参考文件（推荐）**

> "你方便直接发一份之前用过的报告文件吗？我按那个格式来做，这样最准确。"

用户发来 Excel/截图后，分析文件中的 sheet 结构、列名、指标，直接生成对应的 config。

**方式二：参考现有模板**

> "我们有几种常见的报告格式，你看哪种更接近你的需求？"
>
> 1. **基础版**：分日报表 + 本周汇总 + 笔记报表
> 2. **标准版**：基础版 + 关键词报表 + 地域报表
> 3. **完整版**：标准版 + 投放模式报表 + 点位报表 + 优化目标报表 + 环比对比

**方式三：让用户自定义**

如果用户有特定需求，逐项确认：

| 维度 | 说明 | 是否需要 |
|------|------|----------|
| 分日报表 | 每天一行，看趋势 | ✅/❌ |
| 本周汇总 | 全周期汇总 | ✅/❌ |
| 上周汇总（环比） | 上一周期汇总，用于对比 | ✅/❌ |
| 投放模式报表 | 按普通投放/简单投拆分 | ✅/❌ |
| 点位报表 | 按投放位置拆分 | ✅/❌ |
| 地域报表 | 按省份拆分 | ✅/❌ |
| 优化目标报表 | 按优化目标拆分 | ✅/❌ |
| 笔记报表 | 按笔记拆分 | ✅/❌ |
| 关键词报表 | 按关键词拆分 | ✅/❌ |

**指标选择**（默认包含常用指标，用户可增减）：

| 指标类型 | 常用指标 |
|----------|----------|
| 基础指标 | 消费、展现量、点击量 |
| 成本指标 | CPC、CPM、私信进线成本、私信开口成本、私信留资成本 |
| 效果指标 | 私信进线数、私信开口数、私信留资数、互动量 |
| 比率指标 | 点击率、进线率、开口率、留资率 |

**引导话术示例**：

> "你需要哪些维度的报表？"
> - "分日看趋势 + 汇总看整体 + 笔记看效果 + 关键词看搜索"
> - "或者你有其他需求？比如按地域、按投放模式拆分？"
>
> "指标方面，除了消费、展现、点击这些基础的，还需要看私信相关的成本吗？比如进线成本、开口成本、留资成本？"

### 第三步：生成新 Skill

1. **创建目录**：
   ```bash
   mkdir skills/{skill-name}
   mkdir skills/{skill-name}/configs
   mkdir skills/{skill-name}/scripts
   mkdir skills/{skill-name}/references
   mkdir skills/{skill-name}/output
   ```

2. **复制脚本**：
   ```bash
   cp juguang-client-skill-template/scripts/*.py skills/{skill-name}/scripts/
   ```

3. **复制参考文档**：
   ```bash
   cp juguang-client-skill-template/references/*.md skills/{skill-name}/references/
   ```

4. **生成配置**：
   根据用户需求，基于 `configs/_template.json` 生成 `skills/{skill-name}/configs/{客户名}-{报告类型}.json`

5. **生成 SKILL.md**：
   基于下方模板生成新 skill 的 SKILL.md

### 第四步：测试并告知用户

1. 运行一次测试，确认数据正确
2. 把结果发给用户确认
3. 告知用户：
   > "以后直接说'跑{客户名}{报告类型}'就行，我会自动执行。"

## ⚠️ 接口使用核心规范（写 config 前必读）

### 规则一：time_unit 选择

| 需求 | time_unit |
|------|-----------|
| 需要分天看趋势 | DAY |
| 其他所有情况（汇总/按维度/按笔记/按关键词） | **SUMMARY** |

**永远不要对非时间维度使用 DAY。**

### 规则二：总计行数据来源

- **必须使用 API 返回的 `aggregation_data`**，API 已正确计算所有字段。
- **禁止 engine 手动累加 data_list 生成总计行**（ratio 字段求和在数学上是错误的）。

### 规则三：指标放置规则

| 场景 | 处理方式 |
|------|---------|
| 单账户 | 所有字段直接放 `metrics` |
| 多账户合并 | 累加型放 `metrics`；ratio 放 `calculated_metrics` 写公式 |
| keyword / search_word | 累加型放 `metrics`；ratio 必须放 `calculated_metrics` |

### 规则四：split_columns 使用规范

- 只有 `account` 和 `creative` endpoint 支持 `split_columns`。
- 使用时必须同时设置 `time_unit: SUMMARY` 和 `merge_accounts: true`。

### ⚠️ 禁止使用的错误组合

| 错误写法 | 后果 | 正确写法 |
|---------|------|---------|
| `split_columns` + `summary_only: true` | 数据不聚合 | 改用 `merge_accounts: true` |
| `split_columns` + `merge_accounts: false` | 输出原始行 | 改用 `merge_accounts: true` |
| `note`/`keyword` + `summary_only: true` | 只剩总计一行 | 改用 `summary_only: false` + `summary_row: true` |

## 投放模式选择

聚光有两种投放模式，数据来自不同接口，**不重叠，需分别拉取后合并**：

| 投放模式 | 接口路径 | 说明 |
|---------|---------|------|
| **普通投放** | `/api/open/jg/data/report/offline/account` | 标准投放，支持全量维度拆分 |
| **简单投** | `/api/open/jg/data/report/offline/easy/promotion/note` | 简化投放，仅支持 city/keyword/noteId 拆分 |

### 用户选择投放模式时的处理

| 用户需求 | 处理方式 |
|---------|---------|
| 只要普通投放 | 只拉 account 接口 |
| 只要简单投 | 只拉 easy 接口 |
| 两者都要（混合模式） | 分别拉取，合并后重算 ratio |
| 不确定 | 问用户确认 |

### 简单投接口限制

| 参数 | 支持 | 说明 |
|------|------|------|
| `city` | ✅ | 城市维度，需映射到省份后合并 |
| `keyword` | ✅ | 关键词维度 |
| `noteId` | ✅ | 笔记维度 |
| `province` | ❌ | 不支持，用 city 代替 |
| `deliveryMode` | ❌ | 不支持 |

### 混合模式数据合并规则

**核心约束：ratio 字段不能直接用 API 返回值，合并后必须重新计算。**

| 步骤 | 操作 |
|------|------|
| 1. 分别拉取 | 普通投放 + 简单投数据 |
| 2. 简单投预处理 | 分日数据按 time 聚合；城市数据 city→province 映射 |
| 3. 累加型字段相加 | fee, impression, click, message_consult, initiative_message, msg_leads_num |
| 4. ratio 字段清空 | 所有已计算的 ratio 字段丢弃 |
| 5. ratio 重算 | 用合并后的累加值重新计算（详见 `references/calculation-rules.md`） |

## 执行注意事项

### 执行后必须发送文件

脚本执行成功后，**必须立即**将生成的 Excel 文件发送给用户：

1. 用 Python 写文件获取最新输出路径（Windows GBK 终端会乱码中文路径）：
   ```
   python -c "import os,glob; files=sorted(glob.glob(r'../output/*.xlsx'),key=os.path.getmtime); open('../output/latest_output.txt','w',encoding='utf-8').write(files[-1])"
   ```
2. 用 `message` 工具发送文件，**不传 target**，让系统自动路由到当前会话。
3. 发送成功后，再告知用户报告已发送及各维度数据行数摘要。

### 其他注意事项

- **离线数据**：次日 10 点后可用
- **接口自动选择**：engine 自动按日期选接口（今天 → realtime，历史 → offline），config 不需要指定 api_type
- **环比自动推算**：自动推算上一同等周期
- **枚举值映射**：在 engine 维护，新值需更新 engine 代码
- **小时区间**：左闭右开，hour_start <= hour < hour_end
- **中文路径问题**：Windows GBK 终端会乱码，用 Python 写文件获取路径

## 新 Skill 的 SKILL.md 模板

```markdown
---
name: {skill-name}
description: 生成{客户名称}的聚光广告{报告类型}。用户提到"{客户名}周报"、"{客户名}日报"、"跑{客户名}数据"时触发。
---

# {客户名称}聚光广告{报告类型}

## 概述

为{客户名称}生成聚光广告{报告类型}，输出 Excel 报告。

## 目录结构

```
{skill-name}/
├── SKILL.md
├── configs/
│   └── {客户名}-{报告类型}.json
├── references/
│   ├── api-endpoints.md
│   ├── api-fields.md
│   ├── calculation-rules.md
│   └── field-mapping.md
├── scripts/
│   ├── report_engine.py
│   ├── data_fetcher.py
│   ├── token_manager.py
│   ├── easy_note_fetcher.py
│   └── city_province_map.py
└── output/
```

## 执行流程

1. 确认时间范围（如"上周"、"2026-06-08~06-14"）
2. 执行报告引擎：
   ```bash
   cd scripts
   python report_engine.py --config ../configs/{客户名}-{报告类型}.json --start YYYY-MM-DD --end YYYY-MM-DD
   ```
3. 将生成的 Excel 文件发送给用户

## 广告主账户

| 账户名 | 广告主ID |
|--------|----------|
| {账户名1} | {ID1} |
| {账户名2} | {ID2} |

## 参考文件

- `references/api-endpoints.md`：聚光 API 接口说明
- `references/api-fields.md`：API 指标全集
- `references/calculation-rules.md`：计算公式
- `references/field-mapping.md`：字段映射
```

## 常见问题排查

### 数据为空

| 可能原因 | 排查方法 |
|---------|---------|
| 时间范围错误 | 确认日期格式 YYYY-MM-DD，离线数据次日 10 点后可用 |
| 广告主 ID 错误 | 用 `get_token.py --search-name` 检索确认 |
| token 失效 | 用 `get_token.py --advertiser-id {id} --fetch` 验证 |
| 投放模式错误 | 确认是普通投放还是简单投，或混合模式 |

### ratio 字段计算错误

| 可能原因 | 排查方法 |
|---------|---------|
| 多账户合并未重算 | 检查 config，ratio 字段应放 `calculated_metrics` |
| 混合模式未重算 | 检查 `calculation-rules.md` 中的重算公式 |
| keyword/search_word 未重算 | ratio 字段必须放 `calculated_metrics` |

### 数据不聚合

| 可能原因 | 排查方法 |
|---------|---------|
| split_columns + summary_only: true | 改用 `merge_accounts: true` |
| split_columns + merge_accounts: false | 改用 `merge_accounts: true` |
